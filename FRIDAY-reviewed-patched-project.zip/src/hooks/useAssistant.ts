import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { describe, requiresConfirmation, type ActionResult, type FridayAction } from "../core/actions";
import { chat, DEFAULT_ENDPOINT, DEFAULT_MODEL, systemPrompt, testConnection } from "../core/ai";
import { ConversationContext } from "../core/context";
import { executeWeb } from "../core/executor";
import { isAffirmative, isNegative, normalize, offlineAnswer, parseLocal } from "../core/parser";
import { hasSavedKey, loadApiKey, saveApiKey, secureMode } from "../core/secure";

export type CoreStatus = "IDLE" | "LISTENING" | "THINKING" | "SPEAKING";
export type RecognitionMode = "OFF" | "AUTO" | "PUSH_TO_TALK" | "MANUAL";
export interface LogEntry { time: string; heard: string; response: string; engine: string; result: string }

export interface Settings {
  onlineAiEnabled: boolean; provider: string; endpoint: string; model: string;
  userName: string; assistantName: string; language: string; voicePreference: string; wakeWord: string;
}
const SETTINGS_KEY = "friday.settings";
const defaults: Settings = {
  onlineAiEnabled: false, provider: "Groq", endpoint: DEFAULT_ENDPOINT, model: DEFAULT_MODEL,
  userName: "Boss", assistantName: "FRIDAY", language: "hi-IN", voicePreference: "auto", wakeWord: "friday",
};
const loadSettings = (): Settings => { try { return { ...defaults, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}") }; } catch { return defaults; } };

type SR = { lang: string; continuous: boolean; interimResults: boolean; maxAlternatives: number; start(): void; stop(): void; abort(): void;
  onresult: ((e: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null; onend: (() => void) | null; onstart: (() => void) | null; onaudiostart: (() => void) | null };
const getSR = (): (new () => SR) | null => {
  const w = window as unknown as { SpeechRecognition?: new () => SR; webkitSpeechRecognition?: new () => SR };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
};

const stamp = () => new Date().toLocaleTimeString([], { hour12: false });

export function useAssistant() {
  const [settings, setSettingsState] = useState<Settings>(loadSettings);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const apiKeyRef = useRef("");
  const [apiKeySaved, setApiKeySaved] = useState(hasSavedKey());
  const [storageMode, setStorageMode] = useState<string>("UNKNOWN");

  const [status, setStatus] = useState<CoreStatus>("IDLE");
  const [statusDetail, setStatusDetail] = useState("");
  const [partial, setPartial] = useState("");
  const [heard, setHeard] = useState("");
  const [response, setResponse] = useState("");
  const [responseEngine, setResponseEngine] = useState("");
  const [level, setLevel] = useState(0);
  const [recent, setRecent] = useState<string[]>([]);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [pendingDescription, setPendingDescription] = useState<string | null>(null);
  const [recognitionMode, setRecognitionMode] = useState<RecognitionMode>("OFF");
  const [lastEngine, setLastEngine] = useState("—");
  const [lastActionResult, setLastActionResult] = useState("—");
  const [micPermission, setMicPermission] = useState<"granted" | "denied" | "prompt" | "unknown">("unknown");
  const [online, setOnline] = useState(navigator.onLine);
  const [connectionStatus, setConnectionStatus] = useState(settings.onlineAiEnabled ? "NOT TESTED" : "OFF");
  const [connectionDetail, setConnectionDetail] = useState("");
  const [testing, setTesting] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [activeVoice, setActiveVoice] = useState("—");
  const [inputText, setInputText] = useState("");

  const ctx = useMemo(() => new ConversationContext(), []);
  const recRef = useRef<SR | null>(null);
  const autoRef = useRef(false);
  const levelTimer = useRef<number | null>(null);
  const recognizerAvailable = !!getSR();
  const ttsAvailable = typeof speechSynthesis !== "undefined";

  // ------------------------------------------------------------ boot
  useEffect(() => {
    loadApiKey().then(k => { apiKeyRef.current = k; setStorageMode(secureMode); });
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    const nav = navigator as Navigator & { permissions?: Permissions };
    nav.permissions?.query({ name: "microphone" as PermissionName }).then(p => {
      setMicPermission(p.state as "granted" | "denied" | "prompt");
      p.onchange = () => setMicPermission(p.state as "granted" | "denied" | "prompt");
    }).catch(() => setMicPermission("unknown"));
    if (ttsAvailable) {
      const load = () => setVoices(speechSynthesis.getVoices());
      load(); speechSynthesis.onvoiceschanged = load;
    }
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, [ttsAvailable]);

  const addLog = useCallback((h: string, r: string, engine: string, result: string) =>
    setLog(l => [{ time: stamp(), heard: h, response: r, engine, result }, ...l].slice(0, 200)), []);

  // ------------------------------------------------------------ TTS
  const pickVoice = useCallback((text: string) => {
    const pref = settingsRef.current.voicePreference;
    const hasDev = /[\u0900-\u097F]/.test(text);
    const wantHindi = pref === "hindi" || (pref === "auto" && hasDev);
    const hi = voices.find(v => v.lang.toLowerCase().startsWith("hi"));
    const enIn = voices.find(v => v.lang.toLowerCase() === "en-in");
    const en = voices.find(v => v.lang.toLowerCase().startsWith("en"));
    if (wantHindi && hi) return { voice: hi, label: hi.lang };
    if (enIn) return { voice: enIn, label: wantHindi ? `${enIn.lang} (Hindi voice missing)` : enIn.lang };
    if (en) return { voice: en, label: `${en.lang} (fallback)` };
    return { voice: null, label: "default" };
  }, [voices]);

  const speak = useCallback((text: string, after?: () => void) => {
    if (!ttsAvailable || !text) { after?.(); return; }
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const { voice, label } = pickVoice(text);
    if (voice) u.voice = voice;
    u.lang = voice?.lang ?? "en-IN";
    u.rate = 1; u.pitch = 1.02;
    setActiveVoice(label);
    u.onstart = () => setStatus("SPEAKING");
    u.onend = u.onerror = () => { setStatus(s => (s === "SPEAKING" ? "IDLE" : s)); after?.(); };
    speechSynthesis.speak(u);
  }, [pickVoice, ttsAvailable]);

  const stopSpeaking = useCallback(() => { if (ttsAvailable) speechSynthesis.cancel(); setStatus(s => (s === "SPEAKING" ? "IDLE" : s)); }, [ttsAvailable]);

  // ------------------------------------------------------------ brain
  const resultLabel = (r: ActionResult) => r.needsConfirmation ? "NEEDS CONFIRMATION" : r.needsPermission ? "NEEDS PERMISSION" : r.ok ? "ACTION SUCCESS" : "ACTION FAILED";

  const finish = useCallback((h: string, text: string, engine: string, result: string, after?: () => void) => {
    setResponse(text); setResponseEngine(engine); setLastEngine(engine); setLastActionResult(result); setStatus("IDLE");
    addLog(h, text, engine, result);
    speak(text, after);
  }, [addLog, speak]);

  const deps = useMemo(() => ({
    typeIntoInput: (t: string) => setInputText(t),
    openInput: () => { document.getElementById("friday-input")?.focus(); return true; },
    scrollBy: (dy: number) => { const el = document.getElementById("friday-scroll"); if (!el) return false; el.scrollBy({ top: dy, behavior: "smooth" }); return true; },
  }), []);

  const runAction = useCallback(async (h: string, a: FridayAction, engine: string, after?: () => void) => {
    const s = settingsRef.current;
    if (a.type === "STOP") { stopSpeaking(); finish(h, "Ruk gayi.", engine, "ACTION SUCCESS", after); return; }
    if (requiresConfirmation(a) && a.type === "WHATSAPP_SEND_MESSAGE") {
      const recipient = a.recipient ?? ctx.lastRecipient;
      if (!recipient) { finish(h, `${s.userName}, kisko bhejna hai? Pehle contact ka naam bataiye (jaise 'Kartavya ki chat kholo').`, engine, "INFO", after); return; }
      const resolved: FridayAction = { type: "WHATSAPP_SEND_MESSAGE", recipient, message: a.message };
      ctx.pendingAction = resolved; ctx.lastMessage = a.message;
      setPendingDescription(describe(resolved));
      finish(h, `${s.userName}, ${recipient} ko "${a.message}" message bhejna hai. Confirm karun?`, engine, "NEEDS CONFIRMATION", after);
      return;
    }
    const r = await executeWeb(a, ctx, deps);
    finish(h, r.message, engine, resultLabel(r), after);
  }, [ctx, deps, finish, stopSpeaking]);

  const handleUserText = useCallback(async (rawText: string, after?: () => void) => {
    const raw = rawText.trim();
    if (!raw) return;
    const s = settingsRef.current;
    const norm = normalize(raw, s.wakeWord);
    setHeard(raw); setResponse(""); setStatus("THINKING"); setStatusDetail("");
    setRecent(r => [raw, ...r].slice(0, 8));

    const pending = ctx.pendingAction;
    if (pending) {
      ctx.pendingAction = null; setPendingDescription(null);
      if (isAffirmative(norm)) { const r = await executeWeb(pending, ctx, deps); finish(raw, r.message, "LOCAL", resultLabel(r), after); return; }
      if (isNegative(norm)) { finish(raw, `Theek hai ${s.userName}, cancel kar diya.`, "LOCAL", "INFO", after); return; }
    }
    if (!norm) { finish(raw, `Ji ${s.userName}?`, "LOCAL", "INFO", after); return; }

    const local = parseLocal(norm, ctx);
    if (local) { await runAction(raw, local, "LOCAL", after); return; }

    if (s.onlineAiEnabled && navigator.onLine && s.endpoint) {
      try {
        const ai = await chat(s.endpoint, apiKeyRef.current, s.model, systemPrompt(s.assistantName, s.userName, ctx.summary()), ctx.history(), raw);
        ctx.remember("user", raw); ctx.remember("assistant", ai.text || "(action)");
        setConnectionStatus("ONLINE"); setConnectionDetail(`model: ${ai.model}`);
        if (ai.actions.length === 0) { finish(raw, ai.text || "...", "AI", "INFO", after); return; }
        if (ai.text) { setResponse(ai.text); setResponseEngine("AI"); speak(ai.text); }
        for (const a of ai.actions) await runAction(raw, a, "AI", after);
        return;
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        setConnectionStatus("ERROR"); setConnectionDetail(msg);
        const off = offlineAnswer(norm, s.userName, s.assistantName);
        finish(raw, off ?? `AI request fail hui: ${msg}`, off ? "OFFLINE" : "AI", "ACTION FAILED", after);
        return;
      }
    }
    const off = offlineAnswer(norm, s.userName, s.assistantName);
    const msg = off ?? (!s.onlineAiEnabled
      ? "Yeh command local mode mein supported nahi hai. Settings mein Online AI enable karein ya 'YouTube kholo', 'Kartavya ki chat kholo' jaise commands bolein."
      : "Internet nahi hai, isliye AI available nahi. Local commands ab bhi chalenge.");
    finish(raw, msg, "OFFLINE", off ? "INFO" : "ACTION FAILED", after);
  }, [ctx, deps, finish, runAction, speak]);

  // ------------------------------------------------------------ voice
  const stopLevel = () => { if (levelTimer.current) { clearInterval(levelTimer.current); levelTimer.current = null; } setLevel(0); };

  const startRecognizer = useCallback((mode: RecognitionMode) => {
    const SRC = getSR();
    if (!SRC) { setStatusDetail("SPEECH RECOGNITION UNSUPPORTED IN THIS BROWSER"); addLog("(mic)", "Browser mein SpeechRecognition API nahi hai (Chrome/Edge use karein).", "SYSTEM", "ACTION FAILED"); return; }
    recRef.current?.abort();
    stopSpeaking();
    const rec = new SRC();
    rec.lang = settingsRef.current.language; rec.continuous = mode === "PUSH_TO_TALK"; rec.interimResults = true; rec.maxAlternatives = 5;
    let finalText = "";
    rec.onstart = () => { setStatus("LISTENING"); setStatusDetail(""); setRecognitionMode(mode); };
    rec.onaudiostart = () => { levelTimer.current = window.setInterval(() => setLevel(0.25 + Math.random() * 0.5), 120); };
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        if (res.isFinal) {
          const alts = Array.from({ length: res.length }, (_, k) => res[k].transcript);
          const keys = ["kholo", "whatsapp", "youtube", "chrome", "chat", "bhejo", "message", "scroll", "back", "home", "volume", "search", "likho", "settings", "lock", "open", "send", "friday"];
          const best = alts.sort((a, b) => keys.filter(k => normalize(b, "friday").includes(k)).length - keys.filter(k => normalize(a, "friday").includes(k)).length)[0];
          finalText += (finalText ? " " : "") + best;
        } else interim += res[0].transcript;
      }
      setPartial(interim || finalText);
    };
    rec.onerror = (e) => {
      const map: Record<string, string> = { "not-allowed": "Microphone permission nahi hai.", "no-speech": "Koi awaaz nahi aayi (timeout).", network: "Network error: browser recognition ke liye internet chahiye.", "audio-capture": "Microphone nahi mila.", aborted: "Stopped." };
      const msg = map[e.error] ?? `Recognition error: ${e.error}`;
      if (e.error === "not-allowed") setMicPermission("denied");
      if (e.error !== "aborted") { setStatusDetail(msg); addLog("(mic)", msg, "SYSTEM", e.error === "not-allowed" ? "NEEDS PERMISSION" : "ACTION FAILED"); }
    };
    rec.onend = () => {
      stopLevel(); setPartial("");
      setStatus(s => (s === "LISTENING" ? "IDLE" : s));
      const text = finalText.trim();
      const again = () => { if (autoRef.current) setTimeout(() => startRecognizer("AUTO"), 300); else setRecognitionMode("OFF"); };
      if (text) { setMicPermission("granted"); handleUserText(text, again); } else again();
    };
    try { rec.start(); recRef.current = rec; } catch { setStatusDetail("MIC START FAILED"); }
  }, [addLog, handleUserText, stopSpeaking]);

  const startListening = useCallback(() => { autoRef.current = true; startRecognizer("AUTO"); }, [startRecognizer]);
  const pushToTalkStart = useCallback(() => { autoRef.current = false; startRecognizer("PUSH_TO_TALK"); }, [startRecognizer]);
  const pushToTalkEnd = useCallback(() => { recRef.current?.stop(); }, []);
  const stop = useCallback(() => {
    autoRef.current = false; recRef.current?.abort(); recRef.current = null; stopLevel(); stopSpeaking();
    setStatus("IDLE"); setStatusDetail("STOPPED"); setPartial(""); setRecognitionMode("OFF");
  }, [stopSpeaking]);

  const submitText = useCallback((t: string) => { setRecognitionMode(m => (m === "OFF" ? "MANUAL" : m)); handleUserText(t); }, [handleUserText]);
  const confirmPending = useCallback(() => handleUserText("haan"), [handleUserText]);
  const denyPending = useCallback(() => handleUserText("nahi"), [handleUserText]);

  // ------------------------------------------------------------ settings
  const saveSettings = useCallback((patch: Partial<Settings>) => {
    setSettingsState(prev => { const next = { ...prev, ...patch }; localStorage.setItem(SETTINGS_KEY, JSON.stringify(next)); settingsRef.current = next; return next; });
  }, []);

  const saveAi = useCallback(async (p: { onlineAiEnabled: boolean; provider: string; endpoint: string; model: string; apiKey: string | null }) => {
    saveSettings({ onlineAiEnabled: p.onlineAiEnabled, provider: p.provider || "Custom", endpoint: p.endpoint.trim() || DEFAULT_ENDPOINT, model: p.model.trim() || DEFAULT_MODEL });
    if (p.apiKey !== null) { await saveApiKey(p.apiKey.trim()); apiKeyRef.current = p.apiKey.trim(); setApiKeySaved(!!p.apiKey.trim()); setStorageMode(secureMode); }
    setConnectionStatus(p.onlineAiEnabled ? "SAVED · NOT TESTED" : "OFF"); setConnectionDetail("");
    addLog("(settings)", `AI settings saved (key ${apiKeyRef.current ? `stored · ${secureMode}` : "empty"})`, "SYSTEM", "INFO");
  }, [addLog, saveSettings]);

  const runTest = useCallback(async () => {
    if (testing) return;
    setTesting(true); setConnectionStatus("TESTING"); setConnectionDetail("");
    if (!navigator.onLine) { setTesting(false); setConnectionStatus("NO INTERNET"); setConnectionDetail("Device offline hai"); addLog("(test)", "Connection test: no internet", "SYSTEM", "ACTION FAILED"); return; }
    const s = settingsRef.current;
    const r = await testConnection(s.endpoint, apiKeyRef.current, s.model);
    setTesting(false); setConnectionStatus(r.ok ? "CONNECTED" : "FAILED"); setConnectionDetail(r.detail);
    addLog("(test)", `Connection ${r.ok ? "OK" : "failed"}: ${r.detail}`, "SYSTEM", r.ok ? "ACTION SUCCESS" : "ACTION FAILED");
  }, [addLog, testing]);

  const saveProfile = useCallback((p: { userName: string; assistantName: string; language: string; voicePreference: string }) => {
    saveSettings({ userName: p.userName.trim() || "Boss", assistantName: p.assistantName.trim() || "FRIDAY", language: p.language, voicePreference: p.voicePreference });
    addLog("(profile)", `Profile saved: ${p.userName || "Boss"} / ${p.assistantName || "FRIDAY"} / ${p.language} / ${p.voicePreference}`, "SYSTEM", "INFO");
  }, [addLog, saveSettings]);

  const previewVoice = useCallback(() => speak(`Hello ${settingsRef.current.userName}, main ${settingsRef.current.assistantName} hoon. Awaaz test ho rahi hai.`), [speak]);
  const setWakeWord = useCallback((w: string) => saveSettings({ wakeWord: w.trim().toLowerCase() || "friday" }), [saveSettings]);
  const clearLog = useCallback(() => { setLog([]); setRecent([]); }, []);
  const clearContext = useCallback(() => { ctx.clearAll(); setPendingDescription(null); addLog("(system)", "Conversation context cleared", "SYSTEM", "INFO"); }, [addLog, ctx]);

  return {
    settings, apiKeySaved, storageMode, status, statusDetail, partial, heard, response, responseEngine, level, recent, log,
    pendingDescription, recognitionMode, lastEngine, lastActionResult, micPermission, online, connectionStatus, connectionDetail,
    testing, voices, activeVoice, recognizerAvailable, ttsAvailable, inputText, setInputText,
    startListening, pushToTalkStart, pushToTalkEnd, stop, submitText, confirmPending, denyPending,
    saveAi, runTest, saveProfile, previewVoice, setWakeWord, clearLog, clearContext,
  };
}
export type Assistant = ReturnType<typeof useAssistant>;
