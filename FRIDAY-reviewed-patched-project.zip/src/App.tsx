import { useState } from "react";
import Home from "./components/Home";
import Log from "./components/Log";
import Profile from "./components/Profile";
import Settings from "./components/Settings";
import Splash from "./components/Splash";
import { useAssistant } from "./hooks/useAssistant";

const tabs = ["HOME", "LOG", "PROFILE", "SETTINGS"] as const;
type Tab = (typeof tabs)[number];

export default function App() {
  const [splash, setSplash] = useState(true);
  const [tab, setTab] = useState<Tab>("HOME");
  const a = useAssistant();

  if (splash) return <Splash onDone={() => setSplash(false)} />;

  return (
    <div className="flex h-dvh flex-col bg-[#0b1220] font-mono text-[#e2e8f0]">
      <main id="friday-scroll" className="flex-1 overflow-y-auto">
        {tab === "HOME" && <Home a={a} />}
        {tab === "LOG" && <Log a={a} />}
        {tab === "PROFILE" && <Profile a={a} />}
        {tab === "SETTINGS" && <Settings a={a} />}
      </main>
      <nav className="grid grid-cols-4 border-t border-[#1c2b40] bg-[#070c16] pb-[env(safe-area-inset-bottom)]">
        {tabs.map(t => (
          <button key={t} type="button" onClick={() => setTab(t)}
            className={`py-5 text-sm font-bold tracking-[0.25em] ${tab === t ? "text-cyan-400 drop-shadow-[0_0_8px_#22d3ee]" : "text-[#7c8da6]"}`}>
            {t}
          </button>
        ))}
      </nav>
    </div>
  );
}
