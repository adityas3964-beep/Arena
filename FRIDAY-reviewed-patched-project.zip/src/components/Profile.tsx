import { useState } from "react";
import type { Assistant } from "../hooks/useAssistant";
import { C, Chips, HudButton, HudField, HudPanel } from "./Hud";

export default function Profile({ a }: { a: Assistant }) {
  const [name, setName] = useState(a.settings.userName);
  const [assistant, setAssistant] = useState(a.settings.assistantName);
  const [lang, setLang] = useState(a.settings.language);
  const [voice, setVoice] = useState(a.settings.voicePreference);
  const hiEn = a.voices.filter(v => /^(hi|en)/i.test(v.lang));
  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-4 px-3.5 pb-6 pt-2">
      <HudPanel title="Profile">
        <HudField label="Preferred name (FRIDAY will address you like this)" value={name} onChange={setName} placeholder="Boss" />
        <HudField label="Assistant name" value={assistant} onChange={setAssistant} placeholder="FRIDAY" />
        <p className="mt-2 text-sm text-[#7c8da6]">Recognition language</p>
        <div className="mt-2"><Chips options={[["hi-IN", "Hindi/Hinglish"], ["en-IN", "English (IN)"], ["en-US", "English (US)"]]} value={lang} onChange={setLang} /></div>
        <p className="mt-4 text-sm text-[#7c8da6]">Voice preference</p>
        <div className="mt-2"><Chips options={[["auto", "Auto"], ["hindi", "Hindi"], ["english", "English"]]} value={voice} onChange={setVoice} /></div>
        <p className="mt-2 text-xs text-[#7c8da6]">Active TTS voice: {a.activeVoice} · Installed hi/en voices: {hiEn.length}{hiEn.some(v => /^hi/i.test(v.lang)) ? "" : " (no Hindi voice → en fallback)"}</p>
        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <HudButton accent={C.cyan} filled onClick={() => a.saveProfile({ userName: name, assistantName: assistant, language: lang, voicePreference: voice })}>Save profile</HudButton>
          <HudButton onClick={a.previewVoice}>Preview voice</HudButton>
        </div>
      </HudPanel>
      <HudPanel title="About">
        <p className="text-[#e2e8f0]">FRIDAY – Personal AI Assistant</p>
        <p className="mt-1 text-cyan-400">Whole credit goes to Aditya.</p>
        <p className="text-[#7c8da6]">© 2026 Aditya. All rights reserved.</p>
        <p className="mt-3 text-xs text-[#7c8da6]">Web build 1.0.0 · Android package com.aditya.friday (source in /android)</p>
        <a href="/friday-android-source.zip" download className="mt-2 inline-block text-xs tracking-[0.15em] text-cyan-400 underline underline-offset-4">DOWNLOAD ANDROID SOURCE ZIP (build APK via GitHub Actions / Android Studio)</a>
        <p className="mt-3 text-xs tracking-[0.2em] text-[#7c8da6]">THIRD-PARTY SOFTWARE</p>
        <p className="text-xs text-[#7c8da6]">React (MIT) · Vite (MIT) · Tailwind CSS (MIT). Android build: AndroidX/Jetpack Compose, Kotlin, kotlinx.coroutines, OkHttp, AndroidX Security Crypto (all Apache-2.0). Speech recognition and TTS are provided by the browser/device engines.</p>
      </HudPanel>
      <HudPanel title="Privacy">
        <p className="text-xs text-[#7c8da6]">• API key is stored only as AES-GCM ciphertext (non-extractable WebCrypto key in IndexedDB; Android Keystore in the native app) and is never logged.<br />• Microphone is used only while listening; status is shown on screen.<br />• Messages are never sent without explicit confirmation.<br />• No analytics, no personal-data collection, no payments.</p>
      </HudPanel>
    </div>
  );
}
