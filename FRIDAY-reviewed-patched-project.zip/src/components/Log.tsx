import type { Assistant } from "../hooks/useAssistant";
import { C, HudButton, HudPanel, StatusRow, resultColor } from "./Hud";

export default function Log({ a }: { a: Assistant }) {
  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-4 px-3.5 pb-6 pt-2">
      <HudPanel title="Service Status">
        <StatusRow label="Online AI" value={!a.settings.onlineAiEnabled ? "OFF" : a.online ? "READY" : "NO INTERNET"} color={!a.settings.onlineAiEnabled ? C.dim : a.online ? C.green : C.amber} />
        <StatusRow label="Offline mode" value={a.recognizerAvailable ? "READY" : "NOT RUNNING"} color={a.recognizerAvailable ? C.green : C.red} />
        <StatusRow label="Microphone permission" value={a.micPermission === "granted" ? "GRANTED" : a.micPermission === "denied" ? "DENIED" : "NEEDS PERMISSION"} color={a.micPermission === "granted" ? C.green : C.amber} />
        <StatusRow label="Accessibility permission" value="N/A IN WEB" color={C.dim} />
        <StatusRow label="Recognition mode" value={a.recognitionMode.replace("_", " ")} color={a.recognitionMode === "OFF" ? C.dim : C.green} />
        <StatusRow label="Wake word status" value="NOT RUNNING" color={C.amber} />
        <StatusRow label="TTS voice" value={a.ttsAvailable ? a.activeVoice : "UNAVAILABLE"} color={a.ttsAvailable ? C.cyan : C.red} />
        <StatusRow label="Key storage" value={a.storageMode} color={a.storageMode === "KEYSTORE" ? C.green : C.amber} />
        <StatusRow label="Last engine used" value={a.lastEngine} color={C.cyan} />
        <StatusRow label="Last command" value={(a.heard || "—").slice(0, 28)} color={C.text} />
        <StatusRow label="Last action result" value={a.lastActionResult} color={resultColor(a.lastActionResult)} />
      </HudPanel>
      <div className="grid grid-cols-2 gap-2.5">
        <HudButton onClick={a.clearLog}>Clear log</HudButton>
        <HudButton onClick={a.clearContext} accent={C.amber}>Clear context</HudButton>
      </div>
      <HudPanel title={`Command Log (${a.log.length})`}>
        {a.log.length === 0 && <p className="text-sm text-[#7c8da6]">No entries yet. Commands and their real results appear here.</p>}
        <ul className="divide-y divide-[#1c2b40]">
          {a.log.map((e, i) => (
            <li key={i} className="py-2.5">
              <div className="flex items-center gap-2 text-[11px] tracking-[0.15em]">
                <span className="text-[#7c8da6]">{e.time}</span><span className="flex-1" />
                <span className="text-cyan-400">[{e.engine}]</span>
                <span style={{ color: resultColor(e.result) }}>{e.result}</span>
              </div>
              <p className="text-[#e2e8f0]">› {e.heard}</p>
              <p className="text-sm text-cyan-400/85">{e.response}</p>
            </li>
          ))}
        </ul>
      </HudPanel>
    </div>
  );
}
