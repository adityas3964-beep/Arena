import type { ButtonHTMLAttributes, ReactNode } from "react";

export const C = { cyan: "#22d3ee", blue: "#3b82f6", dim: "#7c8da6", green: "#34d399", amber: "#f59e0b", red: "#f87171", text: "#e2e8f0" };

export function HudPanel({ title, children, className = "" }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={`relative w-full bg-[#0e1726]/60 border border-[#1c2b40] px-4 py-4 ${className}`}>
      {[["top-0 left-0", "border-t-[3px] border-l-[3px]"], ["top-0 right-0", "border-t-[3px] border-r-[3px]"], ["bottom-0 left-0", "border-b-[3px] border-l-[3px]"], ["bottom-0 right-0", "border-b-[3px] border-r-[3px]"]].map(([pos, b]) => (
        <span key={pos} className={`pointer-events-none absolute ${pos} h-6 w-6 border-cyan-400 ${b} drop-shadow-[0_0_6px_#22d3ee]`} />
      ))}
      <h2 className="text-cyan-400 tracking-[0.25em] text-sm mb-3 uppercase">{title}</h2>
      {children}
    </section>
  );
}

export function StatusRow({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
      <span className="flex-1 text-[#7c8da6] tracking-[0.15em] text-sm uppercase">{label}</span>
      <span className="font-bold tracking-[0.15em] text-sm uppercase text-right" style={{ color }}>{value}</span>
    </div>
  );
}

export function HudButton({ children, onClick, accent = C.dim, filled = false, disabled = false, className = "", ...rest }:
  { children: ReactNode; onClick?: () => void; accent?: string; filled?: boolean; disabled?: boolean; className?: string } & Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onClick" | "children">) {
  return (
    <button
      type="button" onClick={onClick} disabled={disabled} {...rest}
      className={`rounded-md border-[1.5px] px-3 py-4 text-sm font-bold uppercase tracking-[0.2em] transition active:scale-[0.98] disabled:opacity-40 select-none ${className}`}
      style={{ borderColor: accent, color: accent, background: filled ? `${accent}1f` : "transparent", boxShadow: filled ? `0 0 14px ${accent}33` : undefined }}
    >
      {children}
    </button>
  );
}

export function HudField({ label, value, onChange, type = "text", placeholder = "", id }:
  { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string; id?: string }) {
  return (
    <label className="block py-1.5">
      <span className="text-[#7c8da6] text-sm">{label}</span>
      <input id={id} type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)}
        autoComplete={type === "password" ? "off" : undefined}
        className="mt-1.5 w-full rounded-md border border-cyan-400/45 bg-[#0e1726]/60 px-3 py-3 text-[#e2e8f0] outline-none focus:border-cyan-400 focus:shadow-[0_0_10px_#22d3ee44] placeholder:text-[#7c8da6]/50" />
    </label>
  );
}

export function Chips({ options, value, onChange }: { options: [string, string][]; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex gap-2">
      {options.map(([k, label]) => (
        <button key={k} type="button" onClick={() => onChange(k)}
          className={`flex-1 rounded-md border py-2.5 text-[11px] uppercase tracking-[0.15em] ${k === value ? "border-cyan-400 bg-cyan-400/15 text-cyan-400" : "border-[#1c2b40] text-[#7c8da6]"}`}>
          {label}
        </button>
      ))}
    </div>
  );
}

export const resultColor = (r: string) => r === "ACTION SUCCESS" ? C.green : r === "ACTION FAILED" ? C.red : r === "NEEDS CONFIRMATION" || r === "NEEDS PERMISSION" ? C.amber : C.dim;
