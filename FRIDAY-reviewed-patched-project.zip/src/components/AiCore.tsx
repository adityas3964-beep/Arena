import { useEffect, useRef } from "react";
import type { CoreStatus } from "../hooks/useAssistant";

const colorFor = (s: CoreStatus) => s === "LISTENING" ? "#34d399" : s === "THINKING" ? "#f59e0b" : "#22d3ee";

export function AiCore({ status, level }: { status: CoreStatus; level: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const st = useRef({ status, level });
  st.current = { status, level };
  useEffect(() => {
    const cv = ref.current!; const ctx = cv.getContext("2d")!;
    let raf = 0; const t0 = performance.now();
    const draw = (now: number) => {
      const t = (now - t0) / 1000;
      const dpr = window.devicePixelRatio || 1;
      const w = cv.clientWidth, h = cv.clientHeight;
      if (cv.width !== w * dpr || cv.height !== h * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
      const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 4;
      const { status: s, level: lv } = st.current;
      const accent = colorFor(s);
      const pulse = 1 + 0.12 * Math.sin(t * (s === "IDLE" ? 1.4 : 4));
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 0.6 * pulse);
      g.addColorStop(0, accent + "66"); g.addColorStop(1, "transparent");
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r * 0.6 * pulse, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#0c2a3c"; ctx.beginPath(); ctx.arc(cx, cy, r * 0.42, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 3; ctx.shadowColor = "#22d3ee"; ctx.shadowBlur = 10; ctx.stroke(); ctx.shadowBlur = 0;
      if (lv > 0.02) { ctx.strokeStyle = "#3b82f6aa"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, r * (0.44 + 0.25 * lv), 0, Math.PI * 2); ctx.stroke(); }
      // ticks
      const rot = (t / 14) * Math.PI * 2;
      ctx.lineCap = "round";
      for (let i = 0; i < 72; i++) {
        const a = rot + (i * 5 * Math.PI) / 180, long = i % 6 === 0;
        const inner = r * 0.5, outer = long ? r * 0.72 : r * 0.62;
        ctx.strokeStyle = (i % 9 === 0 ? "#3b82f6" : "#22d3ee") + (i % 3 === 0 ? "f2" : "66");
        ctx.lineWidth = long ? 3 : 1.5;
        ctx.beginPath(); ctx.moveTo(cx + inner * Math.cos(a), cy + inner * Math.sin(a)); ctx.lineTo(cx + outer * Math.cos(a), cy + outer * Math.sin(a)); ctx.stroke();
      }
      // outer arcs
      const rot2 = -(t / 9) * Math.PI * 2;
      const arc = (from: number, len: number, color: string, lw: number) => { ctx.strokeStyle = color; ctx.lineWidth = lw; ctx.shadowColor = color; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(cx, cy, r * 0.86, rot2 + from, rot2 + from + len); ctx.stroke(); ctx.shadowBlur = 0; };
      arc(0, Math.PI * 0.61, "#22d3ee", 4); arc(Math.PI * 0.83, Math.PI * 0.33, "#22d3ee", 4); arc(Math.PI * 1.33, Math.PI * 0.44, "#3b82f6b3", 2);
      ctx.strokeStyle = "#22d3ee40"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r * 0.96, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = "#22d3ee2e"; ctx.beginPath(); ctx.arc(cx, cy, r * 0.78, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = accent; ctx.shadowColor = accent; ctx.shadowBlur = 16; ctx.beginPath(); ctx.arc(cx, cy, r * 0.07 * pulse, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} className="h-[300px] w-full max-w-[340px]" aria-label="FRIDAY AI core" />;
}

export function Waveform({ active, speaking, level }: { active: boolean; speaking: boolean; level: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const st = useRef({ active, speaking, level }); st.current = { active, speaking, level };
  useEffect(() => {
    const cv = ref.current!; const ctx = cv.getContext("2d")!; let raf = 0; const t0 = performance.now();
    const draw = (now: number) => {
      const t = (now - t0) / 1000, dpr = window.devicePixelRatio || 1, w = cv.clientWidth, h = cv.clientHeight;
      if (cv.width !== w * dpr || cv.height !== h * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
      const bars = 46, bw = w / bars; const { active: a, speaking: sp, level: lv } = st.current; const phase = t * 5.7;
      ctx.fillStyle = "#22d3ee";
      for (let i = 0; i < bars; i++) {
        const base = !a ? 0.14 : sp ? 0.3 + 0.7 * Math.abs(Math.sin(phase + i * 0.45)) * (0.6 + 0.4 * Math.abs(Math.cos(i * 0.9))) : (0.2 + 0.8 * Math.abs(Math.sin(phase * 0.6 + i * 0.4))) * (0.3 + lv);
        const bh = Math.max(4, Math.min(h, h * base));
        ctx.beginPath(); ctx.roundRect(i * bw + bw * 0.3, (h - bh) / 2, bw * 0.4, bh, 3); ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw); return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} className="h-[72px] w-full" aria-hidden />;
}
