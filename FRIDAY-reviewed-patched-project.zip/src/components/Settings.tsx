import { useState } from "react";
import type { Assistant } from "../hooks/useAssistant";
import { C, Chips, HudButton, HudField, HudPanel, StatusRow } from "./Hud";

export default function Settings({ a }: { a: Assistant }) {
  const [enabled, setEnabled] = useState(a.settings.onlineAiEnabled);
  const [provider, setProvider] = useState(a.settings.provider);
  const [endpoint, setEndpoint] = useState(a.settings.endpoint);
  const [model, setModel] = useState(a.settings.model);
  const [apiKey, setApiKey] = useState("");
  const [wake, setWake] = useState(a.settings.wakeWord);
  const connColor = ["CONNECTED", "ONLINE"].includes(a.connectionStatus) ? C.green : ["FAILED", "ERROR", "NO INTERNET"].includes(a.connectionStatus) ? C.red : a.connectionStatus === "TESTING" ? C.amber : C.dim;
  const save = () => a.saveAi({ onlineAiEnabled: enabled, provider, endpoint, model, apiKey: apiKey ? apiKey : null });

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-4 px-3.5 pb-6 pt-2">
      <HudPanel title="Device Admin (Phone Lock)">
        <StatusRow label="Status" value="N/A IN WEB" color={C.amber} />
        <p className="text-sm text-[#7c8da6]">Sirf 'force-lock' policy: 'phone lock karo' bolne par screen lock hoti hai. Data wipe ya password change ki permission nahi maangi jaati. Yeh feature sirf native Android build (android/) mein available hai — browser phone lock nahi kar sakta.</p>
        <HudButton className="mt-3 w-full" accent={C.cyan} filled disabled>Activate device admin (Android only)</HudButton>
      </HudPanel>

      <HudPanel title="Accessibility (Phone Control)">
        <StatusRow label="Status" value="N/A IN WEB" color={C.dim} />
        <p className="text-sm text-[#7c8da6]">Back/Home/scroll/click/type aur WhatsApp automation Android Accessibility Service se hoti hai (native build). Web build mein scroll, back, click aur typing sirf is dashboard ke andar kaam karte hain; WhatsApp message wa.me se prepare hota hai aur aap khud Send dabate hain.</p>
      </HudPanel>

      <HudPanel title="Wake Word">
        <StatusRow label="Status" value="NOT RUNNING" color={C.amber} />
        <p className="text-sm text-[#7c8da6]">Browser mein genuine always-on wake-word detection possible nahi hai (tab background mein mic band ho jata hai). Isliye yahan fake engine nahi dikhaya gaya — Start Listening / Push To Talk use karein. Wake word bolne par FRIDAY usse command se hata deti hai ("FRIDAY, YouTube kholo").</p>
        <HudField label="Wake word" value={wake} onChange={setWake} placeholder="friday" />
        <HudButton className="w-full" accent={C.cyan} onClick={() => a.setWakeWord(wake)}>Save wake word</HudButton>
      </HudPanel>

      <HudPanel title="AI Provider (Optional)">
        <div className="flex items-center justify-between py-2">
          <span className="text-lg tracking-[0.1em] text-[#e2e8f0]">ENABLE ONLINE AI</span>
          <button type="button" role="switch" aria-checked={enabled} onClick={() => setEnabled(v => !v)}
            className={`relative h-9 w-16 rounded-full border transition ${enabled ? "border-cyan-400 bg-cyan-400/30" : "border-[#4b5563] bg-[#1f2937]"}`}>
            <span className={`absolute top-1 h-6 w-6 rounded-full transition-all ${enabled ? "left-9 bg-cyan-400 shadow-[0_0_10px_#22d3ee]" : "left-1 bg-[#6b7280]"}`} />
          </button>
        </div>
        <p className="text-sm text-[#7c8da6]">Provider</p>
        <div className="mt-2 mb-1"><Chips options={[["Groq", "Groq"], ["OpenAI", "OpenAI"], ["Custom", "Custom"]]} value={provider} onChange={p => {
          setProvider(p);
          if (p === "Groq") { setEndpoint("https://api.groq.com/openai/v1/chat/completions"); if (!model) setModel("llama-3.3-70b-versatile"); }
          if (p === "OpenAI") { setEndpoint("https://api.openai.com/v1/chat/completions"); if (!model) setModel("gpt-4o-mini"); }
        }} /></div>
        <HudField label="Endpoint (OpenAI-compatible /chat/completions URL)" value={endpoint} onChange={setEndpoint} />
        <HudField label="Model name (editable — providers change models)" value={model} onChange={setModel} placeholder="llama-3.3-70b-versatile" />
        <HudField label={a.apiKeySaved ? "API key (saved, encrypted · enter new to replace)" : "API key"} value={apiKey} onChange={setApiKey} type="password" placeholder={a.apiKeySaved ? "••••••••" : "gsk_…"} />
        <div className="mt-1 grid grid-cols-2 gap-2.5">
          <HudButton accent={C.cyan} filled onClick={() => { save(); setApiKey(""); }}>Save key</HudButton>
          <HudButton disabled={a.testing} onClick={async () => { await save(); setApiKey(""); a.runTest(); }}>{a.testing ? "Testing…" : "Test"}</HudButton>
        </div>
        <div className="mt-2"><StatusRow label="Connection" value={a.connectionStatus} color={connColor} /></div>
        {a.connectionDetail && <p className="break-all text-xs text-[#7c8da6]">{a.connectionDetail}</p>}
        <p className="mt-2 text-xs text-[#7c8da6]">AI ke liye internet chahiye aur provider ki free-tier limits lag sakti hain (Groq free tier: rate-limited, billing zaroori nahi). Koi key app mein bundled nahi hai; key encrypt hoke store hoti hai ({a.storageMode}) aur kabhi log nahi hoti. Bina AI ke saare local commands chalte hain. AI jawab [AI] tag se dikhte hain.</p>
      </HudPanel>

      <HudPanel title="Troubleshooting">
        <p className="text-sm text-[#7c8da6]">• Mic start nahi hota: browser ko Microphone permission dein; Chrome/Edge use karein (Firefox mein SpeechRecognition nahi hai).<br />• Recognition "network" error: browser speech recognition Google servers use karta hai, internet chahiye.<br />• Test Connection fail: endpoint, model name aur key check karein; HTTP 401 = galat key, 404 = galat model/endpoint, 429 = rate limit; "CORS" = provider browser requests allow nahi karta (native app mein yeh issue nahi hai).<br />• Apps nahi khulte: popups allow karein. Phone ke installed apps, volume, settings aur lock sirf Android build mein.<br />• Hindi awaaz nahi: OS mein Hindi TTS voice install karein; warna en-IN fallback.</p>
      </HudPanel>
    </div>
  );
}
