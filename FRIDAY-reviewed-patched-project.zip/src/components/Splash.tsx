import { useEffect, useState } from "react";

const stages = ["INITIALIZING CORE", "LOADING VOICE ENGINE", "CALIBRATING", "LINKING COMMAND DISPATCHER", "CHECKING SERVICES", "FRIDAY ONLINE"];

export default function Splash({ onDone }: { onDone: () => void }) {
  const [stage, setStage] = useState(0);
  useEffect(() => {
    if (stage < stages.length - 1) { const t = setTimeout(() => setStage(s => s + 1), 430); return () => clearTimeout(t); }
    const t = setTimeout(onDone, 500); return () => clearTimeout(t);
  }, [stage, onDone]);
  const pct = Math.round(((stage + 1) / stages.length) * 100);
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#0b1220] font-mono">
      <div className="flex w-full max-w-md flex-col items-center px-8">
        <h1 className="text-5xl font-bold tracking-[0.3em] text-cyan-400 animate-pulse" style={{ textShadow: "0 0 18px #22d3ee, 0 0 40px #22d3ee88" }}>FRIDAY</h1>
        <p className="mt-3 text-[11px] tracking-[0.3em] text-[#7c8da6]">YOUR PERSONAL AI ASSISTANT</p>
        <div className="relative mt-12 h-32 w-32">
          <svg viewBox="0 0 100 100" className="h-full w-full animate-[spin_1.4s_linear_infinite]">
            <circle cx="50" cy="50" r="46" fill="none" stroke="#22d3ee" strokeOpacity="0.15" strokeWidth="2" />
            <circle cx="50" cy="50" r="46" fill="none" stroke="#22d3ee" strokeWidth="3" strokeLinecap="round" strokeDasharray="240 50" style={{ filter: "drop-shadow(0 0 6px #22d3ee)" }} />
          </svg>
          <span className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-400 shadow-[0_0_14px_#22d3ee]" />
        </div>
        <p className="mt-9 text-sm tracking-[0.25em] text-[#e2e8f0]">{stages[stage]}</p>
        <div className="mt-7 h-1.5 w-full overflow-hidden rounded-full bg-[#1c2b40]">
          <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-500" style={{ width: `${pct}%` }} />
        </div>
        <p className="mt-2 text-xs text-[#7c8da6]">{pct}%</p>
        <div className="mt-6 flex gap-2.5">{stages.map((_, i) => <span key={i} className={`h-2 w-2 rounded-full ${i <= stage ? "bg-cyan-400 shadow-[0_0_8px_#22d3ee]" : "bg-[#1c2b40]"}`} />)}</div>
      </div>
    </div>
  );
}
