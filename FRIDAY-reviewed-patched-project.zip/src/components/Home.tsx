import { useState } from "react";
import type { Assistant } from "../hooks/useAssistant";
import { AiCore, Waveform } from "./AiCore";
import { C, HudButton, HudPanel, StatusRow, resultColor } from "./Hud";

export default function Home({ a }: { a: Assistant }) {
  const [ptt, setPtt] = useState(false);
  const statusText = a.status === "SPEAKING" ? "SPEAKING" : a.statusDetail || (a.status === "IDLE" ? "STANDBY" : a.status);
  const statusColor = a.status === "IDLE" ? C.dim : a.status === "LISTENING" ? C.green : a.status === "THINKING" ? C.amber : C.cyan;
  const listeningAuto = a.recognitionMode === "AUTO" && a.status !== "IDLE";
  const micOk = a.micPermission !== "denied";

  const pttDown = () => { if (!a.recognizerAvailable) return; setPtt(true); a.pushToTalkStart(); };
  const pttUp = () => { if (!ptt) return; setPtt(false); a.pushToTalkEnd(); };

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center gap-4 px-3.5 pb-6 pt-2">
      <AiCore status={a.status} level={a.level} />
      <p className="text-sm tracking-[0.35em]" style={{ color: statusColor }}>{statusText.toUpperCase()}</p>
      {a.partial && <p className="-mt-2 text-xs text-[#7c8da6]">{a.partial}</p>}
      <Waveform active={a.status !== "IDLE"} speaking={a.status === "SPEAKING"} level={a.level} />

      <div className="grid w-full grid-cols-[1.1fr_1.1fr_0.8fr] gap-2.5">
        <HudButton onClick={a.startListening} accent={listeningAuto ? C.green : C.dim} disabled={!a.recognizerAvailable}>
          {listeningAuto ? "Listening…" : <>Start<br />Listening</>}
        </HudButton>
        <HudButton accent={ptt ? C.cyan : C.dim} filled={ptt} disabled={!a.recognizerAvailable}
          onPointerDown={pttDown} onPointerUp={pttUp} onPointerLeave={pttUp} onPointerCancel={pttUp} onContextMenu={e => e.preventDefault()}>
          {ptt ? "Release to send" : "Push to talk"}
        </HudButton>
        <HudButton onClick={a.stop} accent={C.red} filled>Stop</HudButton>
      </div>
      {!a.recognizerAvailable && <p className="text-xs text-amber-400">This browser has no SpeechRecognition API — use Chrome/Edge, or type commands below.</p>}
      {!micOk && <p className="text-xs text-amber-400">Microphone permission denied — allow it in the browser site settings.</p>}

      <form className="flex w-full items-end gap-2" onSubmit={e => { e.preventDefault(); if (a.inputText.trim()) { a.submitText(a.inputText); a.setInputText(""); } }}>
        <label className="flex-1">
          <span className="text-sm text-[#7c8da6]">Type a command (fallback)</span>
          <input id="friday-input" value={a.inputText} onChange={e => a.setInputText(e.target.value)} placeholder="WhatsApp kholo / Kartavya ki chat kholo"
            className="mt-1.5 w-full rounded-md border border-cyan-400/45 bg-[#0e1726]/60 px-3 py-3 text-[#e2e8f0] outline-none focus:border-cyan-400 placeholder:text-[#7c8da6]/50" />
        </label>
        <HudButton accent={C.cyan} filled className="py-3" type="submit">Send</HudButton>
      </form>

      <HudPanel title="Assistant">
        <p className="text-xs tracking-[0.2em] text-[#7c8da6]">HEARD</p>
        <p className="text-lg text-[#e2e8f0]">{a.heard || "—"}</p>
        <p className="mt-3 text-xs tracking-[0.2em] text-[#7c8da6]">RESPONSE{a.responseEngine ? ` [${a.responseEngine}]` : ""}</p>
        <p className="text-lg text-cyan-400">{a.response || `Standing by, ${a.settings.userName}.`}</p>
        {a.pendingDescription && (
          <div className="mt-3">
            <p className="text-xs text-amber-400">PENDING: {a.pendingDescription}</p>
            <div className="mt-2 grid grid-cols-2 gap-2.5">
              <HudButton onClick={a.confirmPending} accent={C.green} filled>Haan · Confirm</HudButton>
              <HudButton onClick={a.denyPending} accent={C.red}>Nahi · Cancel</HudButton>
            </div>
          </div>
        )}
      </HudPanel>

      <HudPanel title="Recent Commands">
        {a.recent.length === 0 && <p className="text-sm text-[#7c8da6]">No commands yet.</p>}
        {a.recent.slice(0, 5).map((r, i) => <p key={i} className="py-0.5 text-[#e2e8f0]">›  {r}</p>)}
      </HudPanel>

      <HudPanel title="Service Status">
        <StatusRow label="Recognition mode" value={a.recognitionMode.replace("_", " ")} color={a.recognitionMode === "OFF" ? C.dim : C.green} />
        <StatusRow label="Last engine used" value={a.lastEngine} color={a.lastEngine === "—" ? C.dim : C.cyan} />
        <StatusRow label="Online AI" value={!a.settings.onlineAiEnabled ? "OFF" : a.online ? "READY" : "NO INTERNET"} color={!a.settings.onlineAiEnabled ? C.dim : a.online ? C.green : C.amber} />
        <StatusRow label="Offline mode" value={a.recognizerAvailable ? "READY" : "NO RECOGNIZER"} color={a.recognizerAvailable ? C.green : C.red} />
        <StatusRow label={`Wake word (${a.settings.wakeWord})`} value="NOT RUNNING" color={C.amber} />
        <StatusRow label="Microphone permission" value={a.micPermission === "granted" ? "GRANTED" : a.micPermission === "denied" ? "DENIED" : "NEEDS PERMISSION"} color={a.micPermission === "granted" ? C.green : a.micPermission === "denied" ? C.red : C.amber} />
        <StatusRow label="Accessibility" value="N/A IN WEB" color={C.dim} />
        <StatusRow label="Last action result" value={a.lastActionResult} color={resultColor(a.lastActionResult)} />
      </HudPanel>
    </div>
  );
}
