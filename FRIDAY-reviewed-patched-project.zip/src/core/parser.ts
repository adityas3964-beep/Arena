import type { FridayAction } from "./actions";
import type { ConversationContext } from "./context";

const devanagari: [string, string][] = [
  ["व्हाट्सएप", "whatsapp"], ["व्हाट्सप्प", "whatsapp"], ["वाट्सएप", "whatsapp"], ["व्हाट्सऐप", "whatsapp"],
  ["यूट्यूब", "youtube"], ["क्रोम", "chrome"], ["कैमरा", "camera"], ["कैलकुलेटर", "calculator"], ["गैलरी", "gallery"],
  ["सेटिंग्स", "settings"], ["सेटिंग", "settings"], ["फोन", "phone"], ["फ़ोन", "phone"], ["गूगल", "google"],
  ["मैसेज", "message"], ["मेसेज", "message"], ["संदेश", "message"], ["खोलो", "kholo"], ["खोल दो", "kholo"], ["खोल", "kholo"],
  ["चालू करो", "chalu karo"], ["बंद करो", "band karo"], ["वापस", "wapas"], ["पीछे", "peeche"], ["नीचे", "neeche"], ["ऊपर", "upar"],
  ["स्क्रॉल", "scroll"], ["होम", "home"], ["स्क्रीन", "screen"], ["लिखो", "likho"], ["लिख दो", "likho"], ["टाइप", "type"],
  ["भेजो", "bhejo"], ["भेज दो", "bhejo"], ["सर्च", "search"], ["खोजो", "search karo"], ["ढूंढो", "search karo"],
  ["आवाज़", "volume"], ["आवाज", "volume"], ["वॉल्यूम", "volume"], ["कम", "kam"], ["ज़्यादा", "zyada"], ["ज्यादा", "zyada"],
  ["बढ़ाओ", "badhao"], ["बढ़ा", "badha"], ["लॉक", "lock"], ["करो", "karo"], ["कर दो", "kar do"], ["जाओ", "jao"], ["पर", "par"],
  ["में", "mein"], ["की", "ki"], ["का", "ka"], ["को", "ko"], ["चैट", "chat"], ["उसको", "usko"], ["उसे", "use"], ["इसको", "isko"],
  ["क्लिक", "click"], ["दबाओ", "dabao"], ["रुको", "ruko"], ["चुप", "chup"], ["वाईफ़ाई", "wifi"], ["वाईफाई", "wifi"],
  ["ब्लूटूथ", "bluetooth"], ["डिस्प्ले", "display"], ["हाँ", "haan"], ["हां", "haan"], ["जी", "ji"], ["नहीं", "nahi"], ["नही", "nahi"],
  ["टाइम", "time"], ["समय", "time"], ["तारीख", "date"], ["जोक", "joke"], ["चुटकुला", "joke"], ["हेलो", "hello"], ["नमस्ते", "namaste"],
];

const typos: [string, string][] = [
  ["whats app", "whatsapp"], ["whatsup", "whatsapp"], ["what's app", "whatsapp"], ["whatsaap", "whatsapp"], ["you tube", "youtube"],
  ["u tube", "youtube"], ["crome", "chrome"], ["kolo", "kholo"], ["khol do", "kholo"], ["khol de", "kholo"], ["kholdo", "kholo"],
  ["open karo", "kholo"], ["open kar", "kholo"], ["bhej de", "bhejo"], ["bhej do", "bhejo"], ["send kar do", "bhejo"], ["send karo", "bhejo"],
  ["send kar", "bhejo"], ["likh de", "likho"], ["likh do", "likho"], ["type karo", "likho"], ["type kar", "likho"], ["niche", "neeche"],
  ["oopar", "upar"], ["uper", "upar"], ["piche", "peeche"], ["vapas", "wapas"], ["wapis", "wapas"], ["volume kam kar do", "volume kam"],
  ["volume kam karo", "volume kam"], ["awaz", "volume"], ["aawaz", "volume"], ["jyada", "zyada"], ["badha do", "badhao"], ["tez karo", "badhao"],
];

export function normalize(input: string, wakeWord: string): string {
  let t = input.toLowerCase().trim();
  for (const [k, v] of devanagari) t = t.split(k).join(` ${v} `);
  t = t.replace(/[,.!?।"']/g, " ");
  const ww = wakeWord.toLowerCase().trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&") || "friday";
  t = t.replace(new RegExp(`^(hey |ok |okay |hi )?(${ww}|fraiday|fryday|frieday|फ्राइडे|फ्राईडे)\\b[, ]*`), "");
  for (const [k, v] of typos) t = t.split(k).join(v);
  return t.replace(/\s+/g, " ").trim();
}

export const isAffirmative = (t: string) =>
  /^(haan|haa|ha|han|hanji|ji haan|ji|yes|yeah|yep|ok|okay|theek hai|thik hai|sahi hai|bhejo|send|kar do|karo|confirm|confirmed|done|sure|go ahead|yes please)( .*)?$/.test(t.trim());
export const isNegative = (t: string) =>
  /^(nahi|nahin|na|no|nope|mat|cancel|rehne do|rahne do|ruko|chhod do|chod do|stop|don't|dont|mat bhejo)( .*)?$/.test(t.trim());

const appWords = ["whatsapp", "youtube", "chrome", "camera", "gallery", "calculator", "settings", "phone", "google", "maps", "gmail", "instagram", "facebook", "telegram", "spotify", "clock", "calendar", "contacts", "messages", "play store", "files"];

const cleanName = (s: string) => s.replace(/^(mere |mera |meri |my )/, "").replace(/ (bhai|ji|sir)$/, "").trim();
const cleanMessage = (s: string) => {
  let m = s.trim().replace(/^(ki |ke |ka |that |saying )/, "").replace(/ (message|msg|likh ke|likhke)$/, "").trim();
  if (["hay", "hai", "hii"].includes(m)) m = "Hi";
  return m.charAt(0).toUpperCase() + m.slice(1);
};
const m = (re: RegExp, t: string) => re.exec(t);

/** Offline Hindi/Hinglish/English intent parser. Returns null when it is not a device command. */
export function parseLocal(t: string, ctx: ConversationContext): FridayAction | null {
  if (!t) return null;
  let r: RegExpExecArray | null;

  if (/^(stop|ruko|chup|chup raho|quiet|be quiet|bas|rukja|ruk jao)$/.test(t)) return { type: "STOP" };

  // WhatsApp send w/ pronoun
  if ((r = m(/^(?:whatsapp (?:par|pe|mein|me) )?(?:usko|use|usse|unko|unhe|isko|ise|him|her|them) (?:ek |yeh |ye )?(.+?)(?: message| msg)? (?:bhejo|bhej|send|likho|likh|bhejna|bhejdo)$/, t)))
    return { type: "WHATSAPP_SEND_MESSAGE", recipient: ctx.lastRecipient, message: cleanMessage(r[1]) };
  if ((r = m(/^send (?:him|her|them) (?:a message )?(?:saying )?(.+)$/, t)))
    return { type: "WHATSAPP_SEND_MESSAGE", recipient: ctx.lastRecipient, message: cleanMessage(r[1]) };
  // "<name> ko <msg> bhejo"
  if ((r = m(/^(?:whatsapp (?:par|pe|mein|me) )?(.+?) ko (?:whatsapp (?:par|pe|mein|me) )?(?:ek |yeh |ye )?(.+?)(?: message| msg)? (?:bhejo|bhej|send|likho|bhejna|bhejdo)$/, t))) {
    const name = r[1].trim();
    if (!["whatsapp", "usko", "use"].includes(name)) return { type: "WHATSAPP_SEND_MESSAGE", recipient: cleanName(name), message: cleanMessage(r[2]) };
  }
  if ((r = m(/^(?:whatsapp )?(?:send|message|text) (.+?) to (.+)$/, t))) return { type: "WHATSAPP_SEND_MESSAGE", recipient: cleanName(r[2]), message: cleanMessage(r[1]) };
  if ((r = m(/^(?:whatsapp )?message (.+?) (?:saying|that|:) (.+)$/, t))) return { type: "WHATSAPP_SEND_MESSAGE", recipient: cleanName(r[1]), message: cleanMessage(r[2]) };
  // open chat
  if ((r = m(/^(?:whatsapp (?:par|pe|mein|me) )?(.+?) (?:ki|ka|ke) chat (?:kholo|open|dikhao|khol)$/, t))) return { type: "WHATSAPP_OPEN_CHAT", contact: cleanName(r[1]) };
  if ((r = m(/^(?:open|show) (?:whatsapp )?(?:chat (?:with|of) )?(.+?)(?:'s)? (?:whatsapp )?chat$/, t))) return { type: "WHATSAPP_OPEN_CHAT", contact: cleanName(r[1]) };
  if ((r = m(/^(?:open|show) (?:whatsapp )?chat (?:with|of) (.+)$/, t))) return { type: "WHATSAPP_OPEN_CHAT", contact: cleanName(r[1]) };
  if ((r = m(/^(.+?) (?:se baat karo|se baat karni hai|ko message karna hai)$/, t))) return { type: "WHATSAPP_OPEN_CHAT", contact: cleanName(r[1]) };

  // navigation
  if (/^(back|back jao|peeche|peeche jao|wapas|wapas jao|go back|back karo|piche jao)$/.test(t)) return { type: "BACK" };
  if (/^(home|home jao|home screen|home screen par jao|home screen pe jao|home par jao|home pe jao|go home|home karo)$/.test(t)) return { type: "HOME" };
  if (/^(neeche scroll(?: karo)?|scroll down|neeche karo|neeche jao|scroll neeche|page down)$/.test(t)) return { type: "SCROLL_DOWN" };
  if (/^(upar scroll(?: karo)?|scroll up|upar karo|upar jao|scroll upar|page up)$/.test(t)) return { type: "SCROLL_UP" };

  // volume
  if (/^(volume|sound|awaaz) (kam|down|ghatao|ghata do|low|kam karo)( .*)?$/.test(t) || t === "volume kam" || /^(decrease|lower|reduce) (the )?volume$/.test(t)) return { type: "VOLUME", direction: "down" };
  if (/^(volume|sound|awaaz) (zyada|up|badhao|badha do|tez|high|badha)( .*)?$/.test(t) || /^(increase|raise) (the )?volume$/.test(t)) return { type: "VOLUME", direction: "up" };
  if (/^(mute|volume mute|silent|silent karo|volume band|phone silent karo|mute karo|awaaz band karo)$/.test(t)) return { type: "VOLUME", direction: "mute" };

  // lock
  if (/^(phone lock(?: karo| kar do)?|screen lock(?: karo)?|lock (?:the )?(?:phone|screen)|lock karo|lock kar do|phone band karo|screen band karo)$/.test(t)) return { type: "LOCK_PHONE" };

  // settings
  if (/^(?:phone (?:ki|ka) )?(wifi|wi fi|wi-fi)(?: (?:ki|ka))? (?:settings? )?(?:kholo|open|dikhao|on karo|off karo)$/.test(t) || t.includes("wifi settings")) return { type: "OPEN_SETTINGS", section: "wifi" };
  if (t.includes("bluetooth")) return { type: "OPEN_SETTINGS", section: "bluetooth" };
  if (t.includes("display") || t.includes("brightness") || t.includes("screen settings")) return { type: "OPEN_SETTINGS", section: "display" };
  if (/^(?:phone (?:ki|ka|ke) )?settings? (?:kholo|open|dikhao|mein jao|me jao)$/.test(t) || t === "open settings" || t === "settings") return { type: "OPEN_SETTINGS", section: "general" };

  // type
  if ((r = m(/^(?:search box|box|text box|yahan|yaha|yahan par|isme|is mein|field)(?: mein| me| par| pe)? (.+?) (?:likho|likh|type|enter karo|daalo)$/, t))) return { type: "TYPE_TEXT", text: r[1].trim() };
  if ((r = m(/^(?:type|likho|write) (.+)$/, t))) return { type: "TYPE_TEXT", text: r[1].trim() };
  if ((r = m(/^(.+?) (?:likho|likh do)$/, t))) return { type: "TYPE_TEXT", text: r[1].trim() };

  // search
  if ((r = m(/^(?:google|internet|web|net) (?:par|pe|mein|me|par jake) (.+?) (?:search karo|search|dhundo|dhoondo|dhundho|khojo|search kar)$/, t))) return { type: "WEB_SEARCH", query: r[1].trim() };
  if ((r = m(/^(?:search|google|look up|search for|search karo) (.+)$/, t))) {
    const q = r[1].replace(/ search karo$/, "").replace(/ karo$/, "").trim();
    if (q) return { type: "WEB_SEARCH", query: q };
  }
  if ((r = m(/^(.+?) (?:google karo|search karo|dhundo|dhoondo)$/, t))) return { type: "WEB_SEARCH", query: r[1].trim() };

  // click
  if ((r = m(/^(.+?) (?:par|pe) (?:click|tap|dabao|press) ?(?:karo)?$/, t))) return { type: "CLICK_TEXT", text: r[1].trim() };
  if ((r = m(/^(?:click|tap|press)(?: on)? (.+?)(?: button)?$/, t))) return { type: "CLICK_TEXT", text: r[1].trim() };
  if ((r = m(/^(.+?) (?:button )?dabao$/, t))) return { type: "CLICK_TEXT", text: r[1].trim() };

  // open app
  if ((r = m(/^(?:open|launch|start|run) (.+?)(?: app| application)?$/, t))) return { type: "OPEN_APP", app: r[1].trim() };
  if ((r = m(/^(.+?)(?: app| application)? (?:kholo|chalu karo|chalao|on karo|start karo|launch karo|khol)$/, t))) return { type: "OPEN_APP", app: r[1].trim() };
  if (appWords.includes(t)) return { type: "OPEN_APP", app: t };
  return null;
}

const jokes = [
  "Teacher: Beta, homework kahan hai? Student: Sir, FRIDAY ne kaha offline hoon, kal karna!",
  "Programmer ki wife: Bazaar se ek doodh lana, aur agar ande hain to chhe le aana. Programmer chhe doodh le aaya.",
  "Why did the phone go to school? Because it wanted to be a smart-phone!",
  "Doctor: Aap roz 8 ghante sote hain? Patient: Haan, office mein 4 aur ghar mein 4.",
  "Mera Wi-Fi password 'incorrect' hai, taaki galat daalte hi phone bata de: password is incorrect!",
];

export function offlineAnswer(t: string, userName: string, assistantName: string): string | null {
  const now = new Date();
  if (/(time kya|kitne baje|what time|what's the time|samay kya|time batao|^time$)/.test(t) && t.length < 40) return `${userName}, abhi ${now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} baje hain.`;
  if (/(date|tareekh|aaj kya din|aaj kaun sa din|what day)/.test(t) && t.length < 40) return `Aaj ${now.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long", year: "numeric" })} hai.`;
  if (/(joke|chutkula|hasao|hasaao|funny)/.test(t)) return jokes[now.getSeconds() % jokes.length];
  if (/(india ki capital|india ka capital|capital of india|bharat ki rajdhani)/.test(t)) return `India ki capital New Delhi hai, ${userName}.`;
  if (/^(hello|hi|hey|namaste|namaskar)/.test(t) && t.length < 30) return `Hello ${userName}! Main ${assistantName} hoon. Boliye, kya karna hai?`;
  if (/(tum kaun ho|who are you|aap kaun|tumhara naam|your name)/.test(t)) return `Main ${assistantName} hoon, aapki personal AI assistant. Credit: Aditya.`;
  if (/(kaise ho|how are you|kya haal)/.test(t)) return `Main bilkul theek hoon ${userName}, aap batao kya karna hai?`;
  if (/(thank|shukriya|dhanyavad)/.test(t)) return `Hamesha hazir, ${userName}.`;
  return null;
}
