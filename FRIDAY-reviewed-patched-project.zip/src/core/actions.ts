export type FridayAction =
  | { type: "OPEN_APP"; app: string }
  | { type: "OPEN_URL"; url: string }
  | { type: "WEB_SEARCH"; query: string }
  | { type: "BACK" }
  | { type: "HOME" }
  | { type: "SCROLL_UP" }
  | { type: "SCROLL_DOWN" }
  | { type: "CLICK_TEXT"; text: string }
  | { type: "TYPE_TEXT"; text: string }
  | { type: "OPEN_SETTINGS"; section: "wifi" | "bluetooth" | "display" | "general" }
  | { type: "VOLUME"; direction: "up" | "down" | "mute" }
  | { type: "LOCK_PHONE" }
  | { type: "WHATSAPP_OPEN_CHAT"; contact: string }
  | { type: "WHATSAPP_SEND_MESSAGE"; recipient: string | null; message: string }
  | { type: "STOP" };

export interface ActionResult {
  ok: boolean;
  message: string;
  needsPermission?: boolean;
  needsConfirmation?: boolean;
}

export const requiresConfirmation = (a: FridayAction) => a.type === "WHATSAPP_SEND_MESSAGE";

export function describe(a: FridayAction): string {
  switch (a.type) {
    case "OPEN_APP": return `Open app: ${a.app}`;
    case "OPEN_URL": return `Open URL: ${a.url}`;
    case "WEB_SEARCH": return `Web search: ${a.query}`;
    case "CLICK_TEXT": return `Click '${a.text}'`;
    case "TYPE_TEXT": return `Type '${a.text}'`;
    case "OPEN_SETTINGS": return `Open settings: ${a.section}`;
    case "VOLUME": return `Volume ${a.direction}`;
    case "WHATSAPP_OPEN_CHAT": return `WhatsApp: open chat with ${a.contact}`;
    case "WHATSAPP_SEND_MESSAGE": return `WhatsApp: send "${a.message}" to ${a.recipient ?? "?"}`;
    default: return a.type;
  }
}

const MAX = 500;
const clean = (o: Record<string, unknown>, ...keys: string[]): string | null => {
  for (const k of keys) {
    const v = o[k];
    if (typeof v === "string" && v.trim()) return v.trim().slice(0, MAX);
  }
  return null;
};

/** Strict whitelist validator for AI-produced actions. Unknown → null. Never executes anything. */
export function validateAction(raw: unknown): FridayAction | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const type = String(o.type ?? "").trim().toUpperCase().replace(/ /g, "_");
  switch (type) {
    case "OPEN_APP": { const app = clean(o, "app", "name"); return app ? { type, app } : null; }
    case "OPEN_URL": { const url = clean(o, "url"); return url && /^https?:\/\//.test(url) ? { type, url } : null; }
    case "WEB_SEARCH": case "SEARCH": { const query = clean(o, "query", "text"); return query ? { type: "WEB_SEARCH", query } : null; }
    case "BACK": case "HOME": case "SCROLL_UP": case "SCROLL_DOWN": case "LOCK_PHONE": case "STOP": return { type } as FridayAction;
    case "CLICK_TEXT": case "CLICK": { const text = clean(o, "text", "target"); return text ? { type: "CLICK_TEXT", text } : null; }
    case "TYPE_TEXT": case "TYPE": { const text = clean(o, "text"); return text ? { type: "TYPE_TEXT", text } : null; }
    case "OPEN_SETTINGS": {
      const s = (clean(o, "section") ?? "general").toLowerCase();
      return { type, section: (["wifi", "bluetooth", "display", "general"].includes(s) ? s : "general") as "wifi" | "bluetooth" | "display" | "general" };
    }
    case "VOLUME": {
      const d = (clean(o, "direction") ?? "").toLowerCase();
      return ["up", "down", "mute"].includes(d) ? { type, direction: d as "up" | "down" | "mute" } : null;
    }
    case "WHATSAPP_OPEN_CHAT": { const contact = clean(o, "contact", "recipient"); return contact ? { type, contact } : null; }
    case "WHATSAPP_SEND_MESSAGE": {
      const message = clean(o, "message", "text");
      return message ? { type, recipient: clean(o, "recipient", "contact"), message } : null;
    }
    default: return null;
  }
}
