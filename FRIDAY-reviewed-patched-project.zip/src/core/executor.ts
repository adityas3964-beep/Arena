import type { ActionResult, FridayAction } from "./actions";
import type { ConversationContext } from "./context";

/**
 * Browser executor. Does what a web page genuinely can (open apps/sites via URL schemes & deep links,
 * scroll, history back, type into FRIDAY's own input, prepare WhatsApp messages via wa.me) and
 * reports honestly what it cannot (system volume, lock screen, accessibility clicks on other apps).
 */
const appLinks: Record<string, string> = {
  whatsapp: "https://web.whatsapp.com/", youtube: "https://www.youtube.com/", chrome: "https://www.google.com/",
  google: "https://www.google.com/", gmail: "https://mail.google.com/", maps: "https://maps.google.com/",
  instagram: "https://www.instagram.com/", facebook: "https://www.facebook.com/", telegram: "https://web.telegram.org/",
  spotify: "https://open.spotify.com/", calendar: "https://calendar.google.com/", "play store": "https://play.google.com/",
  calculator: "https://www.google.com/search?q=calculator", gallery: "https://photos.google.com/", photos: "https://photos.google.com/",
};

export interface ExecutorDeps {
  typeIntoInput: (text: string) => void;
  openInput: () => boolean;
  scrollBy: (dy: number) => boolean;
}

function openUrl(url: string, okMsg: string): ActionResult {
  const w = window.open(url, "_blank", "noopener");
  return w ? { ok: true, message: okMsg } : { ok: false, message: "Browser ne popup block kar diya. Allow popups aur dobara try karein." };
}

export async function executeWeb(a: FridayAction, ctx: ConversationContext, deps: ExecutorDeps): Promise<ActionResult> {
  switch (a.type) {
    case "OPEN_APP": {
      const key = a.app.toLowerCase().replace(/ app$/, "").trim();
      const href = appLinks[key];
      if (!href) return { ok: false, message: `'${a.app}' web se launch nahi ho sakta (native Android build mein installed apps khulte hain).` };
      const r = openUrl(href, `${a.app} khol diya (web).`);
      if (r.ok) ctx.currentApp = key;
      return r;
    }
    case "OPEN_URL": return openUrl(a.url, "Link khol diya.");
    case "WEB_SEARCH": return openUrl("https://www.google.com/search?q=" + encodeURIComponent(a.query), `'${a.query}' Google par search kar rahi hoon.`);
    case "BACK": if (window.history.length > 1) { window.history.back(); return { ok: true, message: "Back." } } return { ok: false, message: "Browser history mein peeche jaane ko kuch nahi." };
    case "HOME": window.scrollTo({ top: 0, behavior: "smooth" }); return { ok: true, message: "Home (top of dashboard)." };
    case "SCROLL_DOWN": return deps.scrollBy(window.innerHeight * 0.7) ? { ok: true, message: "Neeche scroll kiya." } : { ok: false, message: "Scroll nahi ho paya." };
    case "SCROLL_UP": return deps.scrollBy(-window.innerHeight * 0.7) ? { ok: true, message: "Upar scroll kiya." } : { ok: false, message: "Scroll nahi ho paya." };
    case "CLICK_TEXT": {
      const q = a.text.toLowerCase();
      const els = Array.from(document.querySelectorAll<HTMLElement>("button, a, [role=button]"));
      const el = els.find(e => e.innerText.trim().toLowerCase() === q) ?? els.find(e => e.innerText.toLowerCase().includes(q));
      if (!el) return { ok: false, message: `'${a.text}' naam ka button is screen par nahi mila.` };
      el.click(); return { ok: true, message: `'${a.text}' par click kiya.` };
    }
    case "TYPE_TEXT": deps.openInput(); deps.typeIntoInput(a.text); return { ok: true, message: `'${a.text}' input box mein likh diya.` };
    case "OPEN_SETTINGS": return { ok: false, message: `Web version se phone ki ${a.section} settings nahi khul saktin — native Android build mein yeh Intent se khulti hain.`, needsPermission: true };
    case "VOLUME": return { ok: false, message: "Browser system volume control nahi kar sakta (Android build mein AudioManager use hota hai).", needsPermission: true };
    case "LOCK_PHONE": return { ok: false, message: "Web se phone lock possible nahi (Android build: Device Admin force-lock).", needsPermission: true };
    case "WHATSAPP_OPEN_CHAT": {
      ctx.lastRecipient = a.contact; ctx.currentApp = "whatsapp";
      const r = openUrl("https://web.whatsapp.com/", `WhatsApp khol diya — '${a.contact}' ki chat web se auto-open nahi ho sakti; naam yaad rakh liya.`);
      return { ok: r.ok, message: r.message };
    }
    case "WHATSAPP_SEND_MESSAGE": {
      const recipient = a.recipient ?? ctx.lastRecipient;
      if (!recipient) return { ok: false, message: "Kisko bhejna hai? Pehle contact ka naam bataiye." };
      ctx.lastRecipient = recipient; ctx.lastMessage = a.message;
      const r = openUrl("https://wa.me/?text=" + encodeURIComponent(a.message), `Message "${a.message}" WhatsApp mein ready hai — ${recipient} select karke aap Send dabayein. (Web version actual send verify nahi kar sakta.)`);
      return { ok: false, message: r.ok ? r.message : r.message, needsConfirmation: false };
    }
    case "STOP": return { ok: true, message: "Ruk gayi." };
  }
}
