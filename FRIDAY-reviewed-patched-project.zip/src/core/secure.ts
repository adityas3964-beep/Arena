/**
 * Browser analogue of Android-Keystore-backed storage: a non-extractable AES-GCM CryptoKey
 * is kept in IndexedDB (the raw key bytes are never readable by JS), and the API key is
 * stored in localStorage only as ciphertext. Falls back to plain storage if WebCrypto/IDB
 * are unavailable (reported honestly through `secureMode`).
 */
const DB = "friday-secure", STORE = "keys", KEY_ID = "master";
const CIPHER_KEY = "friday.apikey.enc";

export let secureMode: "KEYSTORE" | "PLAIN" | "UNKNOWN" = "UNKNOWN";

function idb(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}
function tx<T>(db: IDBDatabase, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return new Promise((res, rej) => {
    const r = fn(db.transaction(STORE, mode).objectStore(STORE));
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
}

async function masterKey(): Promise<CryptoKey | null> {
  try {
    const db = await idb();
    let key = await tx<CryptoKey | undefined>(db, "readonly", s => s.get(KEY_ID) as IDBRequest<CryptoKey | undefined>);
    if (!key) {
      key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
      await tx(db, "readwrite", s => s.put(key, KEY_ID));
    }
    secureMode = "KEYSTORE";
    return key;
  } catch { secureMode = "PLAIN"; return null; }
}

const b64 = (b: ArrayBuffer) => btoa(String.fromCharCode(...new Uint8Array(b)));
const unb64 = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0));

export async function saveApiKey(apiKey: string): Promise<void> {
  if (!apiKey) { localStorage.removeItem(CIPHER_KEY); return; }
  const key = await masterKey();
  if (!key) { localStorage.setItem(CIPHER_KEY, "plain:" + apiKey); return; }
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(apiKey));
  localStorage.setItem(CIPHER_KEY, `gcm:${b64(iv.buffer)}:${b64(ct)}`);
}

export async function loadApiKey(): Promise<string> {
  const v = localStorage.getItem(CIPHER_KEY);
  if (!v) { await masterKey(); return ""; }
  if (v.startsWith("plain:")) { secureMode = "PLAIN"; return v.slice(6); }
  const [, ivs, cts] = v.split(":");
  const key = await masterKey();
  if (!key) return "";
  try {
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(ivs) }, key, unb64(cts));
    return new TextDecoder().decode(pt);
  } catch { return ""; }
}

export const hasSavedKey = () => !!localStorage.getItem(CIPHER_KEY);
