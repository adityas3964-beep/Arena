import type { FridayAction } from "./actions";
import { describe } from "./actions";

export interface AiMessage { role: "user" | "assistant"; content: string }

export class ConversationContext {
  lastRecipient: string | null = null;
  lastMessage: string | null = null;
  currentApp: string | null = null;
  pendingAction: FridayAction | null = null;
  private transcript: AiMessage[] = [];

  remember(role: AiMessage["role"], content: string) {
    this.transcript.push({ role, content: content.slice(0, 1500) });
    while (this.transcript.length > 12) this.transcript.shift();
  }
  history() { return [...this.transcript]; }
  clearAll() { this.lastRecipient = this.lastMessage = this.currentApp = this.pendingAction = null; this.transcript = []; }
  summary() {
    return `last_recipient=${this.lastRecipient ?? "none"}, last_message=${this.lastMessage ?? "none"}, current_app=${this.currentApp ?? "unknown"}, pending_action=${this.pendingAction ? describe(this.pendingAction) : "none"}`;
  }
}
