import { validateAction, type FridayAction } from "./actions";
import type { AiMessage } from "./context";

export const DEFAULT_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";
export const DEFAULT_MODEL = "llama-3.3-70b-versatile";

export interface AiReply { text: string; actions: FridayAction[]; model: string }

export function systemPrompt(assistantName: string, userName: string, ctx: string) {
  return `You are ${assistantName}, a personal AI voice assistant running inside an Android app. Address the user as "${userName}".
The user speaks Hindi, Hinglish (Hindi in Latin letters) or English. ALWAYS answer in the same language/style the user used. Keep spoken replies short (1-3 sentences) because they are read aloud.

You can control the phone ONLY by returning structured actions. Respond with ONLY a JSON object, no markdown:
{"reply": "<what you say to the user>", "actions": [ ...zero or more actions... ]}

Allowed actions (no other types exist):
{"type":"OPEN_APP","app":"WhatsApp"}
{"type":"OPEN_URL","url":"https://..."}
{"type":"WEB_SEARCH","query":"..."}
{"type":"BACK"} {"type":"HOME"} {"type":"SCROLL_UP"} {"type":"SCROLL_DOWN"}
{"type":"CLICK_TEXT","text":"<visible button label>"}
{"type":"TYPE_TEXT","text":"<text to type into the focused field>"}
{"type":"OPEN_SETTINGS","section":"wifi|bluetooth|display|general"}
{"type":"VOLUME","direction":"up|down|mute"}
{"type":"LOCK_PHONE"}
{"type":"WHATSAPP_OPEN_CHAT","contact":"<name>"}
{"type":"WHATSAPP_SEND_MESSAGE","recipient":"<name>","message":"<text>"}

Rules:
- Use actions only when the user asks to DO something on the phone. For questions/jokes/chat, return an empty actions list.
- The app ALWAYS asks the user to confirm before any WHATSAPP_SEND_MESSAGE is executed. Never claim a message was sent; say you are preparing it.
- If "usko/use/unko" refers to a previous recipient, use last_recipient from context. If the recipient is unknown or ambiguous, ask instead of guessing.
- Never invent actions you cannot perform. Never include code.
Context: ${ctx}`;
}

export function parseReply(content: string, model: string): AiReply {
  let raw = content.trim();
  if (raw.startsWith("```")) raw = raw.replace(/^```json?/, "").replace(/```$/, "").trim();
  const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
  if (s >= 0 && e > s) {
    try {
      const obj = JSON.parse(raw.slice(s, e + 1));
      if (obj && typeof obj === "object" && ("reply" in obj || "actions" in obj)) {
        const actions: FridayAction[] = [];
        if (Array.isArray(obj.actions)) for (const a of obj.actions.slice(0, 5)) { const v = validateAction(a); if (v) actions.push(v); }
        return { text: String(obj.reply ?? "").trim(), actions, model };
      }
    } catch { /* fall through to plain text */ }
  }
  return { text: content, actions: [], model };
}

async function post(endpoint: string, apiKey: string, body: unknown, timeoutMs = 45000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
    const res = await fetch(endpoint, { method: "POST", headers, body: JSON.stringify(body), signal: ctrl.signal });
    const text = await res.text();
    return { status: res.status, text };
  } finally { clearTimeout(timer); }
}

const extractError = (text: string) => {
  try { const o = JSON.parse(text); return o?.error?.message || o?.message || text.slice(0, 160); } catch { return text.slice(0, 160) || "no response body"; }
};

/** Real request. Returns the real HTTP outcome. The key is never logged. */
export async function testConnection(endpoint: string, apiKey: string, model: string): Promise<{ ok: boolean; detail: string }> {
  if (!/^https?:\/\//.test(endpoint)) return { ok: false, detail: "Endpoint URL invalid hai" };
  try {
    const { status, text } = await post(endpoint, apiKey, { model, max_tokens: 8, messages: [{ role: "user", content: "Reply with OK" }] }, 20000);
    if (status >= 200 && status < 300) {
      let used = model; try { used = JSON.parse(text).model || model; } catch { /* ignore */ }
      return { ok: true, detail: `HTTP ${status} OK · model: ${used}` };
    }
    return { ok: false, detail: `HTTP ${status} · ${extractError(text)}` };
  } catch (e) {
    const msg = e instanceof Error ? (e.name === "AbortError" ? "timeout" : e.message) : String(e);
    return { ok: false, detail: `Network/CORS error: ${msg}` };
  }
}

export async function chat(endpoint: string, apiKey: string, model: string, system: string, history: AiMessage[], user: string): Promise<AiReply> {
  const { status, text } = await post(endpoint, apiKey, {
    model, temperature: 0.4, max_tokens: 600,
    messages: [{ role: "system", content: system }, ...history, { role: "user", content: user }],
  });
  if (status < 200 || status >= 300) throw new Error(`HTTP ${status} · ${extractError(text)}`);
  const root = JSON.parse(text);
  const content: string = root?.choices?.[0]?.message?.content ?? "";
  return parseReply(content, root?.model ?? model);
}
