# FRIDAY – Your Personal AI Assistant

> Whole credit goes to Aditya. © 2026 Aditya. All rights reserved.

This repository contains **two deliverables**:

| Path | What it is | Status |
|---|---|---|
| `android/` | Complete native Android project (Kotlin · Jetpack Compose · `com.aditya.friday`) – AI client, command dispatcher, conversation context, Accessibility automation (incl. WhatsApp flow with explicit confirmation), SpeechRecognizer, TextToSpeech, wake-word foreground service, Keystore-encrypted settings, Device Admin (force-lock only), Splash/Home/Log/Profile/Settings UI | **Source complete. NOT compiled by the author** – the authoring sandbox had no JDK/Android SDK. Build it with the GitHub Actions workflow or Android Studio (see `android/README.md`). |
| `src/` (this web app) | A runnable **web build of FRIDAY** reproducing the three reference screens with the real brain: Web Speech API recognition (hi-IN/en-IN/en-US), speech synthesis, Groq/OpenAI-compatible client with a genuine Test Connection, the same Hinglish command parser, conversation context, confirmation flow, encrypted key storage | **Built and logic-tested here** (`npm run build` passes; 22 parser/validator cases pass). |
| `.github/workflows/android-build.yml` | CI that runs the unit tests, assembles `app-debug.apk`, verifies it with `aapt dump badging`, and uploads it as the `friday-debug-apk` artifact | Ready – runs on push / manual dispatch. |
| `public/friday-android-source.zip` | The Android project zipped for download (also served next to the web app) | Generated. |

## Honest limitations of this delivery
- **No APK is included.** It is not possible to compile Kotlin/Android in the environment that produced this code. The workflow builds it on GitHub; the first run may reveal small compile errors to fix since the Kotlin code has never been through a compiler.
- Web build cannot do what only a native app can: launch installed apps, change system volume, open phone settings, lock the phone, or press Send inside WhatsApp. Those paths report "N/A in web" / fail honestly instead of pretending. WhatsApp messages are prepared via `wa.me` for you to send manually.
- Browser speech recognition (Chrome/Edge) is cloud-based and needs internet; there is no always-on wake word in a browser and none is faked.

See `android/README.md` for installation, API configuration, Accessibility setup, the build/testing report and the full list of known limitations.
