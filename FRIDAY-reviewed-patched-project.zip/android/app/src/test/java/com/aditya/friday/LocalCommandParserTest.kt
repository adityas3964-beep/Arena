package com.aditya.friday

import com.aditya.friday.ai.AiClient
import com.aditya.friday.core.ConversationContext
import com.aditya.friday.core.FridayAction
import com.aditya.friday.core.LocalCommandParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalCommandParserTest {

    private fun parse(text: String, ctx: ConversationContext = ConversationContext()): FridayAction? =
        LocalCommandParser.parse(LocalCommandParser.normalize(text, "friday"), ctx)

    @Test fun opensApps() {
        assertEquals(FridayAction.OpenApp("youtube"), parse("FRIDAY, YouTube kholo."))
        assertEquals(FridayAction.OpenApp("whatsapp"), parse("WhatsApp open karo"))
        assertEquals(FridayAction.OpenApp("chrome"), parse("Chrome kholo"))
        assertEquals(FridayAction.OpenApp("camera"), parse("कैमरा खोलो"))
    }

    @Test fun settingsAndNavigation() {
        assertEquals(FridayAction.OpenSettings("general"), parse("Phone ki settings kholo"))
        assertEquals(FridayAction.OpenSettings("wifi"), parse("wifi settings kholo"))
        assertEquals(FridayAction.Volume("down"), parse("Volume kam kar do"))
        assertEquals(FridayAction.Back, parse("Back jao"))
        assertEquals(FridayAction.Home, parse("Home screen par jao"))
        assertEquals(FridayAction.ScrollDown, parse("Neeche scroll karo"))
        assertEquals(FridayAction.ScrollUp, parse("Upar scroll karo"))
        assertEquals(FridayAction.TypeText("hello"), parse("Search box mein Hello likho"))
        assertEquals(FridayAction.WebSearch("best phones"), parse("Google par best phones search karo"))
    }

    @Test fun whatsAppFlowWithContext() {
        val ctx = ConversationContext()
        assertEquals(FridayAction.WhatsAppOpenChat("kartavya"), parse("Kartavya ki chat kholo", ctx))
        ctx.setRecipient("kartavya")
        val send = parse("Usko Hi message bhejo", ctx)
        assertTrue(send is FridayAction.WhatsAppSendMessage)
        send as FridayAction.WhatsAppSendMessage
        assertEquals("kartavya", send.recipient)
        assertEquals("Hi", send.message)
        assertTrue(send.requiresConfirmation)
    }

    @Test fun pronounWithoutContextHasNoRecipient() {
        val send = parse("usko hello bhejo") as FridayAction.WhatsAppSendMessage
        assertNull(send.recipient)
    }

    @Test fun questionsAreNotActions() {
        assertNull(parse("India ki capital kya hai?"))
        assertNull(parse("Ek funny joke sunao"))
        assertTrue(LocalCommandParser.offlineAnswer("india ki capital kya hai", "Boss", "FRIDAY")!!.contains("New Delhi"))
    }

    @Test fun confirmationWords() {
        assertTrue(LocalCommandParser.isAffirmative("haan"))
        assertTrue(LocalCommandParser.isAffirmative(LocalCommandParser.normalize("हाँ", "friday")))
        assertTrue(LocalCommandParser.isNegative("nahi"))
    }

    @Test fun aiReplyParsing() {
        val r = AiClient.parseReply("""```json
{"reply":"Boss, WhatsApp khol rahi hoon.","actions":[{"type":"OPEN_APP","app":"WhatsApp"},{"type":"RUN_CODE","code":"rm -rf"}]}
```""", "m")
        assertEquals("Boss, WhatsApp khol rahi hoon.", r.text)
        assertEquals(1, r.actions.size)       // unknown RUN_CODE rejected by validator
        assertEquals(FridayAction.OpenApp("WhatsApp"), r.actions[0])
        val plain = AiClient.parseReply("New Delhi is the capital of India.", "m")
        assertEquals(0, plain.actions.size)
    }
}
