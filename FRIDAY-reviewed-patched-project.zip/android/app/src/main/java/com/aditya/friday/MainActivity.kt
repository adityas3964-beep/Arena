package com.aditya.friday

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.aditya.friday.ui.AssistantViewModel
import com.aditya.friday.ui.FridayApp
import com.aditya.friday.ui.theme.FridayTheme

class MainActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refreshStatuses() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FridayTheme {
                FridayApp(vm = vm, onRequestMic = { requestMic() })
            }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        vm.refreshStatuses()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_WAKE, false) == true) {
            intent.removeExtra(EXTRA_WAKE)
            vm.onWakeWordDetected()
        }
    }

    private fun requestMic() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(perms.toTypedArray())
    }

    companion object {
        const val EXTRA_WAKE = "friday.wake"
        const val EXTRA_WAKE_TEXT = "friday.wake.text"
    }
}
