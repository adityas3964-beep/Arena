package com.aditya.friday.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import java.util.Locale

class AppLauncher(private val context: Context) {

    private val known: Map<String, List<String>> = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "youtube" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome"),
        "google" to listOf("com.google.android.googlequicksearchbox"),
        "gmail" to listOf("com.google.android.gm"),
        "maps" to listOf("com.google.android.apps.maps"),
        "calculator" to listOf("com.google.android.calculator", "com.android.calculator2", "com.miui.calculator", "com.sec.android.app.popupcalculator", "com.coloros.calculator", "com.oneplus.calculator"),
        "gallery" to listOf("com.google.android.apps.photos", "com.miui.gallery", "com.sec.android.gallery3d", "com.coloros.gallery3d", "com.oneplus.gallery", "com.android.gallery3d"),
        "photos" to listOf("com.google.android.apps.photos"),
        "camera" to listOf("com.google.android.GoogleCamera", "com.android.camera", "com.sec.android.app.camera", "com.oppo.camera", "com.oneplus.camera", "com.android.camera2"),
        "phone" to listOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer"),
        "dialer" to listOf("com.google.android.dialer", "com.android.dialer"),
        "contacts" to listOf("com.google.android.contacts", "com.android.contacts", "com.samsung.android.app.contacts"),
        "messages" to listOf("com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging"),
        "settings" to listOf("com.android.settings"),
        "instagram" to listOf("com.instagram.android"),
        "facebook" to listOf("com.facebook.katana"),
        "telegram" to listOf("org.telegram.messenger"),
        "spotify" to listOf("com.spotify.music"),
        "play store" to listOf("com.android.vending"),
        "playstore" to listOf("com.android.vending"),
        "clock" to listOf("com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage"),
        "calendar" to listOf("com.google.android.calendar", "com.android.calendar"),
        "files" to listOf("com.google.android.apps.nbu.files", "com.android.documentsui")
    )

    /** Returns (success, humanMessage). Never claims success unless startActivity went through. */
    fun launch(appName: String): Pair<Boolean, String> {
        val key = appName.lowercase(Locale.ROOT).trim()
            .removeSuffix(" app").removeSuffix(" application").trim()
        val pm = context.packageManager

        // 1. known packages
        known[key]?.forEach { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                return start(intent, key)
            }
        }
        // 2. camera via system intent
        if (key == "camera") {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            if (intent.resolveActivity(pm) != null) return start(intent, key)
        }
        // 3. match any installed launcher app by label
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        val labelled = activities.map { it to it.loadLabel(pm).toString().lowercase(Locale.ROOT) }
        val match = labelled.firstOrNull { it.second == key }
            ?: labelled.firstOrNull { it.second.startsWith(key) }
            ?: labelled.firstOrNull { it.second.contains(key) && key.length >= 4 }
        if (match != null) {
            val info = match.first.activityInfo
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(info.packageName, info.name)
            return start(intent, match.second)
        }
        return false to "'$appName' naam ka app is phone par nahi mila."
    }

    fun isInstalled(appName: String): Boolean {
        val key = appName.lowercase(Locale.ROOT)
        return known[key]?.any { context.packageManager.getLaunchIntentForPackage(it) != null } == true
    }

    private fun start(intent: Intent, label: String): Pair<Boolean, String> = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        context.startActivity(intent)
        true to "${label.replaceFirstChar { it.titlecase(Locale.ROOT) }} khol diya."
    } catch (e: Exception) {
        false to "$label open nahi ho paya: ${e.javaClass.simpleName}"
    }
}
