package com.aditya.friday.core

import com.aditya.friday.ai.AiMessage

/**
 * Short-lived conversation memory: last recipient / message / current app / pending
 * confirmation and a bounded chat transcript for the AI.
 */
class ConversationContext {
    var lastRecipient: String? = null
        private set
    var lastMessage: String? = null
        private set
    var currentApp: String? = null
    var pendingAction: FridayAction? = null
        private set

    private val transcript = ArrayDeque<AiMessage>()

    fun setRecipient(name: String) {
        lastRecipient = name
    }

    fun setMessage(text: String) {
        lastMessage = text
    }

    fun setPending(action: FridayAction) {
        pendingAction = action
    }

    fun clearPending() {
        pendingAction = null
    }

    fun clearAll() {
        lastRecipient = null
        lastMessage = null
        currentApp = null
        pendingAction = null
        transcript.clear()
    }

    fun remember(role: String, content: String) {
        transcript.addLast(AiMessage(role, content.take(1500)))
        while (transcript.size > 12) transcript.removeFirst()
    }

    fun history(): List<AiMessage> = transcript.toList()

    /** Hindi/Hinglish pronoun check: "usko", "use", "unko" ... refer to the previous recipient. */
    fun isPronounReference(text: String): Boolean {
        val t = " ${text.lowercase()} "
        return listOf(" usko ", " use ", " usse ", " unko ", " unhe ", " isko ", " ise ", " उसको ", " उसे ", " इसको ", " उनको ", " him ", " her ", " them ")
            .any { t.contains(it) }
    }

    fun summary(): String = buildString {
        append("last_recipient=").append(lastRecipient ?: "none")
        append(", last_message=").append(lastMessage ?: "none")
        append(", current_app=").append(currentApp ?: "unknown")
        append(", pending_action=").append(pendingAction?.describe() ?: "none")
    }
}
