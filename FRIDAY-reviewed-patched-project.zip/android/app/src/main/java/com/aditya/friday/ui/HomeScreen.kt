package com.aditya.friday.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aditya.friday.ui.components.HudButton
import com.aditya.friday.ui.components.HudPanel
import com.aditya.friday.ui.components.HudTextField
import com.aditya.friday.ui.components.StatusRow
import com.aditya.friday.ui.theme.Amber
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.ElectricBlue
import com.aditya.friday.ui.theme.Green
import com.aditya.friday.ui.theme.Red
import com.aditya.friday.ui.theme.TextDim
import com.aditya.friday.ui.theme.TextPrimary
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HomeScreen(vm: AssistantViewModel, state: UiState, onRequestMic: () -> Unit) {
    var manual by remember { mutableStateOf("") }
    val scroll = rememberScrollState()

    Column(Modifier.fillMaxWidth().verticalScroll(scroll).padding(horizontal = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(10.dp))
        AiCore(state.status, state.level, Modifier.fillMaxWidth().height(300.dp))
        Spacer(Modifier.height(10.dp))
        val statusText = when (state.status) {
            CoreStatus.IDLE -> if (state.statusDetail.isNotBlank()) state.statusDetail else "STANDBY"
            CoreStatus.LISTENING -> if (state.statusDetail.isNotBlank()) state.statusDetail else "LISTENING"
            CoreStatus.THINKING -> if (state.statusDetail.isNotBlank()) state.statusDetail else "THINKING"
            CoreStatus.SPEAKING -> "SPEAKING"
        }
        Text(statusText.uppercase(), style = MaterialTheme.typography.titleMedium, color = when (state.status) {
            CoreStatus.IDLE -> TextDim; CoreStatus.LISTENING -> Green; CoreStatus.THINKING -> Amber; CoreStatus.SPEAKING -> Cyan
        })
        if (state.partial.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(state.partial, style = MaterialTheme.typography.bodySmall, color = TextDim)
        }
        Spacer(Modifier.height(12.dp))
        Waveform(active = state.status != CoreStatus.IDLE, level = state.level, speaking = state.status == CoreStatus.SPEAKING)
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val listeningAuto = state.recognitionMode == RecognitionMode.AUTO && state.status != CoreStatus.IDLE
            HudButton(
                text = if (listeningAuto) "LISTENING…" else "START\nLISTENING",
                onClick = { if (state.micGranted) vm.startListening() else onRequestMic() },
                modifier = Modifier.weight(1.1f),
                accent = if (listeningAuto) Green else TextDim
            )
            val pttActive = state.recognitionMode == RecognitionMode.PUSH_TO_TALK && state.status == CoreStatus.LISTENING
            val pttColor = if (pttActive) Cyan else TextDim
            Box(
                Modifier
                    .weight(1.1f)
                    .background(if (pttActive) Cyan.copy(alpha = 0.12f) else Color.Transparent, RoundedCornerShape(6.dp))
                    .border(1.5.dp, pttColor, RoundedCornerShape(6.dp))
                    .pointerInput(state.micGranted) {
                        detectTapGestures(onPress = {
                            if (!state.micGranted) { onRequestMic(); return@detectTapGestures }
                            vm.pushToTalkStart()
                            tryAwaitRelease()
                            vm.pushToTalkEnd()
                        })
                    }
                    .padding(horizontal = 12.dp, vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(if (pttActive) "RELEASE TO SEND" else "PUSH TO TALK", style = MaterialTheme.typography.labelLarge, color = pttColor, textAlign = TextAlign.Center)
            }
            HudButton("STOP", onClick = { vm.stop() }, modifier = Modifier.weight(0.8f), accent = Red, filled = true)
        }
        if (!state.micGranted) {
            Spacer(Modifier.height(8.dp))
            Text("Microphone permission required — tap Start Listening to grant.", style = MaterialTheme.typography.bodySmall, color = Amber)
        }
        Spacer(Modifier.height(14.dp))

        // manual text fallback
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudTextField("Type a command (fallback)", manual, { manual = it }, Modifier.weight(1f), placeholder = "WhatsApp kholo / Kartavya ki chat kholo")
            Spacer(Modifier.width(8.dp))
            HudButton("SEND", onClick = { if (manual.isNotBlank()) { vm.submitText(manual); manual = "" } }, accent = Cyan, filled = true, modifier = Modifier.padding(top = 20.dp))
        }
        Spacer(Modifier.height(14.dp))

        HudPanel("Assistant") {
            Text("HEARD", style = MaterialTheme.typography.labelSmall, color = TextDim)
            Text(state.heard.ifBlank { "—" }, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            Spacer(Modifier.height(10.dp))
            Text("RESPONSE" + if (state.responseEngine.isNotBlank()) " [${state.responseEngine}]" else "", style = MaterialTheme.typography.labelSmall, color = TextDim)
            Text(state.response.ifBlank { "Standing by, ${state.userName}." }, style = MaterialTheme.typography.bodyLarge, color = Cyan)
            if (state.pendingDescription != null) {
                Spacer(Modifier.height(12.dp))
                Text("PENDING: ${state.pendingDescription}", style = MaterialTheme.typography.bodySmall, color = Amber)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HudButton("HAAN · CONFIRM", onClick = { vm.confirmPending() }, Modifier.weight(1f), accent = Green, filled = true)
                    HudButton("NAHI · CANCEL", onClick = { vm.denyPending() }, Modifier.weight(1f), accent = Red)
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        HudPanel("Recent Commands") {
            if (state.recent.isEmpty()) Text("No commands yet.", style = MaterialTheme.typography.bodyMedium, color = TextDim)
            state.recent.take(5).forEach { Text("›  $it", style = MaterialTheme.typography.bodyMedium, color = TextPrimary, modifier = Modifier.padding(vertical = 2.dp)) }
        }
        Spacer(Modifier.height(14.dp))

        HudPanel("Service Status") {
            StatusRow("Recognition mode", state.recognitionMode.name.replace('_', ' '), if (state.recognitionMode == RecognitionMode.OFF) TextDim else Green)
            StatusRow("Last engine used", state.lastEngine, if (state.lastEngine == "—") TextDim else Cyan)
            StatusRow("Online AI", if (!state.onlineAiEnabled) "OFF" else if (state.networkAvailable) "READY" else "NO INTERNET", if (!state.onlineAiEnabled) TextDim else if (state.networkAvailable) Green else Amber)
            StatusRow("Offline mode", if (state.recognizerAvailable) "READY" else "NO RECOGNIZER", if (state.recognizerAvailable) Green else Red)
            StatusRow("Wake word (${state.wakeWord})", if (state.wakeWordRunning) "RUNNING" else "NOT RUNNING", if (state.wakeWordRunning) Green else Amber)
            StatusRow("Microphone permission", if (state.micGranted) "GRANTED" else "NEEDS PERMISSION", if (state.micGranted) Green else Red)
            StatusRow("Accessibility", if (state.accessibilityEnabled) "ENABLED" else "NEEDS PERMISSION", if (state.accessibilityEnabled) Green else Amber)
            StatusRow("Last action result", state.lastActionResult, when (state.lastActionResult) { "ACTION SUCCESS" -> Green; "ACTION FAILED" -> Red; "NEEDS CONFIRMATION", "NEEDS PERMISSION" -> Amber; else -> TextDim })
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun AiCore(status: CoreStatus, level: Float, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "core")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "rot")
    val rot2 by inf.animateFloat(360f, 0f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rot2")
    val pulse by inf.animateFloat(0.88f, 1.12f, infiniteRepeatable(tween(if (status == CoreStatus.IDLE) 2200 else 900), RepeatMode.Reverse), label = "pulse")
    val accent = when (status) { CoreStatus.LISTENING -> Green; CoreStatus.THINKING -> Amber; else -> Cyan }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        // glow
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.35f), Color.Transparent), c, r * 0.6f * pulse), r * 0.6f * pulse, c)
        // inner disc
        drawCircle(Color(0xFF0C2A3C), r * 0.42f, c)
        drawCircle(Cyan, r * 0.42f, c, style = Stroke(3.dp.toPx()))
        // level ring
        if (level > 0.02f) drawCircle(ElectricBlue.copy(alpha = 0.55f), r * (0.44f + 0.25f * level), c, style = Stroke(2.dp.toPx()))
        // ticks
        rotate(rot, c) {
            for (i in 0 until 72) {
                val a = Math.toRadians(i * 5.0)
                val long = i % 6 == 0
                val inner = r * 0.50f
                val outer = if (long) r * 0.72f else r * 0.62f
                val alpha = if (i % 3 == 0) 0.95f else 0.4f
                val col = if (i % 9 == 0) ElectricBlue else Cyan
                drawLine(col.copy(alpha = alpha),
                    Offset(c.x + inner * cos(a).toFloat(), c.y + inner * sin(a).toFloat()),
                    Offset(c.x + outer * cos(a).toFloat(), c.y + outer * sin(a).toFloat()),
                    strokeWidth = if (long) 3.dp.toPx() else 1.5.dp.toPx(), cap = StrokeCap.Round)
            }
        }
        // outer arcs
        rotate(rot2, c) {
            val tl = Offset(c.x - r * 0.86f, c.y - r * 0.86f)
            val sz = Size(r * 1.72f, r * 1.72f)
            drawArc(Cyan, 0f, 110f, false, tl, sz, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
            drawArc(Cyan, 150f, 60f, false, tl, sz, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
            drawArc(ElectricBlue.copy(alpha = 0.7f), 240f, 80f, false, tl, sz, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        }
        drawCircle(Cyan.copy(alpha = 0.25f), r * 0.96f, c, style = Stroke(1.dp.toPx()))
        drawCircle(Cyan.copy(alpha = 0.18f), r * 0.78f, c, style = Stroke(1.dp.toPx()))
        // core dot
        drawCircle(accent, r * 0.07f * pulse, c)
    }
}

@Composable
fun Waveform(active: Boolean, level: Float, speaking: Boolean, bars: Int = 46) {
    val inf = rememberInfiniteTransition(label = "wave")
    val phase by inf.animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "phase")
    Canvas(Modifier.fillMaxWidth().height(72.dp)) {
        val w = size.width / bars
        for (i in 0 until bars) {
            val base = if (!active) 0.14f
            else if (speaking) 0.3f + 0.7f * abs(sin(phase + i * 0.45f)) * (0.6f + 0.4f * abs(cos(i * 0.9f)))
            else (0.2f + 0.8f * abs(sin(phase * 0.6f + i * 0.4f))) * (0.3f + level)
            val h = (size.height * base).coerceIn(4.dp.toPx(), size.height)
            drawRoundRect(Cyan, Offset(i * w + w * 0.3f, (size.height - h) / 2f), Size(w * 0.4f, h), CornerRadius(4f, 4f))
        }
    }
}
