package com.aditya.friday.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/**
 * Android TextToSpeech with Hindi / Indian-English voices and honest fallbacks.
 * voicePreference: auto | hindi | english
 */
class TtsController(
    context: Context,
    private val onStart: () -> Unit,
    private val onDone: () -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var voicePreference = "auto"
    private var hindiAvailable = false
    private var englishIndiaAvailable = false
    var activeVoiceLabel: String = "INITIALIZING"
        private set

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                val t = tts!!
                hindiAvailable = t.isLanguageAvailable(Locale("hi", "IN")) >= TextToSpeech.LANG_AVAILABLE
                englishIndiaAvailable = t.isLanguageAvailable(Locale("en", "IN")) >= TextToSpeech.LANG_AVAILABLE
                t.setSpeechRate(0.98f)
                t.setPitch(1.02f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = onStart()
                    override fun onDone(utteranceId: String?) = onDone()
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = onDone()
                    override fun onError(utteranceId: String?, errorCode: Int) = onDone()
                })
                applyLocaleFor("")
            } else {
                activeVoiceLabel = "TTS ENGINE UNAVAILABLE"
            }
        }
    }

    fun setPreference(pref: String) {
        voicePreference = pref
        if (ready) applyLocaleFor("")
    }

    fun availableVoices(): List<String> {
        val t = tts ?: return emptyList()
        if (!ready) return emptyList()
        return runCatching {
            t.voices.orEmpty()
                .filter { v: Voice -> v.locale.language == "hi" || v.locale.language == "en" }
                .map { "${it.locale.toLanguageTag()} · ${it.name}" }
                .sorted()
        }.getOrDefault(emptyList())
    }

    private fun applyLocaleFor(text: String) {
        val t = tts ?: return
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        val wantHindi = when (voicePreference) {
            "hindi" -> true
            "english" -> false
            else -> hasDevanagari
        }
        val chosen: Locale = when {
            wantHindi && hindiAvailable -> Locale("hi", "IN")
            englishIndiaAvailable -> Locale("en", "IN")
            else -> Locale.US
        }
        val res = t.setLanguage(chosen)
        activeVoiceLabel = when {
            res < TextToSpeech.LANG_AVAILABLE -> { t.setLanguage(Locale.US); "en-US (fallback)" }
            wantHindi && !hindiAvailable -> "${chosen.toLanguageTag()} (Hindi voice missing)"
            else -> chosen.toLanguageTag()
        }
    }

    fun speak(text: String): Boolean {
        val t = tts ?: return false
        if (!ready || text.isBlank()) return false
        applyLocaleFor(text)
        val params = Bundle()
        val id = "friday_" + System.currentTimeMillis()
        return t.speak(text, TextToSpeech.QUEUE_FLUSH, params, id) == TextToSpeech.SUCCESS
    }

    fun stop() {
        tts?.stop()
        onDone()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
