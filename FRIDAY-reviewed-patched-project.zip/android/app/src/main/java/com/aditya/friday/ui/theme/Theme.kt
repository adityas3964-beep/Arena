package com.aditya.friday.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0B1220)
val NavyDeep = Color(0xFF070C16)
val Panel = Color(0xFF0E1726)
val PanelBorder = Color(0xFF1C2B40)
val Cyan = Color(0xFF22D3EE)
val CyanDim = Color(0xFF0E7490)
val ElectricBlue = Color(0xFF3B82F6)
val TextPrimary = Color(0xFFE2E8F0)
val TextDim = Color(0xFF7C8DA6)
val Green = Color(0xFF34D399)
val Amber = Color(0xFFF59E0B)
val Red = Color(0xFFF87171)

private val Mono = FontFamily.Monospace

val FridayTypography = Typography(
    displayLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 44.sp, letterSpacing = 6.sp),
    titleMedium = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Medium, fontSize = 15.sp, letterSpacing = 3.sp),
    titleSmall = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 2.sp),
    bodyLarge = TextStyle(fontFamily = Mono, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = Mono, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Mono, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 3.sp),
    labelSmall = TextStyle(fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
)

@Composable
fun FridayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            onPrimary = Navy,
            secondary = ElectricBlue,
            background = Navy,
            onBackground = TextPrimary,
            surface = Panel,
            onSurface = TextPrimary,
            surfaceVariant = Panel,
            onSurfaceVariant = TextDim,
            outline = PanelBorder,
            error = Red
        ),
        typography = FridayTypography,
        content = content
    )
}
