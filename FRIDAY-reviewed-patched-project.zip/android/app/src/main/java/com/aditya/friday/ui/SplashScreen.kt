package com.aditya.friday.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.ElectricBlue
import com.aditya.friday.ui.theme.Navy
import com.aditya.friday.ui.theme.PanelBorder
import com.aditya.friday.ui.theme.TextDim
import com.aditya.friday.ui.theme.TextPrimary
import kotlinx.coroutines.delay

private val stages = listOf("INITIALIZING CORE", "LOADING VOICE ENGINE", "CALIBRATING", "LINKING COMMAND DISPATCHER", "CHECKING SERVICES", "FRIDAY ONLINE")

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var stage by remember { mutableIntStateOf(0) }
    val progress by animateFloatAsState(targetValue = (stage + 1) / stages.size.toFloat(), animationSpec = tween(450), label = "p")
    val inf = rememberInfiniteTransition(label = "spin")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "rot")
    val glow by inf.animateFloat(0.6f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "glow")

    LaunchedEffect(Unit) {
        for (i in stages.indices) { stage = i; delay(420) }
        delay(350)
        onDone()
    }

    Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text("FRIDAY", style = MaterialTheme.typography.displayLarge, color = Cyan.copy(alpha = 0.35f * glow), modifier = Modifier.padding(2.dp))
                Text("FRIDAY", style = MaterialTheme.typography.displayLarge, color = Cyan)
            }
            Spacer(Modifier.height(8.dp))
            Text("YOUR PERSONAL AI ASSISTANT", style = MaterialTheme.typography.labelSmall, color = TextDim)
            Spacer(Modifier.height(48.dp))
            Canvas(Modifier.size(130.dp)) {
                val r = size.minDimension / 2
                drawCircle(Cyan.copy(alpha = 0.15f), r, center, style = Stroke(2.dp.toPx()))
                rotate(rot, center) {
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Cyan.copy(alpha = 0f), Cyan)),
                        startAngle = 0f, sweepAngle = 300f, useCenter = false,
                        topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2, r * 2),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                drawCircle(Cyan.copy(alpha = 0.4f * glow), 9.dp.toPx(), center)
                drawCircle(Cyan, 4.dp.toPx(), center)
            }
            Spacer(Modifier.height(36.dp))
            Text(stages[stage], style = MaterialTheme.typography.titleMedium, color = TextPrimary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(28.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).background(PanelBorder, RoundedCornerShape(3.dp))) {
                Box(
                    Modifier.fillMaxWidth(progress).height(6.dp)
                        .background(Brush.horizontalGradient(listOf(Cyan, ElectricBlue)), RoundedCornerShape(3.dp))
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, color = TextDim)
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                stages.indices.forEach { i ->
                    Box(Modifier.size(8.dp).background(if (i <= stage) Cyan else PanelBorder, CircleShape))
                }
            }
        }
    }
}
