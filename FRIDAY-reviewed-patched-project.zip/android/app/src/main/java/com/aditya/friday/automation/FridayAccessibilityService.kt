package com.aditya.friday.automation

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aditya.friday.core.ActionResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Real phone control through the Android Accessibility API.
 * Only acts when a command asks it to; never records or stores screen content.
 */
class FridayAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We only need the current window on demand; nothing is persisted.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        _connected.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        _connected.value = false
        super.onDestroy()
    }

    // ---------------------------------------------------------------- basic actions

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val target = findFirst(root) { it.isScrollable } ?: return false
        return target.performAction(action)
    }

    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = text.lowercase()
        val node = findFirst(root) { n ->
            val t = n.text?.toString()?.lowercase() ?: ""
            val d = n.contentDescription?.toString()?.lowercase() ?: ""
            t == q || d == q
        } ?: findFirst(root) { n ->
            val t = n.text?.toString()?.lowercase() ?: ""
            val d = n.contentDescription?.toString()?.lowercase() ?: ""
            t.contains(q) || d.contains(q)
        } ?: return false
        return clickNodeOrParent(node)
    }

    fun typeText(text: String, append: Boolean = false): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = findFirst(root) { it.isFocused && it.isEditable } ?: findFirst(root) { it.isEditable } ?: return false
        return setText(field, text, append)
    }

    fun clearText(): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = findFirst(root) { it.isFocused && it.isEditable } ?: findFirst(root) { it.isEditable } ?: return false
        return setText(field, "", false)
    }

    // ---------------------------------------------------------------- WhatsApp automation

    /**
     * Opens WhatsApp, taps Search, types the contact name and opens the matching conversation.
     * Reports ambiguity instead of guessing. Every step is verified against the live UI.
     */
    suspend fun whatsAppOpenChat(contact: String): ActionResult {
        val pkg = launcherPackage() ?: return ActionResult(false, "WhatsApp install nahi hai.")
        val launch = packageManager.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "WhatsApp launch nahi ho paya.")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(launch)
        delay(1800)

        // Already in a chat? go back to the list first.
        if (rootInActiveWindow?.packageName?.toString() != pkg) delay(1200)

        val search = waitFor(5000) { root ->
            findFirst(root) { n ->
                (n.viewIdResourceName?.endsWith(":id/menuitem_search") == true ||
                    n.contentDescription?.toString()?.contains("search", true) == true) && n.isClickable
            }
        }
        if (search == null) {
            // might be inside a chat; try back once then search again
            back(); delay(900)
            val retry = waitFor(3000) { root ->
                findFirst(root) { n ->
                    (n.viewIdResourceName?.endsWith(":id/menuitem_search") == true ||
                        n.contentDescription?.toString()?.contains("search", true) == true) && n.isClickable
                }
            } ?: return ActionResult(false, "WhatsApp ka Search button nahi mila. WhatsApp khula hai, chat manually kholein.")
            retry.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            search.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        delay(900)

        val edit = waitFor(3000) { root -> findFirst(root) { it.isEditable } }
            ?: return ActionResult(false, "Search box nahi mila.")
        setText(edit, contact, false)
        delay(1600)

        // Collect candidate rows (exclude the search field and the typed query echo)
        val root = rootInActiveWindow ?: return ActionResult(false, "Screen read nahi ho payi.")
        val q = contact.lowercase()
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collect(root, candidates) { n ->
            !n.isEditable && n.text != null && n.text.toString().lowercase().contains(q) &&
                (n.viewIdResourceName?.contains("contact_name") == true || n.viewIdResourceName?.contains("conversations_row") == true || n.isClickable || n.parent?.isClickable == true)
        }
        val names = candidates.mapNotNull { it.text?.toString() }.distinct()
        if (candidates.isEmpty()) {
            return ActionResult(false, "'$contact' naam ka koi contact nahi mila. WhatsApp mein search result khula hai.")
        }
        val exact = candidates.firstOrNull { it.text.toString().equals(contact, true) }
        val chosen = when {
            exact != null -> exact
            names.size == 1 -> candidates.first()
            else -> return ActionResult(false, "Ek se zyada contact mile: ${names.take(4).joinToString(", ")}. Poora naam bolein.")
        }
        val chosenName = chosen.text.toString()
        if (!clickNodeOrParent(chosen)) return ActionResult(false, "'$chosenName' par tap nahi ho paya.")
        delay(1400)

        val entry = waitFor(4000) { r -> findFirst(r) { n -> n.isEditable } }
        return if (entry != null) ActionResult(true, "$chosenName ki chat khul gayi.")
        else ActionResult(false, "Chat open hui ya nahi, verify nahi ho paya.")
    }

    /**
     * Types the message into the open chat and presses Send. Success is verified by the
     * entry box becoming empty after the click. Otherwise reports honestly.
     */
    suspend fun whatsAppSendMessage(message: String): ActionResult {
        val root = rootInActiveWindow ?: return ActionResult(false, "Screen read nahi ho payi.")
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) {
            return ActionResult(false, "WhatsApp chat screen par nahi hain. Pehle chat kholein.")
        }
        val entry = findFirst(root) { n -> n.isEditable && n.viewIdResourceName?.endsWith(":id/entry") == true }
            ?: findFirst(root) { it.isEditable }
            ?: return ActionResult(false, "Message box nahi mila. Kya chat khuli hai?")
        if (!setText(entry, message, false)) return ActionResult(false, "Message type nahi ho paya.")
        delay(700)

        val send = waitFor(3000) { r ->
            findFirst(r) { n ->
                n.isClickable && (n.viewIdResourceName?.endsWith(":id/send") == true ||
                    n.contentDescription?.toString()?.equals("send", true) == true)
            }
        } ?: return ActionResult(false, "Message type ho gaya lekin Send button nahi mila — aap manually send karein.")
        if (!send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return ActionResult(false, "Send button par tap fail hua — message box mein text ready hai, manually send karein.")
        }
        delay(1300)
        val after = rootInActiveWindow?.let { r -> findFirst(r) { n -> n.isEditable } }
        val remaining = after?.text?.toString()?.trim() ?: ""
        return if (remaining.isEmpty() || remaining.equals("Message", true) || remaining.equals(after?.hintText?.toString() ?: "\u0000", true)) {
            ActionResult(true, "Message send ho gaya (verified: input box clear hua).")
        } else {
            ActionResult(false, "Send tap hua lekin message abhi bhi box mein hai — delivery verify nahi hui.")
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun launcherPackage(): String? = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
        packageManager.getLaunchIntentForPackage(it) != null
    }

    private suspend fun waitFor(timeoutMs: Long, finder: (AccessibilityNodeInfo) -> AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            val root = rootInActiveWindow
            if (root != null) {
                val found = finder(root)
                if (found != null) return found
            }
            delay(250)
        }
        return null
    }

    private fun setText(node: AccessibilityNodeInfo, text: String, append: Boolean): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val existing = if (append) (node.text?.toString() ?: "") else ""
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, existing + text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        return false
    }

    private fun findFirst(root: AccessibilityNodeInfo, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (pred(root)) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val r = findFirst(child, pred)
            if (r != null) return r
        }
        return null
    }

    private fun collect(root: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, pred: (AccessibilityNodeInfo) -> Boolean) {
        if (pred(root)) out.add(root)
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            collect(child, out, pred)
        }
    }

    companion object {
        @Volatile
        var instance: FridayAccessibilityService? = null
            private set
        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected
    }
}
