package com.aditya.friday.ai

import com.aditya.friday.core.ActionValidator
import com.aditya.friday.core.FridayAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiMessage(val role: String, val content: String)

data class AiReply(
    val text: String,
    val actions: List<FridayAction>,
    val model: String
)

/**
 * OpenAI-compatible chat-completions client (Groq by default). No key is bundled,
 * the key is never logged, and the model name is fully user-editable.
 */
class AiClient(
    private val endpoint: String,
    private val apiKey: String,
    private val model: String
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Performs a real minimal request and returns the real outcome. */
    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(endpoint.startsWith("http")) { "Endpoint URL invalid hai" }
            val body = JSONObject().apply {
                put("model", model)
                put("max_tokens", 8)
                put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "Reply with OK")))
            }
            val (code, text) = post(body)
            if (code in 200..299) {
                val used = runCatching { JSONObject(text).optString("model", model) }.getOrDefault(model)
                "HTTP $code OK · model: $used"
            } else {
                throw IllegalStateException("HTTP $code · ${extractError(text)}")
            }
        }
    }

    suspend fun chat(system: String, history: List<AiMessage>, user: String): Result<AiReply> =
        withContext(Dispatchers.IO) {
            runCatching {
                val messages = JSONArray()
                messages.put(JSONObject().put("role", "system").put("content", system))
                history.forEach { messages.put(JSONObject().put("role", it.role).put("content", it.content)) }
                messages.put(JSONObject().put("role", "user").put("content", user))
                val body = JSONObject().apply {
                    put("model", model)
                    put("temperature", 0.4)
                    put("max_tokens", 600)
                    put("messages", messages)
                }
                val (code, text) = post(body)
                if (code !in 200..299) throw IllegalStateException("HTTP $code · ${extractError(text)}")
                val root = JSONObject(text)
                val content = root.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content", "").trim()
                parseReply(content, root.optString("model", model))
            }
        }

    private fun post(body: JSONObject): Pair<Int, String> {
        val builder = Request.Builder()
            .url(endpoint)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .addHeader("Content-Type", "application/json")
        if (apiKey.isNotBlank()) builder.addHeader("Authorization", "Bearer $apiKey")
        http.newCall(builder.build()).execute().use { resp ->
            return resp.code to (resp.body?.string() ?: "")
        }
    }

    private fun extractError(text: String): String = runCatching {
        val o = JSONObject(text)
        val err = o.optJSONObject("error")
        err?.optString("message")?.takeIf { it.isNotBlank() } ?: o.optString("message").ifBlank { text.take(160) }
    }.getOrDefault(text.take(160).ifBlank { "no response body" })

    companion object {
        /** Extracts {"reply": "...", "actions": [...]} leniently; falls back to plain text. */
        fun parseReply(content: String, model: String): AiReply {
            var raw = content
            if (raw.startsWith("```")) {
                raw = raw.removePrefix("```json").removePrefix("```").trim()
                if (raw.endsWith("```")) raw = raw.removeSuffix("```").trim()
            }
            val start = raw.indexOf('{')
            val end = raw.lastIndexOf('}')
            if (start >= 0 && end > start) {
                val candidate = raw.substring(start, end + 1)
                val obj = runCatching { JSONObject(candidate) }.getOrNull()
                if (obj != null && (obj.has("reply") || obj.has("actions"))) {
                    val reply = obj.optString("reply", "").trim()
                    val actions = mutableListOf<FridayAction>()
                    val arr = obj.optJSONArray("actions")
                    if (arr != null) {
                        for (i in 0 until minOf(arr.length(), 5)) {
                            val a = arr.optJSONObject(i) ?: continue
                            ActionValidator.fromJson(a)?.let { actions.add(it) }
                        }
                    }
                    return AiReply(reply, actions, model)
                }
            }
            return AiReply(content, emptyList(), model)
        }

        fun systemPrompt(assistantName: String, userName: String, contextSummary: String): String = """
You are $assistantName, a personal AI voice assistant running inside an Android app. Address the user as "$userName".
The user speaks Hindi, Hinglish (Hindi in Latin letters) or English. ALWAYS answer in the same language/style the user used. Keep spoken replies short (1-3 sentences) because they are read aloud.

You can control the phone ONLY by returning structured actions. Respond with ONLY a JSON object, no markdown:
{"reply": "<what you say to the user>", "actions": [ ...zero or more actions... ]}

Allowed actions (no other types exist):
{"type":"OPEN_APP","app":"WhatsApp"}
{"type":"OPEN_URL","url":"https://..."}
{"type":"WEB_SEARCH","query":"..."}
{"type":"BACK"} {"type":"HOME"} {"type":"SCROLL_UP"} {"type":"SCROLL_DOWN"}
{"type":"CLICK_TEXT","text":"<visible button label>"}
{"type":"TYPE_TEXT","text":"<text to type into the focused field>"}
{"type":"OPEN_SETTINGS","section":"wifi|bluetooth|display|general"}
{"type":"VOLUME","direction":"up|down|mute"}
{"type":"LOCK_PHONE"}
{"type":"WHATSAPP_OPEN_CHAT","contact":"<name>"}
{"type":"WHATSAPP_SEND_MESSAGE","recipient":"<name>","message":"<text>"}

Rules:
- Use actions only when the user asks to DO something on the phone. For questions/jokes/chat, return an empty actions list.
- The app ALWAYS asks the user to confirm before any WHATSAPP_SEND_MESSAGE is executed. Never claim a message was sent; say you are preparing it.
- If "usko/use/unko" refers to a previous recipient, use last_recipient from context. If the recipient is unknown or ambiguous, ask instead of guessing.
- Never invent actions you cannot perform. Never include code.
Context: $contextSummary
""".trimIndent()
    }
}
