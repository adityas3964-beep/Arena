package com.aditya.friday.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aditya.friday.admin.FridayDeviceAdminReceiver
import com.aditya.friday.ui.components.ChoiceChips
import com.aditya.friday.ui.components.HudButton
import com.aditya.friday.ui.components.HudPanel
import com.aditya.friday.ui.components.HudTextField
import com.aditya.friday.ui.components.StatusRow
import com.aditya.friday.ui.theme.Amber
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.Green
import com.aditya.friday.ui.theme.Navy
import com.aditya.friday.ui.theme.Red
import com.aditya.friday.ui.theme.TextDim
import com.aditya.friday.ui.theme.TextPrimary

@Composable
fun SettingsScreen(vm: AssistantViewModel, state: UiState, onRequestMic: () -> Unit) {
    val ctx = LocalContext.current
    var enabled by remember(state.onlineAiEnabled) { mutableStateOf(state.onlineAiEnabled) }
    var provider by remember(state.provider) { mutableStateOf(state.provider) }
    var endpoint by remember(state.endpoint) { mutableStateOf(state.endpoint) }
    var model by remember(state.model) { mutableStateOf(state.model) }
    var apiKey by remember { mutableStateOf("") }
    var wakeWord by remember(state.wakeWord) { mutableStateOf(state.wakeWord) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(2.dp))

        HudPanel("Device Admin (Phone Lock)") {
            StatusRow("Status", if (state.deviceAdminActive) "ACTIVE" else "OFF", if (state.deviceAdminActive) Green else Amber)
            Text(
                "Sirf 'force-lock' policy: 'phone lock karo' bolne par screen lock hoti hai. Data wipe ya password change ki permission nahi maangi jaati. Android aapse manually activate karwata hai.",
                style = MaterialTheme.typography.bodyMedium, color = TextDim
            )
            Spacer(Modifier.height(12.dp))
            if (!state.deviceAdminActive) {
                HudButton("Activate device admin", onClick = {
                    ctx.startActivity(FridayDeviceAdminReceiver.activationIntent(ctx, "FRIDAY uses only the lock-screen policy so your voice command can lock the phone."))
                }, Modifier.fillMaxWidth(), accent = Cyan, filled = true)
            } else {
                HudButton("Deactivate device admin", onClick = { FridayDeviceAdminReceiver.deactivate(ctx); vm.refreshStatuses() }, Modifier.fillMaxWidth(), accent = Red)
            }
        }

        HudPanel("Accessibility (Phone Control)") {
            StatusRow("Status", if (state.accessibilityEnabled) "ENABLED" else "NEEDS PERMISSION", if (state.accessibilityEnabled) Green else Amber)
            Text(
                "Back / Home / scroll / click / type aur WhatsApp automation ke liye 'FRIDAY Phone Control' accessibility service on karein. Screen content store nahi hota.",
                style = MaterialTheme.typography.bodyMedium, color = TextDim
            )
            Spacer(Modifier.height(12.dp))
            HudButton("Open accessibility settings", onClick = {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, Modifier.fillMaxWidth(), accent = Cyan, filled = !state.accessibilityEnabled)
        }

        HudPanel("Wake Word") {
            StatusRow("Status", if (state.wakeWordRunning) "RUNNING" else if (state.wakeWordError != null) "ERROR" else "NOT RUNNING", if (state.wakeWordRunning) Green else Amber)
            state.wakeWordError?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = Red) }
            Text(
                "Foreground service + persistent notification. Android ka on-device speech recognizer loop mein chalta hai aur wake word check karta hai — yeh dedicated low-power engine nahi hai, battery use hoti hai aur mic indicator dikhta rahega. Default OFF.",
                style = MaterialTheme.typography.bodyMedium, color = TextDim
            )
            HudTextField("Wake word", wakeWord, { wakeWord = it }, placeholder = "friday")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudButton(if (state.wakeWordEnabled) "Stop wake word" else "Start wake word", onClick = {
                    if (!state.micGranted) onRequestMic() else vm.setWakeWord(wakeWord, !state.wakeWordEnabled)
                }, Modifier.weight(1f), accent = if (state.wakeWordEnabled) Red else Cyan, filled = true)
            }
        }

        HudPanel("AI Provider (Optional)") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ENABLE ONLINE AI", style = MaterialTheme.typography.bodyLarge, color = TextPrimary, modifier = Modifier.weight(1f))
                Switch(
                    checked = enabled, onCheckedChange = { enabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Navy, checkedTrackColor = Cyan, uncheckedThumbColor = TextDim, uncheckedTrackColor = Navy)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text("Provider", style = MaterialTheme.typography.bodyMedium, color = TextDim)
            Spacer(Modifier.height(8.dp))
            ChoiceChips(listOf("Groq" to "Groq", "OpenAI" to "OpenAI", "Custom" to "Custom"), provider) { p ->
                provider = p
                when (p) {
                    "Groq" -> { endpoint = "https://api.groq.com/openai/v1/chat/completions"; if (model.isBlank()) model = "llama-3.3-70b-versatile" }
                    "OpenAI" -> { endpoint = "https://api.openai.com/v1/chat/completions"; if (model.isBlank()) model = "gpt-4o-mini" }
                }
            }
            HudTextField("Endpoint (OpenAI-compatible /chat/completions URL)", endpoint, { endpoint = it })
            HudTextField("Model name (editable — providers change models)", model, { model = it }, placeholder = "llama-3.3-70b-versatile")
            HudTextField(
                if (state.apiKeySaved) "API key (saved, encrypted · enter new to replace)" else "API key",
                apiKey, { apiKey = it }, password = true, placeholder = if (state.apiKeySaved) "••••••••" else "gsk_…"
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudButton("Save key", onClick = {
                    vm.saveAi(enabled, provider, endpoint, model, if (apiKey.isNotBlank()) apiKey else null); apiKey = ""
                }, Modifier.weight(1f), accent = Cyan, filled = true)
                HudButton(if (state.testing) "Testing…" else "Test", onClick = {
                    vm.saveAi(enabled, provider, endpoint, model, if (apiKey.isNotBlank()) apiKey else null); apiKey = ""
                    vm.testConnection()
                }, Modifier.weight(1f), enabled = !state.testing)
            }
            Spacer(Modifier.height(8.dp))
            StatusRow("Connection", state.connectionStatus, when (state.connectionStatus) {
                "CONNECTED", "ONLINE" -> Green; "FAILED", "ERROR", "NO INTERNET" -> Red; "TESTING" -> Amber; else -> TextDim
            })
            if (state.connectionDetail.isNotBlank()) Text(state.connectionDetail, style = MaterialTheme.typography.bodySmall, color = TextDim)
            Spacer(Modifier.height(6.dp))
            Text(
                "AI ke liye internet chahiye aur provider ki free-tier limits lag sakti hain (Groq free tier: rate-limited, billing zaroori nahi). Koi key app mein bundled nahi hai; key Android Keystore se encrypt hoti hai aur kabhi log nahi hoti. Bina AI ke saare local commands chalte hain. AI jawab [AI] tag se dikhte hain.",
                style = MaterialTheme.typography.bodySmall, color = TextDim
            )
        }

        HudPanel("Troubleshooting") {
            Text(
                "• Mic start nahi hota: Permissions mein Microphone dein; Google app / Speech Services installed hona chahiye. Offline recognition ke liye Settings → System → Languages → On-device speech recognition mein Hindi/English download karein.\n" +
                    "• 'Recognizer busy': wake-word service mic use kar rahi hai — pehle use band karein.\n" +
                    "• Back/scroll/WhatsApp kaam nahi karta: Accessibility service on karein.\n" +
                    "• WhatsApp contact nahi milta: poora naam bolein; ek se zyada match par FRIDAY poochegi.\n" +
                    "• Hindi awaaz nahi: Google Text-to-speech mein Hindi voice data install karein; warna en-IN fallback use hota hai.\n" +
                    "• Test Connection fail: endpoint, model name aur key check karein; HTTP 401 = galat key, 404 = galat model/endpoint, 429 = rate limit.",
                style = MaterialTheme.typography.bodyMedium, color = TextDim
            )
        }
        Spacer(Modifier.height(20.dp))
    }
}
