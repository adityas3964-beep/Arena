package com.aditya.friday.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

enum class VoiceState { IDLE, STARTING, LISTENING, PROCESSING }

/**
 * Thin wrapper over Android SpeechRecognizer. Must be used from the main thread.
 * Reports REAL states and errors; never fabricates results.
 */
class VoiceController(private val context: Context) {

    interface Listener {
        fun onState(state: VoiceState)
        fun onPartial(text: String)
        fun onFinal(alternatives: List<String>)
        fun onError(message: String, code: Int)
        fun onRms(rms: Float)
    }

    var listener: Listener? = null
    private var recognizer: SpeechRecognizer? = null
    var isActive = false
        private set

    val isAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(language: String, preferOffline: Boolean) {
        if (!isAvailable) {
            listener?.onError("Is device par speech recognition service nahi hai.", -1)
            return
        }
        cancel()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isActive = true; listener?.onState(VoiceState.LISTENING) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { listener?.onRms(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listener?.onState(VoiceState.PROCESSING) }
            override fun onError(error: Int) {
                isActive = false
                listener?.onState(VoiceState.IDLE)
                listener?.onError(describe(error), error)
            }
            override fun onResults(results: Bundle?) {
                isActive = false
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                listener?.onState(VoiceState.IDLE)
                if (list.isEmpty()) listener?.onError("Kuch sunai nahi diya.", SpeechRecognizer.ERROR_NO_MATCH)
                else listener?.onFinal(list)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { listener?.onPartial(it) }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            if (preferOffline) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        listener?.onState(VoiceState.STARTING)
        isActive = true
        r.startListening(intent)
    }

    /** Push-to-talk release: stop capturing and let the engine deliver what it heard. */
    fun stopAndFinish() {
        recognizer?.stopListening()
    }

    fun cancel() {
        isActive = false
        recognizer?.let {
            runCatching { it.cancel() }
            runCatching { it.destroy() }
        }
        recognizer = null
    }

    fun destroy() = cancel()

    companion object {
        fun describe(code: Int): String = when (code) {
            SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error."
            SpeechRecognizer.ERROR_CLIENT -> "Recognizer client error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission nahi hai."
            SpeechRecognizer.ERROR_NETWORK -> "Network error: online recognition ke liye internet chahiye."
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout."
            SpeechRecognizer.ERROR_NO_MATCH -> "Kuch samajh nahi aaya, dobara boliye."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai (shayad wake-word service mic use kar rahi hai)."
            SpeechRecognizer.ERROR_SERVER -> "Recognition server error."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Koi awaaz nahi aayi (timeout)."
            12 -> "Yeh language is device par supported nahi hai."   // ERROR_LANGUAGE_NOT_SUPPORTED (API 31)
            13 -> "Language pack unavailable (offline model download karein)."   // ERROR_LANGUAGE_UNAVAILABLE
            else -> "Recognition error $code."
        }
    }
}
