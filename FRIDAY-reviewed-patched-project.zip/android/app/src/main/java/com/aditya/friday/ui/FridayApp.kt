package com.aditya.friday.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.Navy
import com.aditya.friday.ui.theme.NavyDeep
import com.aditya.friday.ui.theme.PanelBorder
import com.aditya.friday.ui.theme.TextDim

enum class Tab { HOME, LOG, PROFILE, SETTINGS }

@Composable
fun FridayApp(vm: AssistantViewModel, onRequestMic: () -> Unit) {
    var splashDone by rememberSaveable { mutableStateOf(false) }
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    val state by vm.state.collectAsState()

    if (!splashDone) {
        SplashScreen(onDone = { splashDone = true })
        return
    }

    Column(Modifier.fillMaxSize().background(Navy).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                Tab.HOME -> HomeScreen(vm, state, onRequestMic)
                Tab.LOG -> LogScreen(vm, state)
                Tab.PROFILE -> ProfileScreen(vm, state)
                Tab.SETTINGS -> SettingsScreen(vm, state, onRequestMic)
            }
        }
        HorizontalDivider(color = PanelBorder)
        Row(Modifier.fillMaxWidth().background(NavyDeep).navigationBarsPadding()) {
            Tab.values().forEach { t ->
                val on = t == tab
                Box(
                    Modifier.weight(1f).clickable { tab = t }.padding(vertical = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(t.name, style = MaterialTheme.typography.labelLarge, color = if (on) Cyan else TextDim)
                }
            }
        }
    }
}
