package com.aditya.friday.core

import android.app.SearchManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import com.aditya.friday.admin.FridayDeviceAdminReceiver
import com.aditya.friday.automation.AppLauncher
import com.aditya.friday.automation.FridayAccessibilityService

/**
 * The only place where validated actions touch Android APIs.
 * Confirmation-gated actions must already be confirmed by the caller (ViewModel / ConfirmationManager).
 */
class ActionExecutor(
    private val app: Context,
    private val launcher: AppLauncher,
    private val ctx: ConversationContext
) {
    private val a11y get() = FridayAccessibilityService.instance

    suspend fun execute(action: FridayAction): ActionResult = when (action) {
        is FridayAction.OpenApp -> {
            val (ok, msg) = launcher.launch(action.app)
            if (ok) ctx.currentApp = action.app
            ActionResult(ok, msg)
        }
        is FridayAction.OpenUrl -> startSafely(Intent(Intent.ACTION_VIEW, Uri.parse(action.url)), "Link khol diya.")
        is FridayAction.WebSearch -> {
            val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, action.query)
            val r = startSafely(i, "'${action.query}' search kar rahi hoon.")
            if (r.ok) r else startSafely(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(action.query))),
                "'${action.query}' Google par search kar rahi hoon."
            )
        }
        FridayAction.Back -> a11y?.let { val ok = it.back(); ActionResult(ok, if (ok) "Back." else "Back action fail hua.") } ?: needsA11y()
        FridayAction.Home -> a11y?.let { ActionResult(it.home(), "Home screen.") } ?: run {
            // graceful fallback without accessibility
            startSafely(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), "Home screen.")
        }
        FridayAction.ScrollDown -> a11y?.let { val ok = it.scroll(true); ActionResult(ok, if (ok) "Neeche scroll kiya." else "Koi scrollable screen nahi mili.") } ?: needsA11y()
        FridayAction.ScrollUp -> a11y?.let { val ok = it.scroll(false); ActionResult(ok, if (ok) "Upar scroll kiya." else "Koi scrollable screen nahi mili.") } ?: needsA11y()
        is FridayAction.ClickText -> a11y?.let { val ok = it.clickByText(action.text); ActionResult(ok, if (ok) "'${action.text}' par click kiya." else "'${action.text}' screen par nahi mila.") } ?: needsA11y()
        is FridayAction.TypeText -> a11y?.let { val ok = it.typeText(action.text); ActionResult(ok, if (ok) "'${action.text}' likh diya." else "Koi text field focus mein nahi hai.") } ?: needsA11y()
        is FridayAction.OpenSettings -> {
            val act = when (action.section) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            startSafely(Intent(act), "${action.section.replaceFirstChar { it.uppercase() }} settings khol di.")
        }
        is FridayAction.Volume -> adjustVolume(action.direction)
        FridayAction.LockPhone -> lockPhone()
        is FridayAction.WhatsAppOpenChat -> {
            val svc = a11y
            if (svc == null) {
                val (ok, _) = launcher.launch("whatsapp")
                ActionResult(false, if (ok) "Accessibility service band hai, isliye WhatsApp khol diya — '${action.contact}' ki chat aap manually kholein." else "WhatsApp nahi mila.", needsPermission = true)
            } else {
                val r = svc.whatsAppOpenChat(action.contact)
                if (r.ok) { ctx.setRecipient(action.contact); ctx.currentApp = "WhatsApp" }
                r
            }
        }
        is FridayAction.WhatsAppSendMessage -> sendWhatsApp(action)
        FridayAction.StopSpeaking -> ActionResult(true, "Ruk gayi.")
    }

    private suspend fun sendWhatsApp(action: FridayAction.WhatsAppSendMessage): ActionResult {
        val recipient = action.recipient ?: ctx.lastRecipient
            ?: return ActionResult(false, "Kisko bhejna hai? Pehle contact ka naam bataiye.")
        val svc = a11y
        if (svc == null) {
            // Safe fallback: prepare the message in WhatsApp for manual sending.
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(action.message)))
            val r = startSafely(i, "Accessibility band hai: message WhatsApp mein ready kar diya, $recipient ko aap manually bhejein.")
            return ActionResult(false, r.message, needsPermission = true)
        }
        // Always resolve the recipient again immediately before sending. The user may
        // have switched chats manually since the previous command; checking only the
        // WhatsApp package would risk sending to the wrong conversation.
        val open = svc.whatsAppOpenChat(recipient)
        if (!open.ok) return open
        ctx.setRecipient(recipient)
        ctx.currentApp = "WhatsApp"
        val sent = svc.whatsAppSendMessage(action.message)
        if (sent.ok) ctx.setMessage(action.message)
        return sent
    }

    private fun adjustVolume(direction: String): ActionResult = try {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val adj = when (direction) {
            "up" -> AudioManager.ADJUST_RAISE
            "down" -> AudioManager.ADJUST_LOWER
            else -> AudioManager.ADJUST_MUTE
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, adj, AudioManager.FLAG_SHOW_UI)
        val now = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        ActionResult(true, "Volume ${if (direction == "mute") "mute" else direction}: $now/$max")
    } catch (e: SecurityException) {
        ActionResult(false, "Volume change karne ki permission nahi (Do Not Disturb policy).", needsPermission = true)
    }

    private fun lockPhone(): ActionResult {
        val dpm = app.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(app, FridayDeviceAdminReceiver::class.java)
        return if (dpm.isAdminActive(admin)) {
            try { dpm.lockNow(); ActionResult(true, "Phone lock kar diya.") }
            catch (e: SecurityException) { ActionResult(false, "Lock fail: ${e.message}") }
        } else ActionResult(false, "Device Admin active nahi hai. Settings mein 'Activate Device Admin' karein.", needsPermission = true)
    }

    private fun startSafely(intent: Intent, okMsg: String): ActionResult = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(intent)
        ActionResult(true, okMsg)
    } catch (e: Exception) {
        ActionResult(false, "Open nahi ho paya: ${e.javaClass.simpleName}")
    }

    private fun needsA11y() = ActionResult(
        false,
        "Is action ke liye FRIDAY Accessibility Service on karni hogi (Settings → Accessibility).",
        needsPermission = true
    )
}
