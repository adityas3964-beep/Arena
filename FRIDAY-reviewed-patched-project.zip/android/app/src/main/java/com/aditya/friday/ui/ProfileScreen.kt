package com.aditya.friday.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aditya.friday.ui.components.ChoiceChips
import com.aditya.friday.ui.components.HudButton
import com.aditya.friday.ui.components.HudPanel
import com.aditya.friday.ui.components.HudTextField
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.TextDim
import com.aditya.friday.ui.theme.TextPrimary

@Composable
fun ProfileScreen(vm: AssistantViewModel, state: UiState) {
    var name by remember(state.userName) { mutableStateOf(state.userName) }
    var assistant by remember(state.assistantName) { mutableStateOf(state.assistantName) }
    var lang by remember(state.language) { mutableStateOf(state.language) }
    var voice by remember(state.voicePreference) { mutableStateOf(state.voicePreference) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(2.dp))
        HudPanel("Profile") {
            HudTextField("Preferred name (FRIDAY will address you like this)", name, { name = it }, placeholder = "Boss")
            HudTextField("Assistant name", assistant, { assistant = it }, placeholder = "FRIDAY")
            Spacer(Modifier.height(8.dp))
            Text("Recognition language", style = MaterialTheme.typography.bodyMedium, color = TextDim)
            Spacer(Modifier.height(8.dp))
            ChoiceChips(listOf("hi-IN" to "Hindi/Hinglish", "en-IN" to "English (IN)", "en-US" to "English (US)"), lang) { lang = it }
            Spacer(Modifier.height(14.dp))
            Text("Voice preference", style = MaterialTheme.typography.bodyMedium, color = TextDim)
            Spacer(Modifier.height(8.dp))
            ChoiceChips(listOf("auto" to "Auto", "hindi" to "Hindi", "english" to "English"), voice) { voice = it }
            Spacer(Modifier.height(8.dp))
            Text("Active TTS voice: ${state.ttsVoice.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall, color = TextDim)
            if (state.voices.isNotEmpty()) {
                Text("Installed hi/en voices: ${state.voices.size}", style = MaterialTheme.typography.bodySmall, color = TextDim)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudButton("Save profile", onClick = { vm.saveProfile(name, assistant, lang, voice) }, Modifier.weight(1f), accent = Cyan, filled = true)
                HudButton("Preview voice", onClick = { vm.previewVoice() }, Modifier.weight(1f))
            }
        }
        HudPanel("About") {
            Text("FRIDAY – Personal AI Assistant", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Text("Whole credit goes to Aditya.", style = MaterialTheme.typography.bodyMedium, color = Cyan)
            Text("© 2026 Aditya. All rights reserved.", style = MaterialTheme.typography.bodyMedium, color = TextDim)
            Spacer(Modifier.height(12.dp))
            Text("Version 1.0.0 · package com.aditya.friday", style = MaterialTheme.typography.bodySmall, color = TextDim)
            Spacer(Modifier.height(12.dp))
            Text("Third-party software", style = MaterialTheme.typography.titleSmall, color = TextDim)
            Spacer(Modifier.height(4.dp))
            Text(
                "AndroidX / Jetpack Compose (Apache-2.0) · Kotlin & kotlinx.coroutines (Apache-2.0) · OkHttp by Square (Apache-2.0) · " +
                    "AndroidX Security Crypto / Tink (Apache-2.0). Speech recognition and text-to-speech are provided by the engines installed on your device.",
                style = MaterialTheme.typography.bodySmall, color = TextDim
            )
        }
        HudPanel("Privacy") {
            Text(
                "• API key is encrypted with an Android Keystore master key and never logged.\n" +
                    "• Microphone is used only while listening (status shown on screen; system mic indicator applies).\n" +
                    "• Messages and calls are never sent without your explicit confirmation.\n" +
                    "• No analytics, no personal-data collection, no payments.",
                style = MaterialTheme.typography.bodySmall, color = TextDim
            )
        }
        Spacer(Modifier.height(20.dp))
    }
}
