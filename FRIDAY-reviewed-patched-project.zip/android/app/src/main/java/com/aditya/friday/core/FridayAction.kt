package com.aditya.friday.core

import org.json.JSONObject

/**
 * Strict, validated action schema. AI output is parsed INTO these types; the AI never
 * executes anything directly. Unknown types / oversized fields are rejected.
 */
sealed class FridayAction {
    data class OpenApp(val app: String) : FridayAction()
    data class OpenUrl(val url: String) : FridayAction()
    data class WebSearch(val query: String) : FridayAction()
    object Back : FridayAction()
    object Home : FridayAction()
    object ScrollUp : FridayAction()
    object ScrollDown : FridayAction()
    data class ClickText(val text: String) : FridayAction()
    data class TypeText(val text: String) : FridayAction()
    data class OpenSettings(val section: String) : FridayAction()   // wifi | bluetooth | display | general
    data class Volume(val direction: String) : FridayAction()       // up | down | mute
    object LockPhone : FridayAction()
    data class WhatsAppOpenChat(val contact: String) : FridayAction()
    data class WhatsAppSendMessage(val recipient: String?, val message: String) : FridayAction()
    object StopSpeaking : FridayAction()

    /** Actions that may never run without the user's explicit "haan/yes". */
    val requiresConfirmation: Boolean
        get() = this is WhatsAppSendMessage

    fun describe(): String = when (this) {
        is OpenApp -> "Open app: $app"
        is OpenUrl -> "Open URL: $url"
        is WebSearch -> "Web search: $query"
        Back -> "Back"
        Home -> "Home"
        ScrollUp -> "Scroll up"
        ScrollDown -> "Scroll down"
        is ClickText -> "Click '$text'"
        is TypeText -> "Type '$text'"
        is OpenSettings -> "Open settings: $section"
        is Volume -> "Volume $direction"
        LockPhone -> "Lock phone"
        is WhatsAppOpenChat -> "WhatsApp: open chat with $contact"
        is WhatsAppSendMessage -> "WhatsApp: send \"$message\" to ${recipient ?: "?"}"
        StopSpeaking -> "Stop"
    }
}

data class ActionResult(
    val ok: Boolean,
    val message: String,
    val needsConfirmation: Boolean = false,
    val needsPermission: Boolean = false
)

object ActionValidator {
    private const val MAX_LEN = 500

    private fun JSONObject.cleanString(vararg keys: String): String? {
        for (k in keys) {
            val v = optString(k, "").trim()
            if (v.isNotEmpty()) return v.take(MAX_LEN)
        }
        return null
    }

    /** Returns null for anything that is not a known, well-formed action. */
    fun fromJson(obj: JSONObject): FridayAction? {
        val type = obj.optString("type", "").trim().uppercase().replace(' ', '_')
        return when (type) {
            "OPEN_APP" -> obj.cleanString("app", "name")?.let { FridayAction.OpenApp(it) }
            "OPEN_URL" -> obj.cleanString("url")?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                ?.let { FridayAction.OpenUrl(it) }
            "WEB_SEARCH", "SEARCH" -> obj.cleanString("query", "text")?.let { FridayAction.WebSearch(it) }
            "BACK" -> FridayAction.Back
            "HOME" -> FridayAction.Home
            "SCROLL_UP" -> FridayAction.ScrollUp
            "SCROLL_DOWN" -> FridayAction.ScrollDown
            "CLICK_TEXT", "CLICK" -> obj.cleanString("text", "target")?.let { FridayAction.ClickText(it) }
            "TYPE_TEXT", "TYPE" -> obj.cleanString("text")?.let { FridayAction.TypeText(it) }
            "OPEN_SETTINGS" -> {
                val s = (obj.cleanString("section") ?: "general").lowercase()
                FridayAction.OpenSettings(if (s in setOf("wifi", "bluetooth", "display", "general")) s else "general")
            }
            "VOLUME" -> {
                val d = (obj.cleanString("direction") ?: "").lowercase()
                if (d in setOf("up", "down", "mute")) FridayAction.Volume(d) else null
            }
            "LOCK_PHONE" -> FridayAction.LockPhone
            "WHATSAPP_OPEN_CHAT" -> obj.cleanString("contact", "recipient")?.let { FridayAction.WhatsAppOpenChat(it) }
            "WHATSAPP_SEND_MESSAGE" -> obj.cleanString("message", "text")?.let {
                FridayAction.WhatsAppSendMessage(obj.cleanString("recipient", "contact"), it)
            }
            "STOP" -> FridayAction.StopSpeaking
            else -> null
        }
    }
}
