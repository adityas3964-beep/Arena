package com.aditya.friday.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.Panel
import com.aditya.friday.ui.theme.PanelBorder
import com.aditya.friday.ui.theme.TextDim
import com.aditya.friday.ui.theme.TextPrimary

/** Panel with glowing corner brackets, as in the reference screenshots. */
@Composable
fun HudPanel(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind {
                val c = 22.dp.toPx()
                val w = 3.dp.toPx()
                val col = Cyan
                drawLine(col, Offset(0f, 0f), Offset(c, 0f), w, StrokeCap.Square)
                drawLine(col, Offset(0f, 0f), Offset(0f, c), w, StrokeCap.Square)
                drawLine(col, Offset(size.width, 0f), Offset(size.width - c, 0f), w, StrokeCap.Square)
                drawLine(col, Offset(size.width, 0f), Offset(size.width, c), w, StrokeCap.Square)
                drawLine(col, Offset(0f, size.height), Offset(c, size.height), w, StrokeCap.Square)
                drawLine(col, Offset(0f, size.height), Offset(0f, size.height - c), w, StrokeCap.Square)
                drawLine(col, Offset(size.width, size.height), Offset(size.width - c, size.height), w, StrokeCap.Square)
                drawLine(col, Offset(size.width, size.height), Offset(size.width, size.height - c), w, StrokeCap.Square)
            }
            .padding(2.dp)
            .background(Panel.copy(alpha = 0.55f))
            .border(1.dp, PanelBorder)
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Text(title.uppercase(), style = MaterialTheme.typography.titleMedium, color = Cyan)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
fun StatusRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.size(12.dp))
        Text(label.uppercase(), style = MaterialTheme.typography.bodyMedium, color = TextDim, modifier = Modifier.weight(1f))
        Text(value.uppercase(), style = MaterialTheme.typography.labelLarge, color = color)
    }
}

@Composable
fun HudButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = TextDim,
    filled: Boolean = false,
    enabled: Boolean = true
) {
    val alpha = if (enabled) 1f else 0.4f
    Box(
        modifier
            .background(if (filled) accent.copy(alpha = 0.12f * alpha) else Color.Transparent, RoundedCornerShape(6.dp))
            .border(1.5.dp, accent.copy(alpha = alpha), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text.uppercase(), style = MaterialTheme.typography.labelLarge, color = accent.copy(alpha = alpha), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
fun HudTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    singleLine: Boolean = true,
    placeholder: String = ""
) {
    Column(modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextDim)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = singleLine,
            placeholder = { Text(placeholder, color = TextDim.copy(alpha = 0.5f), style = MaterialTheme.typography.bodyMedium) },
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Text),
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            shape = RoundedCornerShape(6.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Cyan,
                unfocusedBorderColor = Cyan.copy(alpha = 0.45f),
                cursorColor = Cyan,
                focusedContainerColor = Panel.copy(alpha = 0.4f),
                unfocusedContainerColor = Panel.copy(alpha = 0.4f)
            )
        )
    }
}

@Composable
fun ChoiceChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (key, label) ->
            val on = key == selected
            Box(
                Modifier
                    .weight(1f)
                    .background(if (on) Cyan.copy(alpha = 0.15f) else Color.Transparent, RoundedCornerShape(6.dp))
                    .border(1.dp, if (on) Cyan else PanelBorder, RoundedCornerShape(6.dp))
                    .clickable { onSelect(key) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = if (on) Cyan else TextDim)
            }
        }
    }
}
