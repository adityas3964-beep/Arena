package com.aditya.friday.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aditya.friday.ui.components.HudButton
import com.aditya.friday.ui.components.HudPanel
import com.aditya.friday.ui.components.StatusRow
import com.aditya.friday.ui.theme.Amber
import com.aditya.friday.ui.theme.Cyan
import com.aditya.friday.ui.theme.Green
import com.aditya.friday.ui.theme.PanelBorder
import com.aditya.friday.ui.theme.Red
import com.aditya.friday.ui.theme.TextDim
import com.aditya.friday.ui.theme.TextPrimary

@Composable
fun LogScreen(vm: AssistantViewModel, state: UiState) {
    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Spacer(Modifier.height(2.dp)) }
        item {
            HudPanel("Service Status") {
                StatusRow("Online AI", if (!state.onlineAiEnabled) "OFF" else if (state.networkAvailable) "READY" else "NO INTERNET", if (!state.onlineAiEnabled) TextDim else if (state.networkAvailable) Green else Amber)
                StatusRow("Offline mode", if (state.recognizerAvailable) "READY" else "NOT RUNNING", if (state.recognizerAvailable) Green else Red)
                StatusRow("Microphone permission", if (state.micGranted) "GRANTED" else "NEEDS PERMISSION", if (state.micGranted) Green else Red)
                StatusRow("Accessibility permission", if (state.accessibilityEnabled) "ENABLED" else "NEEDS PERMISSION", if (state.accessibilityEnabled) Green else Amber)
                StatusRow("Recognition mode", state.recognitionMode.name.replace('_', ' '), if (state.recognitionMode == RecognitionMode.OFF) TextDim else Green)
                StatusRow("Wake word status", if (state.wakeWordRunning) "RUNNING" else if (state.wakeWordError != null) "ERROR" else "NOT RUNNING", if (state.wakeWordRunning) Green else Amber)
                StatusRow("Device admin", if (state.deviceAdminActive) "ACTIVE" else "OFF", if (state.deviceAdminActive) Green else TextDim)
                StatusRow("TTS voice", state.ttsVoice.ifBlank { "—" }, Cyan)
                StatusRow("Last engine used", state.lastEngine, Cyan)
                StatusRow("Last command", state.heard.ifBlank { "—" }.take(28), TextPrimary)
                StatusRow("Last action result", state.lastActionResult, when (state.lastActionResult) { "ACTION SUCCESS" -> Green; "ACTION FAILED" -> Red; "NEEDS CONFIRMATION", "NEEDS PERMISSION" -> Amber; else -> TextDim })
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudButton("Clear log", onClick = { vm.clearLog() }, Modifier.weight(1f))
                HudButton("Clear context", onClick = { vm.clearContext() }, Modifier.weight(1f), accent = Amber)
            }
        }
        item {
            HudPanel("Command Log (${state.log.size})") {
                if (state.log.isEmpty()) Text("No entries yet. Commands and their real results appear here.", style = MaterialTheme.typography.bodyMedium, color = TextDim)
            }
        }
        items(state.log) { e ->
            Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    Text(e.time, style = MaterialTheme.typography.labelSmall, color = TextDim)
                    Spacer(Modifier.weight(1f))
                    Text("[${e.engine}]", style = MaterialTheme.typography.labelSmall, color = Cyan)
                    Spacer(Modifier.padding(4.dp))
                    Text(e.result, style = MaterialTheme.typography.labelSmall, color = when (e.result) {
                        "ACTION SUCCESS" -> Green; "ACTION FAILED" -> Red; "NEEDS CONFIRMATION", "NEEDS PERMISSION" -> Amber; else -> TextDim
                    })
                }
                Text("› ${e.heard}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Text(e.response, style = MaterialTheme.typography.bodySmall, color = Cyan.copy(alpha = 0.85f))
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = PanelBorder)
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}
