package com.aditya.friday.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * All persisted settings. The API key (and everything else here) is stored in
 * EncryptedSharedPreferences whose master key lives in the Android Keystore.
 * The key is never written to logs.
 */
class SecureSettings(context: Context) {

    private var secureStorageAvailable: Boolean = true

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "friday_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Keep non-secret preferences usable, but fail closed for API credentials.
        // Never silently write an API key to unencrypted SharedPreferences.
        secureStorageAvailable = false
        context.getSharedPreferences("friday_fallback_prefs", Context.MODE_PRIVATE)
    }

    private fun str(key: String, default: String) = prefs.getString(key, default) ?: default
    private fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()
    private fun put(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()

    var onlineAiEnabled: Boolean
        get() = prefs.getBoolean("online_ai", false)
        set(v) = put("online_ai", v)

    var provider: String
        get() = str("provider", "Groq")
        set(v) = put("provider", v)

    var endpoint: String
        get() = str("endpoint", DEFAULT_ENDPOINT)
        set(v) = put("endpoint", v)

    /** Editable: providers rotate models. This is only a starting suggestion. */
    var model: String
        get() = str("model", DEFAULT_MODEL)
        set(v) = put("model", v)

    var apiKey: String
        get() = if (secureStorageAvailable) str("api_key", "") else ""
        set(v) { if (secureStorageAvailable) put("api_key", v) }

    val canSecurelyStoreApiKey: Boolean
        get() = secureStorageAvailable

    var userName: String
        get() = str("user_name", "Boss")
        set(v) = put("user_name", v)

    var assistantName: String
        get() = str("assistant_name", "FRIDAY")
        set(v) = put("assistant_name", v)

    /** Recognition language tag: hi-IN, en-IN, en-US */
    var language: String
        get() = str("language", "hi-IN")
        set(v) = put("language", v)

    /** auto | hindi | english */
    var voicePreference: String
        get() = str("voice_pref", "auto")
        set(v) = put("voice_pref", v)

    var wakeWord: String
        get() = str("wake_word", "friday")
        set(v) = put("wake_word", v)

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_enabled", false)
        set(v) = put("wake_enabled", v)

    companion object {
        const val DEFAULT_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
        const val DEFAULT_MODEL = "llama-3.3-70b-versatile"
    }
}
