package com.aditya.friday.ui

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aditya.friday.admin.FridayDeviceAdminReceiver
import com.aditya.friday.ai.AiClient
import com.aditya.friday.automation.AppLauncher
import com.aditya.friday.automation.FridayAccessibilityService
import com.aditya.friday.core.ActionExecutor
import com.aditya.friday.core.ActionResult
import com.aditya.friday.core.ConversationContext
import com.aditya.friday.core.FridayAction
import com.aditya.friday.core.LocalCommandParser
import com.aditya.friday.data.SecureSettings
import com.aditya.friday.voice.TtsController
import com.aditya.friday.voice.VoiceController
import com.aditya.friday.voice.VoiceState
import com.aditya.friday.voice.WakeWordService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CoreStatus { IDLE, LISTENING, THINKING, SPEAKING }
enum class RecognitionMode { OFF, AUTO, PUSH_TO_TALK, MANUAL }

data class LogEntry(
    val time: String,
    val heard: String,
    val response: String,
    val engine: String,      // LOCAL | AI | OFFLINE | SYSTEM
    val result: String       // ACTION SUCCESS | ACTION FAILED | NEEDS CONFIRMATION | NEEDS PERMISSION | INFO
)

data class UiState(
    val status: CoreStatus = CoreStatus.IDLE,
    val statusDetail: String = "",
    val partial: String = "",
    val heard: String = "",
    val response: String = "",
    val responseEngine: String = "",
    val level: Float = 0f,
    val recent: List<String> = emptyList(),
    val log: List<LogEntry> = emptyList(),
    val pendingDescription: String? = null,
    val recognitionMode: RecognitionMode = RecognitionMode.OFF,
    val lastEngine: String = "—",
    val lastActionResult: String = "—",
    // real service statuses
    val micGranted: Boolean = false,
    val recognizerAvailable: Boolean = false,
    val accessibilityEnabled: Boolean = false,
    val wakeWordRunning: Boolean = false,
    val wakeWordError: String? = null,
    val deviceAdminActive: Boolean = false,
    val networkAvailable: Boolean = false,
    val ttsVoice: String = "",
    // settings snapshot
    val onlineAiEnabled: Boolean = false,
    val provider: String = "Groq",
    val endpoint: String = SecureSettings.DEFAULT_ENDPOINT,
    val model: String = SecureSettings.DEFAULT_MODEL,
    val apiKeySaved: Boolean = false,
    val connectionStatus: String = "OFF",
    val connectionDetail: String = "",
    val testing: Boolean = false,
    val userName: String = "Boss",
    val assistantName: String = "FRIDAY",
    val language: String = "hi-IN",
    val voicePreference: String = "auto",
    val wakeWord: String = "friday",
    val wakeWordEnabled: Boolean = false,
    val voices: List<String> = emptyList()
)

class AssistantViewModel(app: Application) : AndroidViewModel(app) {

    private val appCtx: Context = app.applicationContext
    private val settings = SecureSettings(appCtx)
    private val context = ConversationContext()
    private val launcher = AppLauncher(appCtx)
    private val executor = ActionExecutor(appCtx, launcher, context)
    private val voice = VoiceController(appCtx)
    private val tts = TtsController(appCtx,
        onStart = { _state.update { it.copy(status = CoreStatus.SPEAKING, statusDetail = "") } },
        onDone = { viewModelScope.launch { onSpeechDone() } })

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var autoMode = false
    private var resumeWakeAfter = false
    private var restartJob: Job? = null

    init {
        _state.update {
            it.copy(
                onlineAiEnabled = settings.onlineAiEnabled, provider = settings.provider, endpoint = settings.endpoint,
                model = settings.model, apiKeySaved = settings.apiKey.isNotBlank(), userName = settings.userName,
                assistantName = settings.assistantName, language = settings.language, voicePreference = settings.voicePreference,
                wakeWord = settings.wakeWord, wakeWordEnabled = settings.wakeWordEnabled,
                connectionStatus = if (settings.onlineAiEnabled) "NOT TESTED" else "OFF"
            )
        }
        tts.setPreference(settings.voicePreference)
        voice.listener = object : VoiceController.Listener {
            override fun onState(state: VoiceState) {
                _state.update {
                    when (state) {
                        VoiceState.STARTING -> it.copy(status = CoreStatus.LISTENING, statusDetail = "STARTING MIC")
                        VoiceState.LISTENING -> it.copy(status = CoreStatus.LISTENING, statusDetail = "")
                        VoiceState.PROCESSING -> it.copy(status = CoreStatus.THINKING, statusDetail = "RECOGNIZING")
                        VoiceState.IDLE -> if (it.status == CoreStatus.LISTENING) it.copy(status = CoreStatus.IDLE, level = 0f) else it
                    }
                }
            }
            override fun onPartial(text: String) { _state.update { it.copy(partial = text) } }
            override fun onFinal(alternatives: List<String>) {
                _state.update { it.copy(partial = "", level = 0f) }
                handleUserText(pickBest(alternatives), spoken = true)
            }
            override fun onError(message: String, code: Int) {
                _state.update { it.copy(partial = "", level = 0f, status = CoreStatus.IDLE, statusDetail = message) }
                addLog("(mic)", message, "SYSTEM", "ACTION FAILED")
                if (autoMode && (code == 7 || code == 6)) scheduleAutoRestart(800) // no match / timeout → keep listening
                else if (autoMode) scheduleAutoRestart(2500)
                else maybeResumeWake()
            }
            override fun onRms(rms: Float) { _state.update { it.copy(level = rms) } }
        }
        viewModelScope.launch { WakeWordService.running.collect { r -> _state.update { it.copy(wakeWordRunning = r) } } }
        viewModelScope.launch { WakeWordService.lastError.collect { e -> _state.update { it.copy(wakeWordError = e) } } }
        viewModelScope.launch { FridayAccessibilityService.connected.collect { refreshStatuses() } }
        viewModelScope.launch { delay(1500); _state.update { it.copy(voices = tts.availableVoices(), ttsVoice = tts.activeVoiceLabel) } }
        refreshStatuses()
    }

    // ------------------------------------------------------------------ status

    fun refreshStatuses() {
        val mic = ContextCompat.checkSelfPermission(appCtx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        _state.update {
            it.copy(
                micGranted = mic,
                recognizerAvailable = voice.isAvailable,
                accessibilityEnabled = FridayAccessibilityService.instance != null,
                deviceAdminActive = FridayDeviceAdminReceiver.isActive(appCtx),
                networkAvailable = isOnline(),
                wakeWordRunning = WakeWordService.running.value,
                ttsVoice = tts.activeVoiceLabel
            )
        }
    }

    private fun isOnline(): Boolean {
        val cm = appCtx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    // ------------------------------------------------------------------ voice controls

    fun startListening() {
        if (!ensureMic()) return
        autoMode = true
        _state.update { it.copy(recognitionMode = RecognitionMode.AUTO) }
        beginSession()
    }

    fun pushToTalkStart() {
        if (!ensureMic()) return
        autoMode = false
        restartJob?.cancel()
        _state.update { it.copy(recognitionMode = RecognitionMode.PUSH_TO_TALK) }
        beginSession()
    }

    fun pushToTalkEnd() {
        voice.stopAndFinish()
    }

    fun stop() {
        autoMode = false
        restartJob?.cancel()
        voice.cancel()
        tts.stop()
        _state.update { it.copy(status = CoreStatus.IDLE, statusDetail = "STOPPED", partial = "", level = 0f, recognitionMode = RecognitionMode.OFF) }
        maybeResumeWake()
    }

    fun onWakeWordDetected() {
        addLog("(wake word)", "Wake word detected — listening", "SYSTEM", "INFO")
        resumeWakeAfter = settings.wakeWordEnabled
        autoMode = false
        _state.update { it.copy(recognitionMode = RecognitionMode.MANUAL) }
        beginSession()
    }

    private fun ensureMic(): Boolean {
        refreshStatuses()
        if (!_state.value.micGranted) {
            _state.update { it.copy(statusDetail = "MICROPHONE PERMISSION NEEDED") }
            addLog("(mic)", "Microphone permission nahi hai", "SYSTEM", "NEEDS PERMISSION")
            return false
        }
        return true
    }

    private fun beginSession() {
        tts.stop()
        if (WakeWordService.running.value) { resumeWakeAfter = true; WakeWordService.stop(appCtx) }
        _state.update { it.copy(partial = "", statusDetail = "") }
        voice.start(settings.language, preferOffline = !isOnline())
    }

    private fun scheduleAutoRestart(delayMs: Long) {
        restartJob?.cancel()
        restartJob = viewModelScope.launch {
            delay(delayMs)
            if (autoMode && _state.value.status != CoreStatus.SPEAKING) voice.start(settings.language, preferOffline = !isOnline())
        }
    }

    private fun onSpeechDone() {
        _state.update { if (it.status == CoreStatus.SPEAKING) it.copy(status = CoreStatus.IDLE) else it }
        if (autoMode) scheduleAutoRestart(400) else maybeResumeWake()
    }

    private fun maybeResumeWake() {
        if (resumeWakeAfter && settings.wakeWordEnabled && !autoMode) {
            resumeWakeAfter = false
            viewModelScope.launch { delay(600); if (_state.value.status == CoreStatus.IDLE) WakeWordService.start(appCtx) }
        }
    }

    /** Picks the recognizer alternative that contains the most command keywords (Hinglish fix). */
    private fun pickBest(alts: List<String>): String {
        if (alts.size <= 1) return alts.firstOrNull() ?: ""
        val keys = listOf("kholo", "whatsapp", "youtube", "chrome", "chat", "bhejo", "message", "scroll", "back", "home", "volume", "search", "likho", "settings", "lock", "khol", "open", "send", "friday")
        return alts.maxByOrNull { alt ->
            val n = LocalCommandParser.normalize(alt, settings.wakeWord)
            keys.count { n.contains(it) }
        } ?: alts.first()
    }

    // ------------------------------------------------------------------ brain

    fun submitText(text: String) = handleUserText(text, spoken = false)

    fun confirmPending() = handleUserText("haan", spoken = false)
    fun denyPending() = handleUserText("nahi", spoken = false)

    private fun handleUserText(rawText: String, spoken: Boolean) {
        val raw = rawText.trim()
        if (raw.isEmpty()) return
        val norm = LocalCommandParser.normalize(raw, settings.wakeWord)
        _state.update {
            it.copy(heard = raw, response = "", status = CoreStatus.THINKING, statusDetail = "",
                recent = (listOf(raw) + it.recent).take(8))
        }
        viewModelScope.launch {
            // 1. pending confirmation?
            val pending = context.pendingAction
            if (pending != null) {
                when {
                    LocalCommandParser.isAffirmative(norm) -> {
                        context.clearPending()
                        _state.update { it.copy(pendingDescription = null) }
                        val r = executor.execute(pending)
                        finish(raw, r.message, "LOCAL", resultLabel(r), speak = true)
                        return@launch
                    }
                    LocalCommandParser.isNegative(norm) -> {
                        context.clearPending()
                        _state.update { it.copy(pendingDescription = null) }
                        finish(raw, "Theek hai ${settings.userName}, cancel kar diya.", "LOCAL", "INFO", speak = true)
                        return@launch
                    }
                    else -> { context.clearPending(); _state.update { it.copy(pendingDescription = null) } }
                }
            }
            if (norm.isBlank()) { finish(raw, "Ji ${settings.userName}?", "LOCAL", "INFO", speak = true); return@launch }

            // 2. local command parser (works offline)
            val local = LocalCommandParser.parse(norm, context)
            if (local != null) { runAction(raw, local, "LOCAL"); return@launch }

            // 3. online AI
            val online = isOnline()
            if (settings.onlineAiEnabled && online && settings.endpoint.isNotBlank()) {
                val client = AiClient(settings.endpoint, settings.apiKey, settings.model)
                val sys = AiClient.systemPrompt(settings.assistantName, settings.userName, context.summary())
                val reply = client.chat(sys, context.history(), raw)
                reply.onSuccess { ai ->
                    context.remember("user", raw)
                    context.remember("assistant", ai.text.ifBlank { "(action)" })
                    if (ai.actions.isEmpty()) {
                        finish(raw, ai.text.ifBlank { "..." }, "AI", "INFO", speak = true)
                    } else {
                        if (ai.text.isNotBlank()) {
                            _state.update { it.copy(response = ai.text, responseEngine = "AI") }
                            tts.speak(ai.text)
                        }
                        for (act in ai.actions) runAction(raw, act, "AI", prefix = ai.text)
                    }
                    _state.update { it.copy(connectionStatus = "ONLINE", connectionDetail = "model: ${ai.model}") }
                }.onFailure { e ->
                    _state.update { it.copy(connectionStatus = "ERROR", connectionDetail = e.message ?: "unknown") }
                    val off = LocalCommandParser.offlineAnswer(norm, settings.userName, settings.assistantName)
                    finish(raw, off ?: "AI request fail hui: ${e.message}", if (off != null) "OFFLINE" else "AI", "ACTION FAILED", speak = true)
                }
                return@launch
            }

            // 4. offline fallback
            val off = LocalCommandParser.offlineAnswer(norm, settings.userName, settings.assistantName)
            val msg = off ?: if (!settings.onlineAiEnabled)
                "Yeh command local mode mein supported nahi hai. Settings mein Online AI enable karein ya 'YouTube kholo', 'Kartavya ki chat kholo' jaise commands bolein."
            else "Internet nahi hai, isliye AI available nahi. Local commands (app kholna, scroll, volume, WhatsApp) ab bhi chalenge."
            finish(raw, msg, "OFFLINE", if (off != null) "INFO" else "ACTION FAILED", speak = true)
        }
    }

    private suspend fun runAction(raw: String, action: FridayAction, engine: String, prefix: String = "") {
        if (action is FridayAction.StopSpeaking) { tts.stop(); finish(raw, "Ruk gayi.", engine, "ACTION SUCCESS", speak = false); return }
        if (action.requiresConfirmation) {
            val a = action as FridayAction.WhatsAppSendMessage
            val recipient = a.recipient ?: context.lastRecipient
            if (recipient == null) {
                finish(raw, "${settings.userName}, kisko bhejna hai? Pehle contact ka naam bataiye (jaise 'Kartavya ki chat kholo').", engine, "INFO", speak = true)
                return
            }
            val resolved = FridayAction.WhatsAppSendMessage(recipient, a.message)
            context.setPending(resolved)
            context.setMessage(a.message)
            val ask = "${settings.userName}, $recipient ko \"${a.message}\" message bhejna hai. Confirm karun?"
            _state.update { it.copy(pendingDescription = resolved.describe()) }
            finish(raw, ask, engine, "NEEDS CONFIRMATION", speak = true)
            return
        }
        val r = executor.execute(action)
        val text = if (prefix.isNotBlank() && r.ok) r.message else r.message
        finish(raw, text, engine, resultLabel(r), speak = true)
    }

    private fun resultLabel(r: ActionResult) = when {
        r.needsConfirmation -> "NEEDS CONFIRMATION"
        r.needsPermission -> "NEEDS PERMISSION"
        r.ok -> "ACTION SUCCESS"
        else -> "ACTION FAILED"
    }

    private fun finish(heard: String, response: String, engine: String, result: String, speak: Boolean) {
        _state.update { it.copy(response = response, responseEngine = engine, lastEngine = engine, lastActionResult = result, status = CoreStatus.IDLE) }
        addLog(heard, response, engine, result)
        if (speak) {
            if (!tts.speak(response)) onSpeechDone()
        } else onSpeechDone()
    }

    private fun addLog(heard: String, response: String, engine: String, result: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        _state.update { it.copy(log = (listOf(LogEntry(t, heard, response, engine, result)) + it.log).take(200)) }
    }

    fun clearLog() = _state.update { it.copy(log = emptyList(), recent = emptyList()) }
    fun clearContext() { context.clearAll(); _state.update { it.copy(pendingDescription = null) }; addLog("(system)", "Conversation context cleared", "SYSTEM", "INFO") }

    // ------------------------------------------------------------------ settings

    fun saveAi(enabled: Boolean, provider: String, endpoint: String, model: String, apiKey: String?) {
        settings.onlineAiEnabled = enabled
        settings.provider = provider.ifBlank { "Custom" }
        settings.endpoint = endpoint.trim().ifBlank { SecureSettings.DEFAULT_ENDPOINT }
        settings.model = model.trim().ifBlank { SecureSettings.DEFAULT_MODEL }
        if (apiKey != null) settings.apiKey = apiKey.trim()
        _state.update {
            it.copy(onlineAiEnabled = enabled, provider = settings.provider, endpoint = settings.endpoint, model = settings.model,
                apiKeySaved = settings.apiKey.isNotBlank(), connectionStatus = if (enabled) "SAVED · NOT TESTED" else "OFF", connectionDetail = "")
        }
        addLog("(settings)", "AI settings saved (key ${if (settings.apiKey.isNotBlank()) "stored encrypted" else "empty"})", "SYSTEM", "INFO")
    }

    fun testConnection() {
        if (_state.value.testing) return
        _state.update { it.copy(testing = true, connectionStatus = "TESTING", connectionDetail = "") }
        viewModelScope.launch {
            if (!isOnline()) {
                _state.update { it.copy(testing = false, connectionStatus = "NO INTERNET", connectionDetail = "Device offline hai") }
                addLog("(test)", "Connection test: no internet", "SYSTEM", "ACTION FAILED"); return@launch
            }
            val r = AiClient(settings.endpoint, settings.apiKey, settings.model).testConnection()
            r.onSuccess { msg ->
                _state.update { it.copy(testing = false, connectionStatus = "CONNECTED", connectionDetail = msg) }
                addLog("(test)", "Connection OK: $msg", "SYSTEM", "ACTION SUCCESS")
            }.onFailure { e ->
                _state.update { it.copy(testing = false, connectionStatus = "FAILED", connectionDetail = e.message ?: "unknown error") }
                addLog("(test)", "Connection failed: ${e.message}", "SYSTEM", "ACTION FAILED")
            }
        }
    }

    fun saveProfile(userName: String, assistantName: String, language: String, voicePref: String) {
        settings.userName = userName.trim().ifBlank { "Boss" }
        settings.assistantName = assistantName.trim().ifBlank { "FRIDAY" }
        settings.language = language
        settings.voicePreference = voicePref
        tts.setPreference(voicePref)
        _state.update { it.copy(userName = settings.userName, assistantName = settings.assistantName, language = language, voicePreference = voicePref, ttsVoice = tts.activeVoiceLabel) }
        addLog("(profile)", "Profile saved: ${settings.userName} / ${settings.assistantName} / $language / $voicePref", "SYSTEM", "INFO")
    }

    fun previewVoice() { tts.speak("Hello ${settings.userName}, main ${settings.assistantName} hoon. Awaaz test ho rahi hai.") }

    fun setWakeWord(word: String, enabled: Boolean) {
        settings.wakeWord = word.trim().lowercase(Locale.ROOT).ifBlank { "friday" }
        settings.wakeWordEnabled = enabled
        _state.update { it.copy(wakeWord = settings.wakeWord, wakeWordEnabled = enabled) }
        if (enabled) {
            if (!ensureMic()) { settings.wakeWordEnabled = false; _state.update { it.copy(wakeWordEnabled = false) }; return }
            WakeWordService.start(appCtx)
            addLog("(wake)", "Wake-word service started (foreground, mic in use)", "SYSTEM", "INFO")
        } else {
            WakeWordService.stop(appCtx)
            addLog("(wake)", "Wake-word service stopped", "SYSTEM", "INFO")
        }
    }

    override fun onCleared() {
        voice.destroy()
        tts.shutdown()
        super.onCleared()
    }
}
