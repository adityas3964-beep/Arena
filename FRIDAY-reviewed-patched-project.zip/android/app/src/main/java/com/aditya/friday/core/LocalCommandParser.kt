package com.aditya.friday.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Offline Hindi / Hinglish / English command understanding. Works with no internet.
 * Also fixes common speech-recognition artefacts (Devanagari keywords, misspellings).
 */
object LocalCommandParser {

    private val devanagariMap = linkedMapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सप्प" to "whatsapp", "वाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "यूट्यूब" to "youtube", "क्रोम" to "chrome", "कैमरा" to "camera", "कैलकुलेटर" to "calculator",
        "गैलरी" to "gallery", "सेटिंग्स" to "settings", "सेटिंग" to "settings", "फोन" to "phone", "फ़ोन" to "phone",
        "गूगल" to "google", "मैसेज" to "message", "मेसेज" to "message", "संदेश" to "message",
        "खोलो" to "kholo", "खोल दो" to "kholo", "खोल" to "kholo", "चालू करो" to "chalu karo",
        "बंद करो" to "band karo", "बंद" to "band", "वापस" to "wapas", "पीछे" to "peeche",
        "नीचे" to "neeche", "ऊपर" to "upar", "स्क्रॉल" to "scroll", "होम" to "home", "स्क्रीन" to "screen",
        "लिखो" to "likho", "लिख दो" to "likho", "टाइप" to "type", "भेजो" to "bhejo", "भेज दो" to "bhejo",
        "सर्च" to "search", "खोजो" to "search karo", "ढूंढो" to "search karo", "आवाज़" to "volume", "आवाज" to "volume",
        "वॉल्यूम" to "volume", "कम" to "kam", "ज़्यादा" to "zyada", "ज्यादा" to "zyada", "बढ़ाओ" to "badhao", "बढ़ा" to "badha",
        "लॉक" to "lock", "करो" to "karo", "कर दो" to "kar do", "जाओ" to "jao", "पर" to "par", "में" to "mein",
        "की" to "ki", "का" to "ka", "को" to "ko", "चैट" to "chat", "उसको" to "usko", "उसे" to "use", "इसको" to "isko",
        "क्लिक" to "click", "दबाओ" to "dabao", "रुको" to "ruko", "चुप" to "chup", "वाईफ़ाई" to "wifi", "वाईफाई" to "wifi",
        "ब्लूटूथ" to "bluetooth", "डिस्प्ले" to "display", "हाँ" to "haan", "हां" to "haan", "जी" to "ji", "नहीं" to "nahi",
        "नही" to "nahi", "टाइम" to "time", "समय" to "time", "तारीख" to "date", "जोक" to "joke", "चुटकुला" to "joke",
        "हेलो" to "hello", "नमस्ते" to "namaste"
    )

    private val typoMap = mapOf(
        "whats app" to "whatsapp", "whatsup" to "whatsapp", "what's app" to "whatsapp", "whatsaap" to "whatsapp",
        "you tube" to "youtube", "u tube" to "youtube", "chrom" to "chrome", "crome" to "chrome",
        "kolo" to "kholo", "khol do" to "kholo", "khol de" to "kholo", "kholdo" to "kholo", "open karo" to "kholo",
        "open kar" to "kholo", "bhej de" to "bhejo", "bhej do" to "bhejo", "send kar do" to "bhejo", "send karo" to "bhejo",
        "send kar" to "bhejo", "likh de" to "likho", "likh do" to "likho", "type karo" to "likho", "type kar" to "likho",
        "niche" to "neeche", "nichay" to "neeche", "oopar" to "upar", "uper" to "upar", "upr" to "upar",
        "piche" to "peeche", "pichhe" to "peeche", "vapas" to "wapas", "wapis" to "wapas",
        "volume kam kar do" to "volume kam", "volume kam karo" to "volume kam", "awaz" to "volume", "aawaz" to "volume",
        "jyada" to "zyada", "badha do" to "badhao", "badhao" to "badhao", "tez karo" to "badhao",
        "settings kholo" to "settings kholo", "setting kholo" to "settings kholo"
    )

    fun normalize(input: String, wakeWord: String): String {
        var t = input.lowercase(Locale.ROOT).trim()
        devanagariMap.forEach { (k, v) -> t = t.replace(k, " $v ") }
        t = t.replace(Regex("[,.!?।\"']"), " ")
        // strip the wake word anywhere at the start ("friday", "fraiday", "hey friday")
        val ww = wakeWord.lowercase(Locale.ROOT).trim()
        t = t.replace(Regex("^(hey |ok |okay |hi )?($ww|fraiday|fryday|frieday|फ्राइडे|फ्राईडे)\\b[, ]*"), "")
        typoMap.forEach { (k, v) -> t = t.replace(k, v) }
        return t.replace(Regex("\\s+"), " ").trim()
    }

    fun isAffirmative(t: String): Boolean {
        val n = t.trim()
        return Regex("^(haan|haa|ha|han|hanji|ji haan|ji|yes|yeah|yep|ok|okay|theek hai|thik hai|sahi hai|bhejo|bhej do|send|send karo|kar do|karo|confirm|confirmed|done|sure|go ahead|yes please)( .*)?$").matches(n) ||
            n.startsWith("haan ") || n.startsWith("yes ") || n.startsWith("ji ")
    }

    fun isNegative(t: String): Boolean {
        val n = t.trim()
        return Regex("^(nahi|nahin|na|no|nope|mat|cancel|rehne do|rahne do|ruko|chhod do|chod do|stop|don't|dont|mat bhejo)( .*)?$").matches(n)
    }

    private val appWords = listOf("whatsapp", "youtube", "chrome", "camera", "gallery", "calculator", "settings", "phone", "google", "maps", "gmail", "instagram", "facebook", "telegram", "spotify", "clock", "calendar", "contacts", "messages", "play store", "files")

    /** Returns a local action or null (null = let the AI / offline Q&A handle it). */
    fun parse(raw: String, ctx: ConversationContext): FridayAction? {
        val t = raw
        if (t.isBlank()) return null

        // ---- stop / quiet
        if (Regex("^(stop|ruko|chup|chup raho|quiet|be quiet|bas|rukja|ruk jao)$").matches(t)) return FridayAction.StopSpeaking

        // ---- WhatsApp: send message with pronoun reference
        Regex("^(?:whatsapp (?:par|pe|mein|me) )?(?:usko|use|usse|unko|unhe|isko|ise|him|her|them) (?:ek |yeh |ye )?(.+?)(?: message| msg)? (?:bhejo|bhej|send|likho|likh|bhejna|bhejdo)$").find(t)?.let {
            return FridayAction.WhatsAppSendMessage(ctx.lastRecipient, cleanMessage(it.groupValues[1]))
        }
        Regex("^send (?:him|her|them) (?:a message )?(?:saying )?(.+)$").find(t)?.let {
            return FridayAction.WhatsAppSendMessage(ctx.lastRecipient, cleanMessage(it.groupValues[1]))
        }
        // ---- WhatsApp: "<name> ko <msg> bhejo"  /  "send <msg> to <name>"  /  "message <name> <msg>"
        Regex("^(?:whatsapp (?:par|pe|mein|me) )?(.+?) ko (?:whatsapp (?:par|pe|mein|me) )?(?:ek |yeh |ye )?(.+?)(?: message| msg)? (?:bhejo|bhej|send|likho|bhejna|bhejdo)$").find(t)?.let {
            val name = it.groupValues[1].trim()
            if (name !in setOf("whatsapp", "usko", "use")) return FridayAction.WhatsAppSendMessage(cleanName(name), cleanMessage(it.groupValues[2]))
        }
        Regex("^(?:whatsapp )?(?:send|message|text) (.+?) to (.+)$").find(t)?.let {
            return FridayAction.WhatsAppSendMessage(cleanName(it.groupValues[2]), cleanMessage(it.groupValues[1]))
        }
        Regex("^(?:whatsapp )?message (.+?) (?:saying|that|:) (.+)$").find(t)?.let {
            return FridayAction.WhatsAppSendMessage(cleanName(it.groupValues[1]), cleanMessage(it.groupValues[2]))
        }
        // ---- WhatsApp: open chat
        Regex("^(?:whatsapp (?:par|pe|mein|me) )?(.+?) (?:ki|ka|ke) chat (?:kholo|open|dikhao|khol)$").find(t)?.let {
            return FridayAction.WhatsAppOpenChat(cleanName(it.groupValues[1]))
        }
        Regex("^(?:open|show) (?:whatsapp )?(?:chat (?:with|of) )?(.+?)(?:'s)? (?:whatsapp )?chat$").find(t)?.let {
            return FridayAction.WhatsAppOpenChat(cleanName(it.groupValues[1]))
        }
        Regex("^(?:open|show) (?:whatsapp )?chat (?:with|of) (.+)$").find(t)?.let {
            return FridayAction.WhatsAppOpenChat(cleanName(it.groupValues[1]))
        }
        Regex("^(.+?) (?:se baat karo|se baat karni hai|ko message karna hai)$").find(t)?.let {
            return FridayAction.WhatsAppOpenChat(cleanName(it.groupValues[1]))
        }

        // ---- navigation
        if (Regex("^(back|back jao|peeche|peeche jao|wapas|wapas jao|go back|back karo|piche jao)$").matches(t)) return FridayAction.Back
        if (Regex("^(home|home jao|home screen|home screen par jao|home screen pe jao|home par jao|home pe jao|go home|home karo)$").matches(t)) return FridayAction.Home
        if (Regex("^(neeche scroll(?: karo)?|scroll down|neeche karo|neeche jao|scroll neeche|niche scroll karo|page down)$").matches(t)) return FridayAction.ScrollDown
        if (Regex("^(upar scroll(?: karo)?|scroll up|upar karo|upar jao|scroll upar|page up)$").matches(t)) return FridayAction.ScrollUp

        // ---- volume
        if (Regex("^(volume|sound|awaaz) (kam|down|ghatao|ghata do|low|kam karo)( .*)?$").matches(t) || t == "volume kam") return FridayAction.Volume("down")
        if (Regex("^(volume|sound|awaaz) (zyada|up|badhao|badha do|tez|high|badha)( .*)?$").matches(t) || Regex("^(increase|raise) (the )?volume$").matches(t)) return FridayAction.Volume("up")
        if (Regex("^(decrease|lower|reduce) (the )?volume$").matches(t)) return FridayAction.Volume("down")
        if (Regex("^(mute|volume mute|silent|silent karo|volume band|phone silent karo|mute karo|awaaz band karo)$").matches(t)) return FridayAction.Volume("mute")

        // ---- lock
        if (Regex("^(phone lock(?: karo| kar do)?|screen lock(?: karo)?|lock (?:the )?(?:phone|screen)|lock karo|lock kar do|phone band karo|screen band karo)$").matches(t)) return FridayAction.LockPhone

        // ---- settings sections
        if (Regex("^(?:phone (?:ki|ka) )?(wifi|wi fi|wi-fi)(?: (?:ki|ka))? (?:settings? )?(?:kholo|open|dikhao|on karo|off karo)$").matches(t) || t.contains("wifi settings")) return FridayAction.OpenSettings("wifi")
        if (t.contains("bluetooth")) return FridayAction.OpenSettings("bluetooth")
        if (t.contains("display") || t.contains("brightness") || t.contains("screen settings")) return FridayAction.OpenSettings("display")
        if (Regex("^(?:phone (?:ki|ka|ke) )?settings? (?:kholo|open|dikhao|mein jao|me jao)$").matches(t) || t == "open settings" || t == "settings") return FridayAction.OpenSettings("general")

        // ---- type text
        Regex("^(?:search box|box|text box|yahan|yaha|yahan par|isme|is mein|field)(?: mein| me| par| pe)? (.+?) (?:likho|likh|type|type karo|enter karo|daalo)$").find(t)?.let {
            return FridayAction.TypeText(it.groupValues[1].trim())
        }
        Regex("^(?:type|likho|write) (.+)$").find(t)?.let { return FridayAction.TypeText(it.groupValues[1].trim()) }
        Regex("^(.+?) (?:likho|likh do|type karo)$").find(t)?.let { return FridayAction.TypeText(it.groupValues[1].trim()) }

        // ---- web search
        Regex("^(?:google|internet|web|net) (?:par|pe|mein|me|par jake) (.+?) (?:search karo|search|dhundo|dhoondo|dhundho|khojo|search kar)$").find(t)?.let {
            return FridayAction.WebSearch(it.groupValues[1].trim())
        }
        Regex("^(?:search|google|look up|search for|search karo) (.+)$").find(t)?.let {
            val q = it.groupValues[1].removeSuffix(" search karo").removeSuffix(" karo").trim()
            if (q.isNotBlank()) return FridayAction.WebSearch(q)
        }
        Regex("^(.+?) (?:google karo|search karo|dhundo|dhoondo)$").find(t)?.let {
            return FridayAction.WebSearch(it.groupValues[1].trim())
        }

        // ---- click
        Regex("^(.+?) (?:par|pe) (?:click|tap|dabao|press) ?(?:karo)?$").find(t)?.let { return FridayAction.ClickText(it.groupValues[1].trim()) }
        Regex("^(?:click|tap|press)(?: on)? (.+?)(?: button)?$").find(t)?.let { return FridayAction.ClickText(it.groupValues[1].trim()) }
        Regex("^(.+?) (?:button )?dabao$").find(t)?.let { return FridayAction.ClickText(it.groupValues[1].trim()) }

        // ---- open app  (very common, keep late so specific patterns win)
        Regex("^(?:open|launch|start|run) (.+?)(?: app| application)?$").find(t)?.let { return FridayAction.OpenApp(it.groupValues[1].trim()) }
        Regex("^(.+?)(?: app| application)? (?:kholo|chalu karo|chalao|on karo|start karo|launch karo|open karo|khol)$").find(t)?.let {
            return FridayAction.OpenApp(it.groupValues[1].trim())
        }
        // bare app name ("youtube", "whatsapp")
        if (t in appWords) return FridayAction.OpenApp(t)

        return null
    }

    private fun cleanName(s: String): String =
        s.replace(Regex("^(mere |mera |meri |my )"), "").replace(Regex(" (bhai|ji|sir)$"), "").trim()

    private fun cleanMessage(s: String): String {
        var m = s.trim()
        m = m.replace(Regex("^(ki |ke |ka |that |saying )"), "")
        m = m.replace(Regex(" (message|msg|likh ke|likhke)$"), "").trim()
        // if the user said 'hi' / 'hello' the recogniser sometimes gives 'hay' / 'hai'
        if (m == "hay" || m == "hai" || m == "hii") m = "Hi"
        return m.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }

    private val jokes = listOf(
        "Teacher: Beta, homework kahan hai? Student: Sir, FRIDAY ne kaha offline hoon, kal karna!",
        "Programmer ki wife: Bazaar se ek doodh lana, aur agar ande hain to chhe le aana. Programmer chhe doodh le aaya.",
        "Why did the phone go to school? Because it wanted to be a smart-phone!",
        "Doctor: Aap roz 8 ghante sote hain? Patient: Haan, office mein 4 aur ghar mein 4.",
        "Mera Wi-Fi password 'incorrect' hai, taaki jab bhi galat daloon, phone khud bata de: password is incorrect!"
    )

    /** Small offline knowledge so the assistant still answers when there is no internet. */
    fun offlineAnswer(t: String, userName: String, assistantName: String): String? {
        if (Regex("(time kya|kitne baje|what time|what's the time|samay kya|time batao|time)").containsMatchIn(t) && t.length < 40) {
            return "$userName, abhi ${SimpleDateFormat("h:mm a", Locale.US).format(Date())} baje hain."
        }
        if (Regex("(date|tareekh|aaj kya din|aaj kaun sa din|what day)").containsMatchIn(t) && t.length < 40) {
            return "Aaj ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.US).format(Date())} hai."
        }
        if (Regex("(joke|chutkula|hasao|hasaao|funny)").containsMatchIn(t)) {
            return jokes[Calendar.getInstance().get(Calendar.SECOND) % jokes.size]
        }
        if (Regex("(india ki capital|india ka capital|capital of india|bharat ki rajdhani)").containsMatchIn(t)) {
            return "India ki capital New Delhi hai, $userName."
        }
        if (Regex("^(hello|hi|hey|namaste|hello $assistantName|hi $assistantName|namaskar)").containsMatchIn(t) && t.length < 30) {
            return "Hello $userName! Main $assistantName hoon. Boliye, kya karna hai?"
        }
        if (Regex("(tum kaun ho|who are you|aap kaun|tumhara naam|your name)").containsMatchIn(t)) {
            return "Main $assistantName hoon, aapki personal AI assistant. Credit: Aditya."
        }
        if (Regex("(kaise ho|how are you|kya haal)").containsMatchIn(t)) {
            return "Main bilkul theek hoon $userName, aap batao kya karna hai?"
        }
        if (Regex("(thank|shukriya|dhanyavad)").containsMatchIn(t)) {
            return "Hamesha hazir, $userName."
        }
        return null
    }
}
