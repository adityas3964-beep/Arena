package com.aditya.friday.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.aditya.friday.MainActivity
import com.aditya.friday.R
import com.aditya.friday.data.SecureSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale
import android.os.Bundle

/**
 * HONEST wake-word implementation: a foreground service (persistent notification + system
 * microphone indicator) that runs the on-device Android SpeechRecognizer in a loop and
 * checks each result for the configured wake word. This is NOT a dedicated low-power
 * wake-word engine (no Porcupine/Snowboy key is bundled); it costs battery and the loop
 * restarts every few seconds, so it is OFF by default and clearly labelled in the UI.
 * When the wake word is heard the service stops itself (freeing the mic) and opens
 * FRIDAY in listening mode; the app restarts it after the command if still enabled.
 */
class WakeWordService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wakeWord = "friday"
    private var language = "hi-IN"
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val settings = SecureSettings(this)
        wakeWord = settings.wakeWord.lowercase(Locale.ROOT).ifBlank { "friday" }
        language = settings.language

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            _lastError.value = "Speech recognition service unavailable"
            stopSelf()
            return START_NOT_STICKY
        }
        _running.value = true
        _lastError.value = null
        startCycle()
        return START_STICKY
    }

    private fun startCycle() {
        if (stopping) return
        recognizer?.let { runCatching { it.destroy() } }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                val delayMs = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2000L else 600L
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    _lastError.value = "Microphone permission missing"
                    stopSelf(); return
                }
                handler.postDelayed({ startCycle() }, delayMs)
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.any { matchesWake(it) }) {
                    val heard = list.first()
                    onWakeDetected(heard)
                } else {
                    handler.postDelayed({ startCycle() }, 300)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.any { matchesWake(it) }) {
                    runCatching { recognizer?.stopListening() }
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        runCatching { r.startListening(intent) }.onFailure {
            handler.postDelayed({ startCycle() }, 1500)
        }
    }

    private fun matchesWake(text: String): Boolean {
        val t = text.lowercase(Locale.ROOT)
        val variants = listOf(wakeWord, "fraiday", "fryday", "frieday", "फ्राइडे", "फ्राईडे").filter { it.isNotBlank() }
        return variants.any { t.contains(it) }
    }

    private fun onWakeDetected(heard: String) {
        stopping = true
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            .putExtra(MainActivity.EXTRA_WAKE, true)
            .putExtra(MainActivity.EXTRA_WAKE_TEXT, heard)
        runCatching { startActivity(i) }
        _wakeEvents.value = System.currentTimeMillis()
        stopSelf()
    }

    override fun onDestroy() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
        recognizer = null
        _running.value = false
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, getString(R.string.wake_channel_name), NotificationManager.IMPORTANCE_LOW)
        ch.description = "Shown while FRIDAY uses the microphone to listen for the wake word"
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.wake_notification_title))
            .setContentText(getString(R.string.wake_notification_text))
            .setContentIntent(open)
            .addAction(0, "STOP", stop)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "friday_wake"
        const val NOTIF_ID = 4101
        const val ACTION_STOP = "com.aditya.friday.WAKE_STOP"

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running
        private val _lastError = MutableStateFlow<String?>(null)
        val lastError: StateFlow<String?> = _lastError
        private val _wakeEvents = MutableStateFlow(0L)
        val wakeEvents: StateFlow<Long> = _wakeEvents

        fun start(context: Context) {
            val i = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, WakeWordService::class.java).setAction(ACTION_STOP))
        }
    }
}
