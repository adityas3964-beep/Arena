# FRIDAY – Your Personal AI Assistant (Android)

Native Android app · Kotlin · Jetpack Compose · package `com.aditya.friday`

> **Whole credit goes to Aditya. © 2026 Aditya. All rights reserved.**

---

## ⚠️ Build & testing report — read this first (honest status)

| Item | Status |
|---|---|
| Source project written (all core files, manifest, services, resources) | ✅ Done |
| **Compiled in the authoring environment** | ❌ **Not possible** – the environment that generated this project has **no JDK, no Android SDK and no Gradle**. No APK was produced there and none is claimed. |
| GitHub Actions workflow that compiles the project and uploads `app-debug.apk` | ✅ Provided (`.github/workflows/android-build.yml`) |
| JVM unit tests (command parser, context, confirmation words, AI reply/validator) | ✅ Written (`app/src/test`), run by the workflow — **not yet executed by the author** |
| Emulator testing | ❌ Not performed |
| Physical device testing | ❌ Not performed |
| Requires manual setup after install | Microphone permission, Accessibility service, (optional) Device Admin, (optional) API key |

Because this code has not been compiled by the author, the first CI run may surface compile errors
(typically import/API-signature issues). They are expected to be small; fix, push, and re-run.

---

## How to get the APK

### Option A – GitHub Actions (recommended, no local tooling)
1. Push this repository to GitHub (keep the `android/` folder and `.github/workflows/android-build.yml` at the repo root).
2. Open **Actions → Build FRIDAY APK → Run workflow** (it also runs on every push touching `android/`).
3. When the job is green, download the **`friday-debug-apk`** artifact → `app-debug.apk`.
4. The workflow verifies the file with `aapt dump badging` before uploading, so the artifact is a real Android package.

### Option B – Android Studio
1. **File → Open** → select the `android/` folder (Android Studio Koala or newer, JDK 17).
2. Let it sync (it will generate the Gradle wrapper if asked; Gradle 8.9 / AGP 8.5.2 / Kotlin 2.0.20).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`.

### Option C – command line
```bash
cd android
gradle wrapper --gradle-version 8.9     # once, if ./gradlew is missing
./gradlew testDebugUnitTest assembleDebug
ls app/build/outputs/apk/debug/app-debug.apk
```

## Installation
1. Copy `app-debug.apk` to the phone, allow "install unknown apps" for your file manager, tap to install.
2. Open FRIDAY → tap **START LISTENING** → grant **Microphone** (and notification permission on Android 13+).
3. Settings tab → **Open accessibility settings** → enable **FRIDAY Phone Control** (needed for Back/Home/scroll/click/type and WhatsApp automation).
4. Optional: Settings → **Activate device admin** (only the force-lock policy; lets "phone lock karo" lock the screen). Deactivate from the same panel.

## AI configuration (Groq free tier)
1. Create a key at https://console.groq.com/keys (free tier; rate-limited; no billing required — limits are set by Groq and may change).
2. FRIDAY → Settings → **AI Provider**: toggle **Enable Online AI**, provider **Groq**,
   endpoint `https://api.groq.com/openai/v1/chat/completions`, model e.g. `llama-3.3-70b-versatile` (edit if Groq retires it), paste the key.
3. **Save key** (stored in EncryptedSharedPreferences with an Android-Keystore master key) → **Test** (performs a real request; the HTTP status/model/error is shown as-is).
4. Any OpenAI-compatible endpoint works (OpenAI, local servers such as LM Studio/Ollama with the `/v1/chat/completions` route).

Without AI: all local commands still work (apps, navigation, volume, settings, WhatsApp flow, time/date/jokes/basic Q&A).

## Voice commands (Hindi / Hinglish / English)
`FRIDAY, YouTube kholo` · `WhatsApp open karo` · `Chrome kholo` · `Google par <x> search karo` · `Phone ki settings kholo` ·
`Volume kam kar do` · `Back jao` · `Home screen par jao` · `Neeche/Upar scroll karo` · `Search box mein Hello likho` ·
`Kartavya ki chat kholo` → `Usko Hi message bhejo` → FRIDAY asks *"Boss, Kartavya ko "Hi" message bhejna hai. Confirm karun?"* → `Haan` ·
`Phone lock karo` · `India ki capital kya hai?` · `Ek funny joke sunao`.

## Architecture
```
ai/AiClient.kt                     OpenAI-compatible client, test connection, JSON reply parser
core/FridayAction.kt               Validated action schema (whitelist) + ActionValidator
core/LocalCommandParser.kt         Offline Hindi/Hinglish/English intent parser + speech-error fixes
core/ConversationContext.kt        Recipient/message/app/pending memory + bounded transcript
core/ActionExecutor.kt             The only place actions touch Android APIs
automation/FridayAccessibilityService.kt  Back/Home/scroll/click/type + WhatsApp search→open→type→send (verified)
automation/AppLauncher.kt          Known packages + launcher-label matching
voice/VoiceController.kt           SpeechRecognizer wrapper (auto / push-to-talk)
voice/TtsController.kt             TextToSpeech, Hindi/en-IN voices with fallback
voice/WakeWordService.kt           Foreground service wake-word loop (honest, battery-costly, OFF by default)
admin/FridayDeviceAdminReceiver.kt force-lock policy only
data/SecureSettings.kt             Keystore-encrypted preferences
ui/*                               Compose: Splash, Home, Log, Profile, Settings, HUD components
```

## Known limitations
- Wake word uses Android's on-device `SpeechRecognizer` in a loop inside a foreground service — not a dedicated low-power engine. It drains battery, shows the mic indicator continuously, and cannot run while another app/FRIDAY itself uses the mic. It stops itself when triggered and is restarted after the command.
- WhatsApp automation depends on WhatsApp's current UI (view ids `menuitem_search`, `entry`, `send`, visible content descriptions). A WhatsApp update can break a step; FRIDAY then reports the failure and leaves the chat/typed message for you to finish manually. Send success is verified only by the input box clearing — not by delivery ticks.
- Speech recognition quality (especially Hinglish) depends on the device's recognition service (usually Google). Offline recognition needs the language pack downloaded in system settings.
- Hindi TTS requires Hindi voice data in the device's TTS engine; otherwise en-IN/en-US fallback is used and labelled.
- `GLOBAL_ACTION_HOME`, scroll and click work only while the Accessibility service is enabled. Some OEM launchers/system dialogs are not accessible.
- Groq free-tier limits apply; errors (429 etc.) are shown verbatim.
- No calls, payments, password handling or data wipe are implemented by design.
