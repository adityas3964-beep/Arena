# FRIDAY ZIP review and safety patch

## What was reviewed
- Native Android project under `android/` (Kotlin + Jetpack Compose)
- Android manifest and Accessibility Service configuration
- AI client and secure settings
- Voice recognition, TTS and wake-word foreground service
- Command execution and WhatsApp automation
- GitHub Actions Android build workflow

## Important build status
- The supplied archive did **not** contain a compiled APK.
- The supplied archive does **not** include `gradlew`, `gradlew.bat`, or `gradle/wrapper/gradle-wrapper.jar`.
- This review environment has Java 21 but no Android SDK, no installed Gradle, and no network access to fetch the missing build tools. Therefore an Android build cannot honestly be claimed here.
- The GitHub Actions workflow is the intended APK build path. Push the project to a GitHub repository and run **Actions → Build FRIDAY APK → Run workflow**. A successful run should upload `friday-debug-apk` containing `app-debug.apk`.

## Safety patch applied
`android/app/src/main/java/com/aditya/friday/core/ActionExecutor.kt`

Before this patch, the sender could skip reopening the recipient chat if FRIDAY's in-memory context said the previous recipient was already open. If the user had manually switched to another WhatsApp chat, the app could attempt to send in the wrong conversation. The patched version always re-resolves/reopens the named recipient immediately before typing and sending. This reduces wrong-recipient risk but still requires real-device testing because WhatsApp UI layouts can change.

## Known limitations to test on a real Android phone
1. WhatsApp accessibility automation relies on WhatsApp's current UI labels/resource IDs and may need adjustment after app updates.
2. The send check only observes whether the message input field cleared. It does not prove delivery or read status.
3. The wake-word service loops Android SpeechRecognizer; it is not a dedicated low-power wake-word engine and can consume battery / keep the microphone indicator active.
4. Speech recognition language/offline support depends on the phone's installed recognition service and language packs.
5. Accessibility, microphone, notification and optional Device Admin permissions must be enabled by the user.
6. The supplied code originally fell back to unencrypted preferences if Keystore initialization failed. The reviewed ZIP has been patched to fail closed for API-key storage in that case; non-secret preferences remain usable. The UI should still be checked to ensure it clearly tells the user when secure key storage is unavailable.

## What is not claimed
- No APK build has been run in this environment.
- No physical-device testing has been performed.
- WhatsApp automation is not guaranteed across all WhatsApp versions/devices.

## Additional security patch applied
`android/app/src/main/java/com/aditya/friday/data/SecureSettings.kt`

If Android Keystore / EncryptedSharedPreferences initialization fails, the patched version no longer silently stores the API key in ordinary unencrypted preferences. In that rare case it keeps non-secret settings usable and returns an empty API key. The UI should be tested to ensure the user receives a clear warning that secure key storage is unavailable.
